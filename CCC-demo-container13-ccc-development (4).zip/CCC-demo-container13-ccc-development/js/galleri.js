import {
  fetchFreshGalleryData,
  getCachedGalleryData
} from "./gallery-data.js?v=1.1.0";

(() => {
  "use strict";

  const PROJECT_ID = "container13-87c1a";
  const API_KEY = "AIzaSyDDWaTS_Yyo5X-skYiJ5nQYX5Jc5ZSa1tw";

  const gallery = document.getElementById("gallery");
  const lightbox = document.getElementById("lightbox");
  const lightboxImage = document.getElementById("lightboxImage");
  const closeButton = document.getElementById("close");
  const previousButton = document.querySelector(".prev");
  const nextButton = document.querySelector(".next");

  let images = [];
  let currentIndex = 0;
  let touchStartX = 0;

  function val(value) {
    if (!value || typeof value !== "object") return null;
    if ("stringValue" in value) return value.stringValue;
    if ("booleanValue" in value) return value.booleanValue;
    if ("integerValue" in value) return Number(value.integerValue);
    if ("doubleValue" in value) return Number(value.doubleValue);
    if ("timestampValue" in value) return value.timestampValue;
    if (value.mapValue) return fields(value.mapValue.fields || {});
    if (value.arrayValue) return (value.arrayValue.values || []).map(val);
    return null;
  }

  function fields(source) {
    const result = {};
    Object.entries(source || {}).forEach(([key, value]) => {
      result[key] = val(value);
    });
    return result;
  }

  function imageUrl(item) {
    return String(item.imageUrl || item.url || item.downloadURL || item.downloadUrl || "").trim();
  }

  function category(item) {
    return String(item.category || item.type || item.section || "").trim().toLowerCase();
  }

  function time(item) {
    const raw = item.createdAt || item.uploadedAt || item.date || item.documentCreatedAt || "";
    const parsed = new Date(raw).getTime();
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function showCurrentImage() {
    const item = images[currentIndex];
    if (!item || !lightboxImage) return;
    lightboxImage.src = imageUrl(item);
    lightboxImage.alt = item.title || "Bild från Container 13 Vintage";
  }

  function openLightbox(index) {
    if (!lightbox || !images.length) return;
    currentIndex = index;
    showCurrentImage();
    lightbox.style.display = "flex";
    lightbox.classList.add("show", "active");
    lightbox.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.classList.remove("show", "active");
    lightbox.setAttribute("aria-hidden", "true");
    lightbox.style.display = "none";
    document.body.style.overflow = "";
  }

  function previousImage() {
    if (!images.length) return;
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    showCurrentImage();
  }

  function nextImage() {
    if (!images.length) return;
    currentIndex = (currentIndex + 1) % images.length;
    showCurrentImage();
  }

  function render(items) {
    if (!gallery) return;

    images = items;
    gallery.innerHTML = "";
    gallery.setAttribute("aria-busy", "false");

    if (!items.length) {
      gallery.innerHTML = '<p class="gallery-status">Det finns inga butiksbilder ännu.</p>';
      return;
    }

    items.forEach((item, index) => {
      // Samma kortstruktur som på Nyinkommet.
      const figure = document.createElement("figure");
      figure.className = "gallery-item nyinkommet-kort galleri-kort image-card-loading";

      const imageButton = document.createElement("button");
      imageButton.className = "nyinkommet-bildknapp";
      imageButton.type = "button";
      imageButton.setAttribute(
        "aria-label",
        item.title ? `Öppna ${item.title} i stort format` : "Öppna bilden i stort format"
      );
      imageButton.addEventListener("click", () => openLightbox(index));

      const image = document.createElement("img");
      image.src = imageUrl(item);
      image.alt = item.title || "Bild från Container 13 Vintage";
      image.loading = "lazy";
      image.decoding = "async";
      image.addEventListener("load", () => {
        figure.classList.remove("image-card-loading");
        figure.classList.add("image-card-loaded");
      });
      image.addEventListener("error", () => figure.remove());

      imageButton.appendChild(image);
      figure.appendChild(imageButton);
      gallery.appendChild(figure);
    });
  }

  async function loadGallery() {
    if (!gallery) return;
    const cached = getCachedGalleryData();
    if (!cached) {
      gallery.innerHTML = '<p class="gallery-status">Hämtar bilder...</p>';
    }

    const renderGalleryData = (json) => {
      const all = (json.documents || []).map((document) => ({
        id: document.name?.split("/").pop() || "",
        documentCreatedAt: document.createTime || "",
        ...fields(document.fields || {})
      }));

      const selected = all
        .filter((item) => category(item) === "galleri" && imageUrl(item))
        .sort((a, b) => time(b) - time(a));

      render(selected);
    };

    if (cached) {
      renderGalleryData(cached);
    }

    try {
      const fresh = await fetchFreshGalleryData();
      renderGalleryData(fresh);
    } catch (error) {
      console.error("Kunde inte hämta galleriet:", error);
      if (!cached) {
        gallery.setAttribute("aria-busy", "false");
        gallery.innerHTML = `<p class="gallery-status">Bilderna kunde inte hämtas just nu (${error.message}).</p>`;
      }
    }
  }

  closeButton?.addEventListener("click", closeLightbox);
  previousButton?.addEventListener("click", (event) => {
    event.stopPropagation();
    previousImage();
  });
  nextButton?.addEventListener("click", (event) => {
    event.stopPropagation();
    nextImage();
  });
  lightboxImage?.addEventListener("click", (event) => event.stopPropagation());
  lightbox?.addEventListener("click", (event) => {
    if (event.target === lightbox) closeLightbox();
  });

  document.addEventListener("keydown", (event) => {
    if (!lightbox?.classList.contains("active")) return;
    if (event.key === "Escape") closeLightbox();
    if (event.key === "ArrowLeft") previousImage();
    if (event.key === "ArrowRight") nextImage();
  });

  lightbox?.addEventListener("touchstart", (event) => {
    touchStartX = event.changedTouches[0].screenX;
  }, { passive: true });

  lightbox?.addEventListener("touchend", (event) => {
    const endX = event.changedTouches[0].screenX;
    if (touchStartX - endX > 50) nextImage();
    if (endX - touchStartX > 50) previousImage();
  }, { passive: true });

  loadGallery();
})();
