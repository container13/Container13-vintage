﻿# mops_dde_history_capability_probe_v37.ps1
# READ-ONLY capability discovery after confirmed DDE communication.
# Searches local WinMOPS/MOPS binaries/config for documented DDE command strings
# beyond open/print, especially history/tag/data commands.
# Does NOT send ExecuteDDE, Command.Execute, or Session.Open.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_DDE_HISTORY_CAPABILITY_PROBE_v37.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS DDE History Capability probe v3.7"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

S "KNOWN DDE REGISTRY"
foreach($root in @("Registry::HKEY_CLASSES_ROOT\WinMOPS.Document","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\WinMOPS.Document")){
 if(Test-Path $root){
  Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue | %{
   try{
    $v=(Get-Item $_.PSPath).GetValue("")
    if($v){L($_.PSPath+" | "+$v)}
   }catch{}
  }
 }
}

S "TARGETED TEXT SEARCH - LOCAL MOPS"
$roots=@("C:\Program Files (x86)\MOPS","C:\ProgramData\MOPS")
$patterns='ExecuteDDE|DDEHelper|ddeexec|TagHistory|BrowseTags|TagValue|HistoryStats|MOPS3iHistory'
foreach($r in $roots){
 if(!(Test-Path $r)){continue}
 Get-ChildItem $r -Recurse -File -ErrorAction SilentlyContinue |
  Where-Object {$_.Extension -match '^\.(xml|ini|cfg|config|txt|ps1|bat|cmd|reg|log)$'} |
  Select-Object -First 1500 | %{
   try{
    $m=Select-String -LiteralPath $_.FullName -Pattern $patterns -ErrorAction SilentlyContinue
    foreach($x in $m){L($_.FullName+" : "+$x.LineNumber+" : "+$x.Line.Trim())}
   }catch{}
  }
}

S "MOPS TYPELIBS / BINARIES"
Get-ChildItem "C:\Program Files (x86)\MOPS\sys\bin" -File -ErrorAction SilentlyContinue |
 Where-Object {$_.Name -match '(?i)wmtools|mportal|mqe|hist|mops3i|winmops'} | %{
   L($_.FullName+" | "+$_.VersionInfo.FileVersion)
 }

S "DDE HELPER STATE - NO COMMAND"
try{
 $d=New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
 L("IsWinMOPSRunning="+$d.IsWinMOPSRunning)
 L("IsInitialized="+$d.IsInitialized)
 L("WinMOPSExecPath="+$d.WinMOPSExecPath)
}catch{L("DDE helper FEL="+$_.Exception.Message)}

S "SUMMARY"
L "NO Initialize()"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
