MOPS MOPS3i TypeLib Scan v5.2

v51 visade att PowerShell Get-Member bara ser System.__ComObject-standardmedlemmar.
v52 går därför ett lager djupare och letar efter typbibliotek/TypeLib som hör till
MOPS3iHistory/MOPS3iSnapshot och mops3i.mcx.

Endast lokal registry- och filmetadata.
Ingen COM-körning, serveranslutning, login eller query.

Resultat skrivs direkt till:
C:\Users\<user>\Downloads\MOPS_MOPS3I_TYPELIB_SCAN_v52.txt
