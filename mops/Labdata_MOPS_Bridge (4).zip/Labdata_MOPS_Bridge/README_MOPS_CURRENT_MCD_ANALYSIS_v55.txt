MOPS current production MCD analysis v5.5

This package analyzes the MCD file the user said is currently run in production.
The analysis was performed directly on the uploaded file bytes; no WinMOPS, COM,
DDE, login, server query, Execute, Submit, Update or Write operation was used.

Most important result:
The current display contains a real MAccess object named MAccessMethod with:
?mqe.MDE_METHODS$BY_EPN(EPN='hist::22=3120=7210-B')

The selected MDEGrid tag is bound directly into MAccessMethod parameter EPN.

See MOPS_CURRENT_MCD_ANALYSIS_v55.txt for the extracted block and bindings.
