NYA MOPS – CHECKPOINT v0.57 / BRIDGE v15

ÄNDRING
- Endast layoutfix i Testmiljön.
- De sex testkorten är ca 20–25 % kompaktare genom mindre padding och vertikala mellanrum.
- Textstorleken är inte nedskalad.
- Råsvarsdelen får återstående höjd och det svarta råsvarsfältet hålls innanför den vita Testmiljö-panelen.
- Funktioner och Bridge är oförändrade.

HOLMEN – STARTA BRIDGE
cd "$env:USERPROFILE\Downloads\Labdata_MOPS_Bridge"
.\labdata_mops_bridge_v15_login_controls.ps1
