MOPS MCD Read-only Scan v5.3

Nästa steg efter v52.

Källa:
\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd

Syfte:
Läsa den befintliga MCD-filen binärt, helt read-only, och leta efter de
konfigurationsspår som WinMOPS själv kan ha sparat:
- MOPS3iHistory / MOPS3iSnapshot
- MAccess / CommandString
- DataNavigator
- TagHistory
- StartTime / EndTime / NumValues / Resolution
- OutputData / Parameters / Fields / Tags
- taggkandidater som börjar med 22=

Säkerhet:
- Ingen WinMOPS-start.
- Ingen DDE eller COM.
- Ingen serverquery eller login.
- Ingen Execute/Submit/Update/Write.
- MCD-filen kopieras eller ändras inte.
- Credential-liknande strängar filtreras bort från resultatet.

Resultat:
C:\Users\<user>\Downloads\MOPS_MCD_READONLY_SCAN_v53.txt
