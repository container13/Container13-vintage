NYA MOPS - TYPELIB/SESSIONSTRING CONTEXT v6.6
Datum: 2026-09-09

BAKGRUND
v6.5 visade att MOPS.Session.Open ansluter direkt till en serviceprovider,
att MOPS.Command har en Session-egenskap och att SessionString väljer
sessionens mål. Det exakta formatet och callback-/detach-kopplingen är ännu
inte verifierade.

SYFTE
Läsa registrerat MOPS-typbibliotek och ordnad strängkontext i mclient.dll för
att fastställa SessionString och callback/detach-semantik utan att gissa.

KÖRNING
Packa upp ZIP-filen och dubbelklicka:
start_mops_typelib_sessionstring_context_v66.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_TYPELIB_SESSIONSTRING_CONTEXT_v66.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
- endast lokal register- och filanalys
- inget COM-objekt skapas
- ingen Connection.Connect eller Session.Open
- ingen CommandText eller Execute
- ingen nätverksfråga, DDE eller MCD-ändring
- ingen Update/Insert/Delete/Write/Save

Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
