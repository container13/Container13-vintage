@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
set "PS1=%SCRIPT_DIR%mops_enable_print_copy_capture_v72.ps1"
if not exist "%PS1%" (
  echo HITTAR INTE: %PS1%
  pause
  exit /b 1
)
%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%PS1%"
echo.
pause
