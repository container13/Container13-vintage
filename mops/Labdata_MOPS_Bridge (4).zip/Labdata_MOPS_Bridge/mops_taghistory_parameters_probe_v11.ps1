﻿# MOPS TagHistory parameter probe v1.1 - READ ONLY
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_TAGHISTORY_PARAMETERS_PROBE_v11.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS TagHistory parameter probe v1.1"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Is64BitProcess="+[Environment]::Is64BitProcess)
$c=$null;$cmd=$null;$p=$null
try{
 L "1. Connection"
 $c=New-Object -ComObject "MOPS.Connection"; $c.ConnectionString="//HOIGIBMOCLAP12/"; $c.Connect()
 L ("IsConnected="+$c.IsConnected)
 L "2. Command"
 $cmd=New-Object -ComObject "MOPS.Command"; $cmd.Connection=$c
 L "3. ServiceName=History"
 try{$cmd.ServiceName="History";L "OK"}catch{L ("FEL="+$_.Exception.Message)}
 L "4. FunctionName=TagHistory"
 try{$cmd.FunctionName="TagHistory";L "OK"}catch{L ("FEL="+$_.Exception.Message)}
 L "5. Parameters"
 try{
   $p=$cmd.Parameters
   $p | Get-Member | Sort-Object MemberType,Name | ForEach-Object {L ($_.MemberType+" "+$_.Name+" :: "+$_.Definition)}
 }catch{L ("FEL="+$_.Exception.Message)}
 L "6. Count"
 try{L ("Count="+$p.Count)}catch{L ("FEL="+$_.Exception.Message)}
 L "7. Enumerering"
 try{
   $n=0
   foreach($x in $p){
     $n++
     try{L ("PARAM "+$n+" Name="+$x.Name)}catch{L ("PARAM "+$n+" Name=<FEL>")}
     try{L ("Value="+[string]$x.Value)}catch{L "Value=<FEL>"}
     try{$x|Get-Member|Sort-Object MemberType,Name|ForEach-Object{L (" MEMBER "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{}
   }
   if($n -eq 0){L "<inga parametrar enumererades>"}
 }catch{L ("FEL="+$_.Exception.Message)}
 L "KLAR - Execute() anropades INTE."
}catch{L ("OVANTAT FEL="+$_.Exception.Message)}
finally{
 if($null-ne $cmd){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd)}catch{}}
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY. Ingen Execute(), login eller skrivning."
L ("Output="+$out)
