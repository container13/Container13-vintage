﻿# MOPS hist functions probe v1.4 - READ ONLY
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_HIST_FUNCTIONS_PROBE_v14.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS hist functions probe v1.4"
$c=$null
try{
 $c=New-Object -ComObject "MOPS.Connection";$c.ConnectionString="//HOIGIBMOCLAP12/";$c.Connect()
 L ("IsConnected="+$c.IsConnected)
 $services=$c.Browser.Services
 $hist=$null
 foreach($svc in $services){if($svc.Name -eq "hist"){$hist=$svc;break}}
 if($null-eq $hist){L "FEL: hist hittades inte";return}
 L "hist hittad"
 L "-- hist Get-Member (utan Sort-Object Name-konflikt) --"
 try{$hist|Get-Member|ForEach-Object{L ($_.MemberType.ToString()+" "+$_.Name+" :: "+$_.Definition)}}catch{L ("FEL="+$_.Exception.Message)}
 L "-- hist.Functions --"
 try{
   $funcs=$hist.Functions
   if($null-eq $funcs){L "Functions=<null>"}
   else{
     try{L ("Functions.Count="+$funcs.Count)}catch{L ("Count FEL="+$_.Exception.Message)}
     try{$funcs|Get-Member|ForEach-Object{L ("FMEMBER "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{L ("Functions Get-Member FEL="+$_.Exception.Message)}
     $n=0
     foreach($f in $funcs){
       $n++;L ("FUNCTION #"+$n)
       foreach($p in @("Name","Description")){
         try{L (" "+$p+"="+[string]$f.$p)}catch{}
       }
       try{$f|Get-Member|ForEach-Object{L (" MEMBER "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{L (" member FEL="+$_.Exception.Message)}
     }
     L ("Functions enumerated="+$n)
   }
 }catch{L ("hist.Functions FEL="+$_.Exception.Message)}
 L "KLAR"
}catch{L ("OVANTAT FEL="+$_.Exception.Message)}
finally{
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY. Ingen Execute(), login eller skrivning."
L ("Output="+$out)
