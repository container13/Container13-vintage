Labdata MOPS Bridge v31 / bridge v0.7

Filer:
  labdata_mops_bridge_v07.ps1
  labdata_mops_bryggtest_v31.html

Syfte:
  Läsa exakt IDispatch type-info från MOPS.Command.Parameters.
  Visar metodnamn och parameterlistor utan att köra TagHistory.

Read-only:
  Ja. Ingen Execute, write, update eller delete.
