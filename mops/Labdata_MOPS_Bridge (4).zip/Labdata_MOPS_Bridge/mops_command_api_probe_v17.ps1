﻿# MOPS Command API probe v1.7 - READ ONLY
# Inspects exact MOPS.Command methods/properties and parameter collection API.
# No Execute(), no login, no writes.
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_COMMAND_API_PROBE_v17.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS Command API probe v1.7"
$c=$null;$cmd=$null
try{
 $c=New-Object -ComObject "MOPS.Connection";$c.ConnectionString="//HOIGIBMOCLAP12/";$c.Connect()
 L ("IsConnected="+$c.IsConnected)
 $cmd=New-Object -ComObject "MOPS.Command";$cmd.Connection=$c
 $cmd.ServiceName="hist";$cmd.FunctionName="TagHistory"
 L "ServiceName=hist"
 L "FunctionName=TagHistory"

 L "-- MOPS.Command exact members --"
 try{$cmd|Get-Member|ForEach-Object{L ($_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{L ("FEL="+$_.Exception.Message)}

 L "-- Parameters exact members --"
 try{
   $p=$cmd.Parameters
   L ("Parameters null="+($null-eq $p))
   if($null-ne $p){
     $p|Get-Member|ForEach-Object{L ($_.MemberType+" "+$_.Name+" :: "+$_.Definition)}
     try{L ("Count="+$p.Count)}catch{}
   }
 }catch{L ("Parameters FEL="+$_.Exception.Message)}

 L "-- Browser parameter definition collection exact members --"
 try{
   $hist=$null;foreach($s in $c.Browser.Services){if($s.Name -eq "hist"){$hist=$s;break}}
   $th=$null;foreach($f in $hist.Functions){if($f.Name -eq "TagHistory"){$th=$f;break}}
   $bp=$th.Parameters
   $bp|Get-Member|ForEach-Object{L ("BROWSER "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)}
 }catch{L ("Browser parameters FEL="+$_.Exception.Message)}

 L "KLAR - Execute() anropades INTE."
}catch{L ("OVANTAT FEL="+$_.Exception.Message)}
finally{
 if($null-ne $cmd){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd)}catch{}}
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY. Ingen Execute(), login eller skrivning."
L ("Output="+$out)
