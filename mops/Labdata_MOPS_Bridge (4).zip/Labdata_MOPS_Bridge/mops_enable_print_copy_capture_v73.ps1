﻿$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_ENABLE_PRINT_COPY_CAPTURE_v73.txt'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function FindBytes([byte[]]$hay,[byte[]]$needle,[int]$start=0){
  for($i=$start;$i-le$hay.Length-$needle.Length;$i++){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if($hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
function FindBytesReverse([byte[]]$hay,[byte[]]$needle,[int]$start){
  for($i=$start;$i-ge0;$i--){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if(($i+$j)-ge$hay.Length-or$hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
try{
  Add-Type -AssemblyName System.Windows.Forms
  $source='\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd'
  $expected='ACE84824DD638BCEEE1DFA5EF993CC93790FC7AE5F35B51674A20D7733405DEB'
  $work=Join-Path $env:USERPROFILE 'Downloads\Labdata_MOPS_Bridge'
  $copy=Join-Path $work 'Manuell labdata Alt1_PRINT_COPY_TEST_v73.mcd'

  L 'MOPS Enable Print + Copy Capture v7.3'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('ApartmentState='+[Threading.Thread]::CurrentThread.ApartmentState)
  L ('Source='+$source)
  L ('TestCopy='+$copy)

  if(-not(Test-Path -LiteralPath $source)){throw 'Produktions-MCD kunde inte läsas från nätverkssökvägen.'}
  $sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
  L ('SourceSHA256='+$sourceHash)
  if($sourceHash-ne$expected){throw ('Fel källversion. Förväntade '+$expected+' men fick '+$sourceHash+'. Ingen kopia skapades.')}

  New-Item -ItemType Directory -Path $work -Force|Out-Null
  [byte[]]$original=[IO.File]::ReadAllBytes($source)
  [byte[]]$bytes=$original.Clone()
  [byte[]]$nameNeedle=[Text.Encoding]::ASCII.GetBytes('(Name "Button_Print")')
  $nameOffset=FindBytes $bytes $nameNeedle 0
  if($nameOffset-lt0){throw 'Button_Print hittades inte.'}
  $secondName=FindBytes $bytes $nameNeedle ($nameOffset+1)
  if($secondName-ge0){throw 'Button_Print förekommer mer än en gång; avbryter.'}
  [byte[]]$valueNeedle=[Text.Encoding]::ASCII.GetBytes('(Visible 0)')
  $valueOffset=FindBytesReverse $bytes $valueNeedle $nameOffset
  if($valueOffset-lt0-or$valueOffset-lt($nameOffset-300)){throw 'Tillhörande Visible 0 hittades inte inom säkert intervall före Button_Print.'}
  $digitOffset=$valueOffset+9
  if($bytes[$digitOffset]-ne[byte][char]'0'){throw 'Kontrollbyten innehåller inte 0; avbryter.'}
  $bytes[$digitOffset]=[byte][char]'1'
  [IO.File]::WriteAllBytes($copy,$bytes)
  L ('PatchObject=Button_Print.Visible')
  L ('PatchOffset='+$digitOffset)
  L 'Patch=0 -> 1'

  [byte[]]$verify=[IO.File]::ReadAllBytes($copy)
  $diffs=0;$lastDiff=-1
  for($i=0;$i-lt$bytes.Length;$i++){if($original[$i]-ne$verify[$i]){$diffs++;$lastDiff=$i}}
  L ('VerifiedDifferentBytes='+$diffs)
  L ('VerifiedDiffOffset='+$lastDiff)
  if($diffs-ne1-or$lastDiff-ne$digitOffset){throw 'Kopian skiljer sig inte med exakt den avsedda byten.'}
  L ('TestCopySHA256='+(Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash)

  L ''
  L '===== OPEN LOCAL COPY ====='
  Start-Process -FilePath $copy
  L 'OpenRequested=Shell open of local copy (WinMOPS file association)'

  Write-Host ''
  Write-Host 'DEN LOKALA TESTKOPIAN ÖPPNAS NU I WINMOPS.' -ForegroundColor Yellow
  Write-Host '1. Vänta tills tabellen och riktiga värden syns.'
  Write-Host '2. Leta efter knappen PRINT uppe till höger ovanför tabellen.'
  Write-Host '3. Klicka PRINT en gång. Excel kan öppnas av WinMOPS normala funktion.'
  Write-Host '4. Gå tillbaka hit utan att kopiera något annat.'
  [void](Read-Host 'Tryck ENTER här efter att du klickat PRINT')

  L ''
  L '===== CLIPBOARD AFTER WINMOPS PRINT ====='
  L ('CaptureTime='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $data=[Windows.Forms.Clipboard]::GetDataObject()
  if(-not$data){throw 'Urklipp är tomt.'}
  $formats=@($data.GetFormats($false))
  L ('Formats='+($formats-join' | '))
  foreach($format in $formats){
    L ''
    L ('--- FORMAT: '+$format+' ---')
    try{
      $v=$data.GetData($format,$false)
      if($null-eq$v){L 'Value=<null>'}
      elseif($v-is[string]){L ('Length='+$v.Length);L 'BEGIN_TEXT';L $v;L 'END_TEXT'}
      elseif($v-is[IO.MemoryStream]){L ('MemoryStreamLength='+$v.Length)}
      elseif($v-is[byte[]]){L ('ByteLength='+$v.Length)}
      else{L ('Type='+$v.GetType().FullName);L ('Value='+[string]$v)}
    }catch{L ('FormatReadError='+$_.Exception.Message)}
  }
  try{
    $text=[Windows.Forms.Clipboard]::GetText([Windows.Forms.TextDataFormat]::UnicodeText)
    $lines=@($text-split"`r?`n")
    L ''
    L ('UnicodeTextLength='+$text.Length)
    L ('LineCount='+$lines.Count)
    $tabs=0;foreach($line in $lines){$tabs+=[regex]::Matches($line,"`t").Count};L ('TabCount='+$tabs)
  }catch{L ('TextShapeError='+$_.Exception.Message)}

  L ''
  L '===== SAFETY ====='
  L 'Production MCD hash verified and production file left unchanged.'
  L 'A local copy was created; exactly one byte changed: Button_Print.Visible 0 -> 1.'
  L 'Only shell-open of the local copy was requested; no save command.'
  L 'WinMOPS performed its existing Print/DoCopyAll action.'
  L 'No new MOPS COM connection, Execute, Session.Open, DDE command, or write to MDE.'
  L 'No Update/Insert/Delete/Write/Save.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
}finally{L ('Output='+$out)}
Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
