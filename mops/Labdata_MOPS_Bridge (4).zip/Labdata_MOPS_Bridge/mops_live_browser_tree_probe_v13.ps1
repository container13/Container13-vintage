﻿# MOPS live browser tree probe v1.3 - READ ONLY
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_LIVE_BROWSER_TREE_PROBE_v13.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
function M($o,[string]$label){
 L ("-- "+$label+" --")
 try{$o|Get-Member|Sort-Object MemberType,Name|ForEach-Object{L ($_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{L ("FEL="+$_.Exception.Message)}
}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS live browser tree probe v1.3"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
$c=$null
try{
 L "1. Connection"
 $c=New-Object -ComObject "MOPS.Connection";$c.ConnectionString="//HOIGIBMOCLAP12/";$c.Connect()
 L ("IsConnected="+$c.IsConnected)
 $b=$c.Browser
 L "2. Connection.Browser"
 try{L ("Name="+$b.Name)}catch{L ("Name FEL="+$_.Exception.Message)}
 try{L ("Node="+$b.Node)}catch{L ("Node FEL="+$_.Exception.Message)}
 try{L ("Enabled="+$b.Enabled)}catch{L ("Enabled FEL="+$_.Exception.Message)}

 L "3. Browser.Services (live child object)"
 try{
   $s=$b.Services
   if($null-eq $s){L "Services=<null>"}else{
     M $s "Services Get-Member"
     try{L ("Services.Count="+$s.Count)}catch{L ("Services.Count FEL="+$_.Exception.Message)}
     try{
       $n=0
       foreach($x in $s){
         $n++; L ("SERVICE #"+$n)
         foreach($p in @("Name","ServiceName","Description","Enabled","Node")){
           try{L (" "+$p+"="+[string]$x.$p)}catch{}
         }
         M $x ("Service #"+$n+" members")
         if($n -ge 50){break}
       }
       L ("Services enumerated="+$n)
     }catch{L ("Services enumeration FEL="+$_.Exception.Message)}
   }
 }catch{L ("Browser.Services FEL="+$_.Exception.Message)}

 L "4. Browser.Namespaces (live child object)"
 try{
   $ns=$b.Namespaces
   if($null-eq $ns){L "Namespaces=<null>"}else{
     M $ns "Namespaces Get-Member"
     try{L ("Namespaces.Count="+$ns.Count)}catch{L ("Namespaces.Count FEL="+$_.Exception.Message)}
   }
 }catch{L ("Browser.Namespaces FEL="+$_.Exception.Message)}

 L "KLAR"
}catch{L ("OVANTAT FEL="+$_.Exception.Message)}
finally{
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY. Ingen Execute(), login eller skrivning."
L ("Output="+$out)
