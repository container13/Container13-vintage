NYA MOPS HOLMEN – CHECKPOINT v0.61
Datum: 2026-09-09

BAS
- Byggd direkt från v0.60 som var godkänd på både 13" och 24".
- v0.60:s responsiva höjd och adaptiva datumetikett är kvar.

ÄNDRING v0.61 – ENDAST BLEKERI 4
- Fixar att Blekeri 4 kunde återgå till den gamla säkerhetsbredden 46 px per
  mätkolumn efter ett vybyte, trots att fitWideTableToWorkspace() fanns.
- Orsak: render() återställde Blekeri 4 till 46 px, men den responsiva
  omräkningen kördes främst vid start/resize/navigatorändring.
- Nu körs fitWideTableToWorkspace() på nytt efter varje render av den breda
  Blekeri 4-tabellen, inklusive ett andra pass när header/rader är på plats.
- Tabellen använder därmed aktuell table-wrap/clientWidth:
  större fönster -> bredare kolumner och hela arbetsytan utnyttjas,
  mindre fönster -> kompaktare kolumner,
  mycket smalt -> läsbar minbredd + befintlig scroll.

UTTRYCKLIGEN INTE ÄNDRAT
- Kokeri 3
- Blekeri 3
- Kokeri 4
- Syrgasblekeri 4
- Kem-beredning
- datainnehåll
- taggregister
- MOPS-/bridge-/loginlogik
- editera/spara-logik
- DIAG_HTML_VERSION (fortsatt 0.57 eftersom protokollet inte ändrats)

FÖREGÅENDE VERSION
- v0.60
