MOPS MDE Service Contract probe v6.0

Syfte:
Kartlägga metadata för den MOPS-service som den aktiva MDEGrid-vyn använder:
MDESPName=mde.

Bakgrund:
- v53-v58 visar att den aktiva labbdatavyn använder MDEGrid.mcx.
- MDEGrid.Parameters.MDESPName = mde.
- MDE Reference Manual säger att MDESPName är namnet på den MDESP-instans
  som MDE Client kommunicerar med.
- Tidigare v29 visade att servicebrowsern ser tjänsten "mde".

v60:
- ansluter MOPS.Connection till //HOIGIBMOCLAP12/
- använder endast servicebrowser-metadata
- hittar service "mde"
- listar dess funktionsnamn
- för läs/relevanta kandidater listas endast parameter- och fältschema
- funktioner med Update/Insert/Delete/Write/Save-liknande namn markeras och körs aldrig

INGEN servicefunktion exekveras.
INGEN Session.Open.
INGEN DDE.
INGEN skrivning.

Resultat:
C:\Users\<user>\Downloads\MOPS_MDE_SERVICE_CONTRACT_v60.txt
