NYA MOPS - WINMOPS WINDOW CAPTURE v8.0
Datum: 2026-09-09

SYFTE
Fanga den vanliga fungerande WinMOPS-vyn som PNG utan Print, Urklipp,
Excel eller andring av MCD. Bilden anvands for att prova stabil avlasning av
det fasta rutnatets rubriker, datum, tider och varden.

KORNING
1. Oppna vanliga WinMOPS och navigera till en avdelning.
2. Vanta tills tabellen och riktiga varden syns.
3. Packa upp ZIP-filen och dubbelklicka start_mops_winmops_window_capture_v80.bat.
4. Tryck Enter i svarta fonstret nar tabellen ar klar.
5. Byt direkt tillbaka till WinMOPS under nedrakningen pa atta sekunder.
6. Lat WinMOPS ligga overst tills bilden tagits.
7. Skicka bada filerna till ChatGPT:

C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_WINDOW_v80.png
C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_WINDOW_CAPTURE_v80.txt

SAKERHET
- Ingen MCD oppnas, kopieras, andras eller sparas av testet.
- Ingen MOPS COM-session, Execute, Session.Open eller skrivning till MDE.
- Ingen anvandning av Print eller Urklipp.
- Endast synliga bildpunkter fran det aktiva WinMOPS-fonstret sparas.
