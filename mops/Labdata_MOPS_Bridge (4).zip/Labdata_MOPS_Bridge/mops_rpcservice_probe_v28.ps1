﻿# mops_rpcservice_probe_v28.ps1
# READ-ONLY: kartlägger RPCService/PQS och relaterad MOPS-konfiguration.
# Ingen Execute(), Session.Open(), credential-sättning eller MOPS-skrivning.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_RPCSERVICE_PROBE_v28.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function Sensitive([string]$s){$s -match '(?i)pass(word)?|pwd|secret|token|credential|hash|salt|private.?key'}
function Safe([string]$s){if(Sensitive $s){"<REDACTED SENSITIVE LINE>"}else{$s}}

Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS RPCService probe v2.8"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

$glb="\\hoigibmoclap12.holmen.net\WinMOPS\Config\mopsglb.xml"

S "RPCSERVICE XML BLOCK"
if(Test-Path $glb){
 try{
  [xml]$x=Get-Content $glb -Raw
  $rpc=$x.config.RPCService
  if($rpc){
   foreach($p in $rpc.ChildNodes){L($p.Name+"="+(Safe ([string]$p.InnerText)))}
  }else{L "<RPCService not found>"}
 }catch{L("FEL="+$_.Exception.Message)}
}

S "SERVER SHARE TOP-LEVEL"
$roots=@("\\hoigibmoclap12.holmen.net\WinMOPS\Config","\\hoigibmoclap12.holmen.net\WinMOPS")
foreach($r in $roots){
 L("ROOT "+$r+" Exists="+(Test-Path $r))
 if(Test-Path $r){
  try{
   Get-ChildItem $r -Force -ErrorAction Stop|Sort-Object Name|Select-Object -First 120|%{
    if($_.PSIsContainer){L("DIR  "+$_.Name+" | "+$_.LastWriteTime)}
    else{L("FILE "+$_.Name+" | "+$_.Length+" | "+$_.LastWriteTime)}
   }
  }catch{L("LIST FEL="+$_.Exception.Message)}
 }
}

S "TARGETED CONFIG SEARCH"
$patterns=@("PQS","mqe","RPCService","MHISTSP","hist","TagHistory","TagBroker","MPORTAL","callback","MOPSCallbackUser")
$roots2=@("\\hoigibmoclap12.holmen.net\WinMOPS\Config","C:\ProgramData\MOPS")
$seen=0
foreach($r in $roots2){
 if(!(Test-Path $r)){continue}
 Get-ChildItem $r -Recurse -File -ErrorAction SilentlyContinue|
  Where-Object {$_.Length -lt 3MB -and $_.Extension -match '(?i)\.(xml|ini|cfg|conf|config|txt)$'}|
  ForEach-Object{
   if($seen -ge 220){return}
   try{
    $h=@(Select-String $_.FullName -SimpleMatch -Pattern $patterns -ErrorAction Stop|Select-Object -First 30)
    if($h){
     L("FILE "+$_.FullName)
     foreach($m in $h){
      L("  L"+$m.LineNumber+": "+(Safe $m.Line.Trim()))
      $seen++;if($seen-ge 220){break}
     }
    }
   }catch{}
  }
}

S "MOPS PROCESSES/SERVICES"
Get-Process -ErrorAction SilentlyContinue|Where-Object {$_.ProcessName -match '(?i)mops|mqe|portal|hist|broker'}|%{
 $pth="";try{$pth=$_.Path}catch{}
 L("PROC "+$_.ProcessName+" PID="+$_.Id+" Session="+$_.SessionId+" Path="+$pth)
}
try{
 Get-CimInstance Win32_Service -ErrorAction Stop|Where-Object {$_.Name -match '(?i)mops|mqe|portal|hist|broker' -or $_.DisplayName -match '(?i)mops|mqe|portal|hist|broker'}|%{
  L("SERVICE "+$_.Name+" | State="+$_.State+" | StartName="+$_.StartName+" | Path="+$_.PathName)
 }
}catch{L("Service scan FEL="+$_.Exception.Message)}

S "DNS / RPC ENDPOINT MAPPER"
$hostn="hoigibmoclap12.holmen.net"
try{L("IPs="+(([Net.Dns]::GetHostAddresses($hostn)|%{$_.IPAddressToString})-join ", "))}catch{}
foreach($port in @(135,445)){
 try{
  $t=New-Object Net.Sockets.TcpClient
  $a=$t.BeginConnect($hostn,$port,$null,$null)
  $ok=$a.AsyncWaitHandle.WaitOne(1500,$false)
  if($ok -and $t.Connected){$t.EndConnect($a);L("$hostn`:$port reachable=True")}else{L("$hostn`:$port reachable=False")}
  $t.Close()
 }catch{L("$hostn`:$port FEL="+$_.Exception.Message)}
}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
