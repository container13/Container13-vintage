﻿# mops_session_rpc_context_probe_v23.ps1
# READ-ONLY. Jämför WinMOPS-processens nät-/sessionspår med en fristående MOPS.Connection.
#
# VIKTIGT:
# - INGEN Command.Execute()
# - INGEN Session.Open()
# - INGEN login/credentials sätts
# - INGEN skrivning till MOPS-data
# - Läser endast process-, nät-, COM- och browsermetadata.

$ErrorActionPreference = "Continue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_SESSION_RPC_CONTEXT_PROBE_v23.txt"

function L([string]$s="") {
    Add-Content -LiteralPath $out -Value $s -Encoding UTF8
}

function S([string]$s) {
    L ""
    L ("===== " + $s + " =====")
}

function SafeVal($obj,[string]$name) {
    try {
        $v = $obj.$name
        if ($null -eq $v) { return "<null>" }
        return [string]$v
    } catch {
        return "<ERROR: $($_.Exception.Message)>"
    }
}

function DumpMembers($obj,[string]$prefix="") {
    if ($null -eq $obj) {
        L ($prefix + "<null>")
        return
    }
    try {
        $obj.PSObject.Members |
            Sort-Object MemberType,Name |
            ForEach-Object {
                L ($prefix + $_.MemberType + " " + $_.Name + " :: " + $_.Definition)
            }
    } catch {
        L ($prefix + "Member dump FEL=" + $_.Exception.Message)
    }
}

function Redact([string]$s) {
    if ($null -eq $s) { return "" }
    if ($s -match '(?i)password|passwd|pwd|secret|token') {
        return "<REDACTED LINE>"
    }
    return $s
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

$c = $null
$session = $null
$cmd = $null

try {
    L "MOPS Session/RPC context probe v2.3"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("COMPUTERNAME=" + $env:COMPUTERNAME)
    L ("WindowsUser=" + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ("PowerShell=" + $PSVersionTable.PSVersion)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

    S "WINMOPS PROCESS"
    $wps = @(Get-Process winmops -ErrorAction SilentlyContinue)
    if ($wps.Count -eq 0) {
        L "winmops process=<not running>"
    } else {
        foreach ($p in $wps) {
            L ("PID=" + $p.Id)
            try { L ("Path=" + $p.Path) } catch { L "Path=<unavailable>" }
            try { L ("SessionId=" + $p.SessionId) } catch {}
            try { L ("StartTime=" + $p.StartTime) } catch {}
            try { L ("MainWindowTitle=" + $p.MainWindowTitle) } catch {}
            L "-- Relevant loaded modules --"
            try {
                $p.Modules |
                    Where-Object { $_.ModuleName -match '(?i)mops|mde|rpc|portal|broker|hist' } |
                    Sort-Object ModuleName -Unique |
                    ForEach-Object { L ("MODULE " + $_.ModuleName + " | " + $_.FileName) }
            } catch {
                L ("Module enumeration FEL=" + $_.Exception.Message)
            }
        }
    }

    S "WINMOPS TCP CONNECTIONS"
    foreach ($p in $wps) {
        L ("-- PID " + $p.Id + " --")
        $got = $false
        try {
            $conns = @(Get-NetTCPConnection -OwningProcess $p.Id -ErrorAction Stop |
                Sort-Object State,RemoteAddress,RemotePort)
            if ($conns.Count -gt 0) {
                $got = $true
                foreach ($t in $conns) {
                    L ("TCP Local={0}:{1} Remote={2}:{3} State={4}" -f
                        $t.LocalAddress,$t.LocalPort,$t.RemoteAddress,$t.RemotePort,$t.State)
                }
            }
        } catch {
            L ("Get-NetTCPConnection unavailable/denied: " + $_.Exception.Message)
        }

        if (-not $got) {
            try {
                netstat -ano -p tcp 2>$null |
                    Select-String ("\s" + $p.Id + "\s*$") |
                    ForEach-Object { L ("NETSTAT " + $_.Line.Trim()) }
            } catch {
                L ("netstat FEL=" + $_.Exception.Message)
            }
        }
    }

    S "MOPS CONNECTION"
    try {
        $c = New-Object -ComObject "MOPS.Connection.1"
        $c.ConnectionString = "//HOIGIBMOCLAP12/"
        $c.Connect()

        foreach ($n in @(
            "IsConnected",
            "ConnectionString",
            "TagBroker",
            "ServerTime",
            "ConnectionErrorState"
        )) {
            L ($n + "=" + (SafeVal $c $n))
        }

        L "-- Connection.UserIdentity --"
        try {
            $ui = $c.UserIdentity
            if ($null -eq $ui) {
                L "UserIdentity=<null>"
            } else {
                DumpMembers $ui "UI "
                foreach ($n in @("UserName","Username","Name","Domain","Identity","Authenticated")) {
                    L ("UI."+ $n +"=" + (SafeVal $ui $n))
                }
            }
        } catch {
            L ("UserIdentity FEL=" + $_.Exception.Message)
        }

        L "-- Connection.AuxiliaryParameters --"
        try {
            $ap = $c.AuxiliaryParameters
            L ("Aux.Count=" + (SafeVal $ap "Count"))
            L ("Aux.ParametersText=" + (SafeVal $ap "ParametersText"))
        } catch {
            L ("AuxiliaryParameters FEL=" + $_.Exception.Message)
        }
    } catch {
        L ("Connection FEL=" + $_.Exception.Message)
    }

    S "SERVICE BROWSER / HIST"
    if ($c -ne $null) {
        try {
            $b = $c.Browser
            $b.Refresh()
            L "Browser.Refresh=OK"

            $services = @($b.Services)
            L ("ServiceCount=" + $services.Count)

            foreach ($svc in $services) {
                $name = SafeVal $svc "Name"
                L ("SERVICE " + $name)
                if ($name -match '(?i)^hist$|history') {
                    L "-- HIST service members --"
                    DumpMembers $svc "HIST "
                    foreach ($n in @("Name","DisplayName","Description","Type","Context","Server","Host")) {
                        L ("HIST."+ $n +"=" + (SafeVal $svc $n))
                    }

                    try {
                        $funcs = @($svc.Functions)
                        L ("HIST.FunctionCount=" + $funcs.Count)
                        foreach ($f in $funcs) {
                            $fn = SafeVal $f "Name"
                            if ($fn -match '(?i)TagHistory|History') {
                                L ("HIST FUNCTION " + $fn)
                                foreach ($n in @("Name","DisplayName","Description","Type","Context","Server","Host")) {
                                    L ("  "+$n+"=" + (SafeVal $f $n))
                                }
                            }
                        }
                    } catch {
                        L ("HIST Functions FEL=" + $_.Exception.Message)
                    }
                }
            }
        } catch {
            L ("Browser FEL=" + $_.Exception.Message)
        }
    }

    S "COMMAND CONTEXT - NO EXECUTE"
    if ($c -ne $null) {
        try {
            $cmd = New-Object -ComObject "MOPS.Command.1"
            $cmd.Connection = $c
            $cmd.ServiceName = "hist"
            $cmd.FunctionName = "TagHistory"

            foreach ($n in @(
                "ServiceName",
                "FunctionName",
                "Context",
                "CommandText",
                "CommandType",
                "MaxRows",
                "PageSize",
                "Sort"
            )) {
                L ("CMD."+ $n +"=" + (SafeVal $cmd $n))
            }

            L ("CMD.Connection.IsConnected=" + (SafeVal $cmd.Connection "IsConnected"))

            try {
                $cs = $cmd.Session
                if ($null -eq $cs) {
                    L "CMD.Session=<null>"
                } else {
                    L "CMD.Session=<object>"
                    foreach ($n in @("IsOpen","SessionString","SessionErrorState")) {
                        L ("CMD.Session."+ $n +"=" + (SafeVal $cs $n))
                    }
                }
            } catch {
                L ("CMD.Session FEL=" + $_.Exception.Message)
            }
        } catch {
            L ("Command FEL=" + $_.Exception.Message)
        }
    }

    S "NEW SESSION CONTEXT - NO OPEN"
    if ($c -ne $null) {
        try {
            $session = New-Object -ComObject "MOPS.Session.1"
            $session.Connection = $c
            foreach ($n in @("IsOpen","SessionString","SessionErrorState")) {
                L ("SESSION."+ $n +"=" + (SafeVal $session $n))
            }

            try {
                $sui = $session.UserIdentity
                if ($null -eq $sui) {
                    L "SESSION.UserIdentity=<null>"
                } else {
                    DumpMembers $sui "SUI "
                    foreach ($n in @("UserName","Username","Name","Domain","Identity","Authenticated")) {
                        L ("SUI."+ $n +"=" + (SafeVal $sui $n))
                    }
                }
            } catch {
                L ("SESSION.UserIdentity FEL=" + $_.Exception.Message)
            }
        } catch {
            L ("Session creation FEL=" + $_.Exception.Message)
        }
    }

    S "CONFIG HINTS - READ ONLY / REDACTED"
    $roots = @(
        "C:\Program Files (x86)\MOPS",
        "$env:APPDATA",
        "$env:LOCALAPPDATA"
    )
    $patterns = @("HOIGIBMOCLAP12","TagBroker","hist","rpc","mportal","session")
    $seen = 0

    foreach ($root in $roots) {
        if (-not (Test-Path $root)) { continue }

        try {
            Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.Length -lt 2MB -and
                    $_.Extension -match '(?i)\.(ini|cfg|conf|config|xml|txt)$'
                } |
                ForEach-Object {
                    if ($seen -ge 80) { return }
                    try {
                        $hits = Select-String -LiteralPath $_.FullName -SimpleMatch -Pattern $patterns -ErrorAction Stop |
                            Select-Object -First 8
                        if ($hits) {
                            L ("FILE " + $_.FullName)
                            foreach ($h in $hits) {
                                L ("  L"+$h.LineNumber+": "+(Redact $h.Line.Trim()))
                                $seen++
                                if ($seen -ge 80) { break }
                            }
                        }
                    } catch {}
                }
        } catch {}
    }

    S "SUMMARY"
    L "NO Execute()"
    L "NO Session.Open()"
    L "NO credentials set"
    L "NO MOPS data write"
}
catch {
    L ("TOPLEVEL FEL=" + $_.Exception.Message)
}
finally {
    if ($c -ne $null) {
        try {
            $c.Disconnect()
            L "Disconnect=OK"
        } catch {
            L ("Disconnect FEL=" + $_.Exception.Message)
        }
    }

    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
