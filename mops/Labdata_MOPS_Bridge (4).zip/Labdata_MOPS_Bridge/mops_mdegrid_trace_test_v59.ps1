﻿$ErrorActionPreference = "Stop"

$src = "\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd"
$work = Join-Path $env:USERPROFILE "Downloads\Labdata_MOPS_Bridge"
$copy = Join-Path $work "Manuell labdata Alt1_TRACE_v59.mcd"
$result = Join-Path $env:USERPROFILE "Downloads\MOPS_MDEGRID_TRACE_RESULT_v59.txt"
$trace = "C:\temp\winmops\mdegrid.txt"
$expectedSha = "ACE84824DD638BCEEE1DFA5EF993CC93790FC7AE5F35B51674A20D7733405DEB"

function L([string]$s=""){ Add-Content -Path $result -Value $s -Encoding UTF8 }
function Fail([string]$s){
    L ("ERROR=" + $s)
    Write-Host $s -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory -Force -Path $work | Out-Null
Remove-Item $result -ErrorAction SilentlyContinue

L "MOPS MDEGrid Trace Test v5.9"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Source=" + $src)
L ("TestCopy=" + $copy)
L ("TraceFile=" + $trace)
L ""

if(-not (Test-Path -LiteralPath $src)){ Fail "Hittar inte käll-MCD." }

$sha=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
L ("SourceSHA256=" + $sha)
if($sha -ne $expectedSha){
    Fail "Källfilens SHA256 stämmer inte med den MCD vi analyserade. Avbryter utan ändring."
}

[byte[]]$b=[IO.File]::ReadAllBytes($src)
$ascii=[Text.Encoding]::ASCII.GetString($b)
$needle="(TraceCalculations 0)"
$idx=$ascii.IndexOf($needle,[StringComparison]::Ordinal)
if($idx -lt 0){ Fail "Hittar inte exakt '(TraceCalculations 0)' i källfilen." }
if($ascii.IndexOf($needle,$idx+1,[StringComparison]::Ordinal) -ge 0){
    Fail "Fler än en TraceCalculations-träff. Avbryter."
}

# Ändra ENDAST tecknet 0 -> 1 i testkopians bytearray.
$zeroPos=$idx + $needle.IndexOf("0")
$before=$b[$zeroPos]
if($before -ne [byte][char]'0'){ Fail "Förväntad byte är inte 0. Avbryter." }
$b[$zeroPos]=[byte][char]'1'

[IO.File]::WriteAllBytes($copy,$b)
$copySha=(Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash
L ("TracePatchOffset=" + $zeroPos)
L ("ChangedBytes=1")
L ("TestCopySHA256=" + $copySha)

# Verifiera att bara en byte skiljer sig.
[byte[]]$orig=[IO.File]::ReadAllBytes($src)
[byte[]]$patched=[IO.File]::ReadAllBytes($copy)
$diff=0
for($i=0;$i -lt $orig.Length;$i++){ if($orig[$i] -ne $patched[$i]){$diff++} }
L ("VerifiedDifferentBytes=" + $diff)
if($diff -ne 1){ Fail "Testkopian skiljer sig på mer än en byte. Avbryter." }

# Ta bort gammal lokal trace så vi vet att ev. nytt innehåll kommer från testet.
Remove-Item -LiteralPath $trace -Force -ErrorAction SilentlyContinue

L ""
L "OpeningTestCopyViaWinMOPS=DDE open only"
$h=New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
$h.Initialize()
$cmd='[open("' + $copy.Replace('\','\\') + '")]'
$h.ExecuteDDE($cmd)
Start-Sleep -Seconds 8
try{$h.Cleanup()}catch{}

L ("TraceExists=" + (Test-Path -LiteralPath $trace))
if(Test-Path -LiteralPath $trace){
    $fi=Get-Item -LiteralPath $trace
    L ("TraceLength=" + $fi.Length)
    L ("TraceLastWriteTime=" + $fi.LastWriteTime)
    L ""
    L "===== MDEGRID TRACE ====="
    Get-Content -LiteralPath $trace -ErrorAction SilentlyContinue | ForEach-Object {
        $line=[string]$_
        if($line -match '(?i)(password|passwd|pwd|token|secret)'){
            L "<filtered credential-like line>"
        } else {
            L $line
        }
    }
} else {
    L "No trace file was produced."
}

L ""
L "===== SAFETY ====="
L "Original MCD not modified."
L "A local copy was created and exactly one byte changed: TraceCalculations 0 -> 1."
L "Only WinMOPS DDE open() was used."
L "No save command was issued."
L "No Update/Insert/Delete/Write command was issued by this script."
L "Any server access is WinMOPS/MDEGrid's normal read path while opening the copied display."

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $result
