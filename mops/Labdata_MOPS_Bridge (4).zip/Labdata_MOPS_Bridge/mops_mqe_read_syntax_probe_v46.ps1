﻿$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_READ_SYNTAX_PROBE_v46.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS MQE Read Syntax probe v4.6"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

function TryQ([string]$name,[string]$table,[string]$fn,[string]$cols,[string]$param){
 S $name
 try{
  $q=New-Object -ComObject "Mqecom.MQEQuery.5"
  L("SetDestination="+$q.SetDestination("//HOIGIBMOCLAP12/?mqe"))
  L("LoginReturn="+$q.Login("MOPSuser","",""))
  $q.Table=$table;$q.SelFunction=$fn;$q.Columns=$cols;$q.OrderingFunction="";$q.MaxRows=2;$q.SelParam=$param
  L("Table="+$q.Table);L("Function="+$q.SelFunction);L("Columns="+$q.Columns);L("Params="+$q.SelParam)
  try{L("DoTransaction="+$q.DoTransaction())}catch{L("DoTransaction=FEL: "+$_.Exception.Message)}
  L("ErrorCode="+$q.GetErrorCode());L("ErrorType="+$q.GetErrorType())
  try{$ec=[int16]$q.GetErrorCode();$et=[int16]$q.GetErrorType();L("ErrorString="+$q.GetErrorString($ec,$et))}catch{}
  L("Rows="+$q.NumOfRows);L("Cols="+$q.NumOfColumns)
  try{$q.FreeRowset()|Out-Null}catch{}
 }catch{L("FEL="+$_.Exception.Message)}
}

# Harmless read functions only. Goal: determine MQECOM query syntax before touching TagHistory again.
TryQ "A: mqe / BrowseTags, empty params" "mqe" "BrowseTags" "Source,Name,Description" ""
TryQ "B: blank table / BrowseTags, empty params" "" "BrowseTags" "Source,Name,Description" ""
TryQ "C: mqe / BrowseTags, positional-ish filter" "mqe" "BrowseTags" "Source,Name,Description" 'TagFilter="22=3120=7264",MaxRows=2'
TryQ "D: mqe / TagValue" "mqe" "TagValue" "Tag,Time,Value,Status" 'Tags="22=3120=7264"'

S "SUMMARY"
L "Only MQEQuery READ functions BrowseTags/TagValue were attempted."
L "MOPSuser blank password used."
L "NO TagHistory transaction in this probe."
L "NO MQEUpdate object / write / Session.Open / DDE / Command.Execute."
L ("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
