﻿# mops_session_history_api_probe_v32.ps1
# READ-ONLY introspection.
# Efter att både hist.TagHistory och mqe.TagHistory gav samma RPC-fel
# kartlägger denna probe exakt MOPS.Session och MOPS3iHistory API:t.
#
# Ingen Execute()
# Ingen Session.Open()
# Inga credentials sätts
# Ingen MOPS-data skrivs

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_SESSION_HISTORY_API_PROBE_v32.txt"

function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function P($o,[string]$n){
    try{
        $v=$o.$n
        if($null-eq$v){return "<null>"}
        return [string]$v
    }catch{return "<ERR: "+$_.Exception.Message+">"}
}
function DumpMembers($o,[string]$title){
    S $title
    if($null-eq$o){L "<null>";return}
    try{
        $o.PSObject.Members | Sort-Object Name | ForEach-Object{
            L($_.MemberType.ToString()+" "+$_.Name+" :: "+$_.Definition)
        }
    }catch{L("Member dump FEL="+$_.Exception.Message)}
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
L "MOPS Session/History API probe v3.2"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

S "SESSION OBJECT"
try{
    $s=New-Object -ComObject "MOPS.Session.1"
    L("Created=True")
    foreach($n in @("IsOpen","SessionString","SessionErrorState","ConnectionString","UserIdentity")){
        L($n+"="+(P $s $n))
    }
    try{
        $ui=$s.UserIdentity
        L("UserIdentity.Domain="+(P $ui "Domain"))
        L("UserIdentity.UserName="+(P $ui "UserName"))
        L("UserIdentity.UseThreadIdentity="+(P $ui "UseThreadIdentity"))
    }catch{}
    DumpMembers $s "SESSION MEMBERS"
}catch{L("Session create FEL="+$_.Exception.Message)}

S "CONNECTION OBJECT"
$c=$null
try{
    $c=New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString="//HOIGIBMOCLAP12/"
    $c.Connect()
    L("IsConnected="+(P $c "IsConnected"))
    L("TagBroker="+(P $c "TagBroker"))
    L("UserIdentity.Domain="+(P $c.UserIdentity "Domain"))
    L("UserIdentity.UserName="+(P $c.UserIdentity "UserName"))
    L("UserIdentity.UseThreadIdentity="+(P $c.UserIdentity "UseThreadIdentity"))
    DumpMembers $c "CONNECTION MEMBERS"
}catch{L("Connection FEL="+$_.Exception.Message)}

S "MOPS3IHISTORY OBJECT"
try{
    $h=New-Object -ComObject "MOPS3iHistory"
    L("Created=True")
    DumpMembers $h "MOPS3IHISTORY MEMBERS"

    foreach($n in @("Connection","Session","ConnectionString","Tag","Tags","StartTime","EndTime","NumValues","Resolution","Data","Result","Status")){
        try{
            $v=$h.$n
            L($n+"="+(if($null-eq$v){"<null>"}else{[string]$v}))
        }catch{
            L($n+"=<property unavailable>")
        }
    }
}catch{L("MOPS3iHistory create FEL="+$_.Exception.Message)}

S "MOPS3ITAGFINDER OBJECT"
try{
    $tf=New-Object -ComObject "MOPS3iTagFinder"
    L("Created=True")
    DumpMembers $tf "MOPS3ITAGFINDER MEMBERS"
}catch{L("MOPS3iTagFinder create FEL="+$_.Exception.Message)}

S "WINMOPS DDE HELPER"
try{
    $d=New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
    L("Created=True")
    DumpMembers $d "WINMOPS DDE HELPER MEMBERS"
}catch{L("DDE helper create FEL="+$_.Exception.Message)}

if($c){try{$c.Disconnect();L("Disconnect=OK")}catch{}}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L ("Output="+$out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
