﻿# Nya MOPS - TagBroker/portal probe v0.4
# Read-only. Does not write to MOPS and does not invoke history/write methods.

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_TAGBROKER_PORTAL_PROBE_v04.txt"

function L([string]$s="") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function S([string]$s) { L ""; L ("===== " + $s + " =====") }

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
L "MOPS TagBroker/portal probe v0.4"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("COMPUTERNAME=" + $env:COMPUTERNAME)
L ("PowerShell=" + $PSVersionTable.PSVersion)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

S "WINMOPS PROCESS"
try {
  Get-Process winmops -ErrorAction Stop | ForEach-Object {
    L ("Process=winmops PID=" + $_.Id)
    try { L ("Path=" + $_.Path) } catch { L "Path=<unavailable>" }
    L "-- Loaded modules containing mops/mde/broker/portal --"
    try {
      $m = $_.Modules | Where-Object { $_.ModuleName -match '(?i)mops|mde|broker|portal' } | Sort-Object ModuleName -Unique
      if ($m) { $m | ForEach-Object { L ("MODULE " + $_.ModuleName + " | " + $_.FileName) } }
      else { L "<none matched>" }
    } catch { L ("Module enumeration error: " + $_.Exception.Message) }
  }
} catch { L ("winmops process error: " + $_.Exception.Message) }

S "MOPS.COMMAND SAFE PROPERTY PROBE"
$c = $null
try {
  $c = New-Object -ComObject "MOPS.Command"
  L "Create MOPS.Command=OK"
  foreach ($name in @("Connected","ConnectionString","TagBroker","AuxiliaryParameters")) {
    try { L ($name + "=" + [string]$c.$name) }
    catch { L ($name + "=<ERROR: " + $_.Exception.Message + ">") }
  }
  L "-- Get-Member --"
  try {
    $c | Get-Member | Sort-Object MemberType,Name | ForEach-Object {
      L ($_.MemberType.ToString().PadRight(18) + " " + $_.Name + " :: " + $_.Definition)
    }
  } catch { L ("Get-Member error: " + $_.Exception.Message) }
} catch { L ("Create MOPS.Command=ERROR: " + $_.Exception.Message) }

S "MOPS.COMMAND COM REGISTRY"
try {
  $cp = "Registry::HKEY_CLASSES_ROOT\MOPS.Command\CLSID"
  if (Test-Path $cp) {
    $clsid = (Get-ItemProperty -LiteralPath $cp).'(default)'
    L ("MOPS.Command CLSID=" + $clsid)
    $base = "Registry::HKEY_CLASSES_ROOT\CLSID\$clsid"
    foreach ($sub in @("","ProgID","VersionIndependentProgID","InprocServer32","LocalServer32","TypeLib")) {
      $path = if ($sub) { Join-Path $base $sub } else { $base }
      if (Test-Path $path) {
        try {
          $v = (Get-ItemProperty -LiteralPath $path).'(default)'
          $label = if ($sub) { $sub } else { "CLSID root" }
          L ($label + "=" + [string]$v)
        } catch {}
      }
    }
  } else { L "HKCR\MOPS.Command\CLSID not found" }
} catch { L ("Registry probe error: " + $_.Exception.Message) }

S "LIKELY COM PROGIDS"
try {
  Get-ChildItem "Registry::HKEY_CLASSES_ROOT" -ErrorAction Stop |
    Where-Object { $_.PSChildName -match '(?i)MOPS|MDE|TagBroker' } |
    Sort-Object PSChildName |
    Select-Object -First 200 |
    ForEach-Object {
      L ("PROGID " + $_.PSChildName)
      try {
        $k = Join-Path $_.PSPath "CLSID"
        if (Test-Path $k) { L ("  CLSID=" + (Get-ItemProperty -LiteralPath $k).'(default)') }
      } catch {}
    }
} catch { L ("ProgID enumeration error: " + $_.Exception.Message) }

S "SUMMARY"
L "Probe complete. Read-only."
L "No history command invoked."
L "No MOPS write command invoked."
L ("Output=" + $out)

if ($c -ne $null) { try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($c) } catch {} }

Write-Host ""
Write-Host "Klart."
Write-Host "Resultat sparat i:"
Write-Host $out
Write-Host ""
