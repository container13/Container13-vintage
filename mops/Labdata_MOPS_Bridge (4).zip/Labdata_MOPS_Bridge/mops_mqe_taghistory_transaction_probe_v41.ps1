﻿# mops_mqe_taghistory_transaction_probe_v41.ps1
# FIRST controlled READ-ONLY transaction via MQECOM.
# Uses MQEQuery (not MQEUpdate) against confirmed //HOIGIBMOCLAP12/?mqe.
# One verified tag, short 2-hour window, max 10 rows.
# No Login(), no write/update object, no Session.Open(), no DDE.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_TAGHISTORY_TRANSACTION_PROBE_v41.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}
Remove-Item $out -ErrorAction SilentlyContinue

$tag="22=3120=7264"
$st=(Get-Date).AddHours(-2)
$en=Get-Date

L "MOPS MQE TagHistory Transaction probe v4.1"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

try{
 $q=New-Object -ComObject "Mqecom.MQEQuery.5"
 S "DESTINATION"
 L("Version="+$q.GetVersion())
 L("SetDestination="+$q.SetDestination("//HOIGIBMOCLAP12/?mqe"))
 L("ErrorCode="+$q.GetErrorCode())

 S "READ-ONLY QUERY"
 # Configure a read query only. SelParam is deliberately explicit and logged.
 $q.Table="TagHistory"
 $q.Columns="Tag,Data,Time,Value,Status"
 $q.SelFunction="TagHistory"
 $q.MaxRows=10

 # MQECOM selection parameter string using the verified TagHistory parameter names.
 # No credentials and no update function.
 $sp='Tags="' + $tag + '";StartTime="' + $st.ToString("yyyy-MM-dd HH:mm:ss") + '";EndTime="' + $en.ToString("yyyy-MM-dd HH:mm:ss") + '";NumValues=10'
 $q.SelParam=$sp

 L("Table="+$q.Table)
 L("Columns="+$q.Columns)
 L("SelFunction="+$q.SelFunction)
 L("SelParam="+$q.SelParam)
 L("MaxRows="+$q.MaxRows)

 S "DOTRANSACTION"
 try{
   $ok=$q.DoTransaction()
   L("DoTransaction="+$ok)
 }catch{
   L("DoTransaction=FEL: "+$_.Exception.Message)
 }

 try{L("ErrorCode="+$q.GetErrorCode())}catch{}
 try{L("ErrorType="+$q.GetErrorType())}catch{}
 try{
   $ec=[int16]$q.GetErrorCode();$et=[int16]$q.GetErrorType()
   L("ErrorString="+$q.GetErrorString($ec,$et))
 }catch{}
 L("NumOfRows="+(P $q "NumOfRows"))
 L("NumOfColumns="+(P $q "NumOfColumns"))

 if(([int](P $q "NumOfRows")) -gt 0 -and ([int](P $q "NumOfColumns")) -gt 0){
   S "RESULT"
   $cols=[int]$q.NumOfColumns
   for($c=0;$c-lt$cols;$c++){
     try{L("COLUMN[$c]="+$q.GetColumnName([int16]$c))}catch{L("COLUMN[$c] FEL="+$_.Exception.Message)}
   }
   $rows=[Math]::Min([int]$q.NumOfRows,10)
   for($r=0;$r-lt$rows;$r++){
     $vals=@()
     for($c=0;$c-lt$cols;$c++){
       try{
         $v=$null
         $rc=$q.GetDataVal([ref]$v,[int]$r,[int16]$c)
         $vals+=("C"+$c+"="+[string]$v+"(rc="+$rc+")")
       }catch{$vals+=("C"+$c+"=<ERR>")}
     }
     L("ROW[$r] "+($vals -join " | "))
   }
 }

 try{$q.FreeRowset()|Out-Null}catch{}
}catch{L("TOP FEL="+$_.Exception.Message)}

S "SUMMARY"
L "DoTransaction() WAS attempted once using MQEQuery read object."
L "NO Login()/LoginFromIni()"
L "NO MQEUpdate object"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS write/update function called"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
