Labdata MOPS Bridge - v30 / bridge v0.6

Fast arbetsmapp:
  Labdata_MOPS_Bridge

Nya filer:
  labdata_mops_bridge_v06.ps1
  labdata_mops_bryggtest_v30.html

Fix:
  [Web.HttpUtility] är helt borttaget.
  Querystring avkodas med System.Uri, som finns i den aktuella PowerShell-miljön.

Read-only:
  Ja. Bridgen accepterar endast GET/OPTIONS och gör inga write/update/delete-anrop.

Testordning:
  1. Starta bridge v0.6.
  2. Öppna HTML v30.
  3. Testa anslutning.
  4. Om MOPS ansluten: Undersök TagHistory-bindning.
