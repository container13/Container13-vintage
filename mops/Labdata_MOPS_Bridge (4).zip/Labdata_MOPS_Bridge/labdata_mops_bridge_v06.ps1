﻿# Labdata MOPS Bridge v0.6
# Read-only. Binds only to 127.0.0.1.
# Fix: no dependency on [Web.HttpUtility] / System.Web.

$ErrorActionPreference = "Stop"
$addr = "127.0.0.1"
$port = 8765
$connectionString = "//HOIGIBMOCLAP12/"

function Send-Json($stream, $statusCode, $obj) {
    $json = $obj | ConvertTo-Json -Depth 12 -Compress
    $body = [Text.Encoding]::UTF8.GetBytes($json)

    $reason = @{
        200="OK"; 400="Bad Request"; 404="Not Found";
        500="Internal Server Error"; 502="Bad Gateway"
    }[$statusCode]
    if (-not $reason) { $reason = "OK" }

    $header = "HTTP/1.1 $statusCode $reason`r`n" +
              "Content-Type: application/json; charset=utf-8`r`n" +
              "Access-Control-Allow-Origin: *`r`n" +
              "Access-Control-Allow-Methods: GET, OPTIONS`r`n" +
              "Access-Control-Allow-Headers: Content-Type`r`n" +
              "Content-Length: $($body.Length)`r`n" +
              "Connection: close`r`n`r`n"

    $hb = [Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($hb,0,$hb.Length)
    $stream.Write($body,0,$body.Length)
    $stream.Flush()
}

function New-MopsConnection {
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = $connectionString
    $c.Connect()
    return $c
}

function Get-QueryValue([string]$query, [string]$name) {
    if ([string]::IsNullOrEmpty($query)) { return $null }
    $q = $query.TrimStart('?')

    foreach ($pair in $q -split '&') {
        if ([string]::IsNullOrEmpty($pair)) { continue }

        $parts = $pair -split '=', 2
        $key = [Uri]::UnescapeDataString(($parts[0] -replace '\+',' '))
        $val = ""
        if ($parts.Count -gt 1) {
            $val = [Uri]::UnescapeDataString(($parts[1] -replace '\+',' '))
        }

        if ($key -eq $name) { return $val }
    }
    return $null
}

function Get-ComMembers($obj) {
    try {
        return @($obj | Get-Member | Select-Object -ExpandProperty Name -Unique)
    } catch {
        return @()
    }
}

function Get-Health {
    $c = $null
    try {
        $c = New-MopsConnection
        $serverTime = $c.ServerTime

        $tagBroker = "available"
        try {
            if ($null -eq $c.TagBroker) { $tagBroker = "missing" }
        } catch {
            $tagBroker = "error"
        }

        $b = $c.Browser
        $b.Refresh()
        $services = @($b.Services | ForEach-Object { $_.Name })

        return @{
            ok = $true
            read_only = $true
            version = "0.6"
            bridge = "labdata-mops-bridge"
            mops_connected = [bool]$c.IsConnected
            server_time = [string]$serverTime
            tag_broker = $tagBroker
            service_names = $services
        }
    } catch {
        return @{
            ok = $false
            read_only = $true
            version = "0.6"
            error = $_.Exception.Message
            hresult = ("0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
        }
    } finally {
        if ($c) { try { $c.Disconnect() } catch {} }
    }
}

function Inspect-HistoryBinding($tag) {
    if ($tag -notmatch '^\d+=\d+=.+$') {
        return @{
            code = 400
            body = @{
                ok = $false
                read_only = $true
                error = "invalid_tag"
            }
        }
    }

    $c = $null
    try {
        $c = New-MopsConnection

        $cmd = New-Object -ComObject "MOPS.Command.1"
        $cmd.Connection = $c
        $cmd.ServiceName = "hist"
        $cmd.FunctionName = "TagHistory"

        $cmdParams = $null
        $cmdParam = $null
        $paramsFromCommand = $null

        try { $cmdParams = New-Object -ComObject "MOPS.CommandParams.1" } catch {}
        try { $cmdParam  = New-Object -ComObject "MOPS.CommandParam.1" } catch {}
        try { $paramsFromCommand = $cmd.Parameters } catch {}

        $body = [ordered]@{
            ok = $true
            read_only = $true
            stage = "inspect_command_parameter_objects"
            tag = $tag
            mops_connected = [bool]$c.IsConnected
            service = "hist"
            function = "TagHistory"
            command_members = Get-ComMembers $cmd
            command_parameters_members = if ($paramsFromCommand) { Get-ComMembers $paramsFromCommand } else { @() }
            commandparams_object_created = [bool]($null -ne $cmdParams)
            commandparams_members = if ($cmdParams) { Get-ComMembers $cmdParams } else { @() }
            commandparam_object_created = [bool]($null -ne $cmdParam)
            commandparam_members = if ($cmdParam) { Get-ComMembers $cmdParam } else { @() }
        }

        $body.next = "Use these exact COM members to construct hist.TagHistory parameters."
        return @{ code = 200; body = $body }

    } catch {
        return @{
            code = 500
            body = @{
                ok = $false
                read_only = $true
                stage = "inspect_command_parameter_objects"
                error = $_.Exception.Message
                hresult = ("0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
            }
        }
    } finally {
        if ($c) { try { $c.Disconnect() } catch {} }
    }
}

$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Parse($addr), $port)
$listener.Start()

Write-Host "Labdata MOPS Bridge v0.6"
Write-Host "Lyssnar pa http://$addr`:$port/"
Write-Host "READ-ONLY. Stoppa genom att stanga PowerShell-fonstret."

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()

        try {
            $reader = New-Object IO.StreamReader(
                $stream, [Text.Encoding]::ASCII, $false, 4096, $true
            )

            $first = $reader.ReadLine()
            while ($true) {
                $line = $reader.ReadLine()
                if ($null -eq $line -or $line -eq "") { break }
            }

            $parts = $first.Split(" ")
            $method = $parts[0]

            if ($method -eq "OPTIONS") {
                Send-Json $stream 200 @{ ok=$true }
                continue
            }

            if ($method -ne "GET") {
                Send-Json $stream 400 @{
                    ok=$false
                    read_only=$true
                    error="GET only"
                }
                continue
            }

            $u = [Uri]("http://localhost" + $parts[1])

            switch ($u.AbsolutePath) {
                "/health" {
                    $h = Get-Health
                    if ($h.ok) {
                        Send-Json $stream 200 $h
                    } else {
                        Send-Json $stream 500 $h
                    }
                }

                "/history" {
                    $tag = Get-QueryValue $u.Query "tag"
                    $x = Inspect-HistoryBinding $tag
                    Send-Json $stream $x.code $x.body
                }

                default {
                    Send-Json $stream 404 @{
                        ok=$false
                        error="not_found"
                    }
                }
            }

        } catch {
            try {
                Send-Json $stream 500 @{
                    ok=$false
                    read_only=$true
                    error=$_.Exception.Message
                }
            } catch {}
        } finally {
            try { $stream.Dispose() } catch {}
            try { $client.Close() } catch {}
        }
    }
} finally {
    $listener.Stop()
}
