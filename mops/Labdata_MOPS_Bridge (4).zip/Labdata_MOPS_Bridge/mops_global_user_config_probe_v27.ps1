﻿# mops_global_user_config_probe_v27.ps1
# READ-ONLY.
# Följer de centrala konfigurationsvägar som v26 hittade:
#   \\hoigibmoclap12.holmen.net\WinMOPS\Config\mopsglb.xml
#   \\hoigibmoclap12.holmen.net\WinMOPS\Config\user
#
# Syfte:
# - kartlägga portal/service/session/security-konfiguration
# - se om det finns separata user-profiler för winmops och iiblabl4
# - hitta hist/RPC/callback-relaterade config-hints
#
# Ingen Execute()
# Ingen Session.Open()
# Ingen credential skrivs
# Ingen MOPS-data skrivs
# Inga lösenord/hash/token-värden skrivs ut.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_GLOBAL_USER_CONFIG_PROBE_v27.txt"

function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function Sensitive([string]$s){
    return ($s -match '(?i)pass(word)?|pwd|secret|token|credential|hash|salt|private.?key')
}
function SafeLine([string]$line){
    if(Sensitive $line){ return "<REDACTED SENSITIVE LINE>" }
    return $line
}

Remove-Item $out -ErrorAction SilentlyContinue

L "MOPS Global/user config probe v2.7"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity="+[System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

$global="\\hoigibmoclap12.holmen.net\WinMOPS\Config\mopsglb.xml"
$userRoot="\\hoigibmoclap12.holmen.net\WinMOPS\Config\user"

S "GLOBAL CONFIG METADATA"
L ("Path="+$global)
L ("TestPath="+(Test-Path $global))
if(Test-Path $global){
    try{
        $fi=Get-Item $global -ErrorAction Stop
        L ("Length="+$fi.Length)
        L ("LastWriteTime="+$fi.LastWriteTime)
        L ("Attributes="+$fi.Attributes)

        $txt=Get-Content -LiteralPath $global -Raw -ErrorAction Stop
        try{
            [xml]$xml=$txt
            L ("XmlRoot="+$xml.DocumentElement.Name)

            $elements=@()
            $attrs=@()
            $nodes=$xml.SelectNodes("//*")
            foreach($n in $nodes){
                $elements += $n.Name
                foreach($a in @($n.Attributes)){
                    if(Sensitive $a.Name){$attrs += ($a.Name+"[SENSITIVE]")}
                    else{$attrs += $a.Name}
                }
            }
            L ("ElementNames="+(($elements|Sort-Object -Unique)-join ", "))
            L ("AttributeNames="+(($attrs|Sort-Object -Unique)-join ", "))
        }catch{
            L ("XML parse FEL="+$_.Exception.Message)
        }
    }catch{
        L ("Global config read FEL="+$_.Exception.Message)
    }
}

S "GLOBAL CONFIG SAFE HINTS"
$patterns=@(
    "hist","MHIST","portal","MPORTAL","TagBroker","callback","RPC","session",
    "security","access","user","server","service","provider","node","endpoint",
    "HOIGIBMOCLAP12","mopsuser","mopssys"
)
if(Test-Path $global){
    try{
        $hits=@(Select-String -LiteralPath $global -SimpleMatch -Pattern $patterns -ErrorAction Stop)
        L ("MatchCount="+$hits.Count)
        foreach($h in ($hits|Select-Object -First 180)){
            L ("L"+$h.LineNumber+": "+(SafeLine $h.Line.Trim()))
        }
    }catch{
        L ("Global hints FEL="+$_.Exception.Message)
    }
}

S "USER CONFIG ROOT"
L ("Path="+$userRoot)
L ("TestPath="+(Test-Path $userRoot))
if(Test-Path $userRoot){
    try{
        $items=@(Get-ChildItem -LiteralPath $userRoot -Force -ErrorAction Stop|Sort-Object Name)
        L ("ItemCount="+$items.Count)
        foreach($i in $items){
            if($i.PSIsContainer){
                L ("DIR  "+$i.Name+" | LastWrite="+$i.LastWriteTime)
            }else{
                L ("FILE "+$i.Name+" | "+$i.Length+" bytes | LastWrite="+$i.LastWriteTime)
            }
        }
    }catch{
        L ("User root list FEL="+$_.Exception.Message)
    }
}

S "USERNAME-SPECIFIC FILE/DIR PRESENCE"
foreach($u in @("winmops","iiblabl4","sys_mopsIBCB")){
    L ("-- "+$u+" --")
    if(Test-Path $userRoot){
        try{
            $hits=@(Get-ChildItem -LiteralPath $userRoot -Recurse -Force -ErrorAction SilentlyContinue |
                Where-Object {$_.Name -match [regex]::Escape($u)} |
                Select-Object -First 80)
            if($hits.Count -eq 0){L "<no filename/path matches>"}
            foreach($h in $hits){
                if($h.PSIsContainer){
                    L ("DIR  "+$h.FullName)
                }else{
                    L ("FILE "+$h.FullName+" | "+$h.Length+" bytes | "+$h.LastWriteTime)
                }
            }
        }catch{
            L ("Search FEL="+$_.Exception.Message)
        }
    }
}

S "SAFE USER CONFIG HINTS"
if(Test-Path $userRoot){
    $patterns2=@(
        "hist","MHIST","portal","MPORTAL","TagBroker","callback","RPC","session",
        "security","access","server","service","provider","node","endpoint",
        "winmops","iiblabl4","mopsuser","mopssys"
    )
    $seen=0
    try{
        Get-ChildItem -LiteralPath $userRoot -Recurse -File -Force -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Length -lt 2MB -and
                $_.Extension -match '(?i)\.(ini|cfg|conf|config|xml|txt|json)$'
            } |
            Sort-Object FullName |
            ForEach-Object{
                if($seen -ge 220){return}
                try{
                    $hits=@(Select-String -LiteralPath $_.FullName -SimpleMatch -Pattern $patterns2 -ErrorAction Stop|
                        Select-Object -First 25)
                    if($hits.Count -gt 0){
                        L ("FILE "+$_.FullName)
                        foreach($h in $hits){
                            L ("  L"+$h.LineNumber+": "+(SafeLine $h.Line.Trim()))
                            $seen++
                            if($seen -ge 220){break}
                        }
                    }
                }catch{}
            }
    }catch{}
}

S "SEQUENCE DB PRESENCE"
foreach($u in @("winmops","iiblabl4")){
    $p=Join-Path $userRoot ($u+"_sequence.db")
    L ($u+" sequence path="+$p)
    L ("Exists="+(Test-Path $p))
    if(Test-Path $p){
        try{
            $fi=Get-Item $p
            L ("Length="+$fi.Length+" LastWrite="+$fi.LastWriteTime)
        }catch{}
    }
}

S "BASIC SERVER REACHABILITY"
foreach($hostn in @("hoigibmoclap12.holmen.net","hoigibmoclap12")){
    try{
        $ips=[System.Net.Dns]::GetHostAddresses($hostn)
        L ($hostn+" IPs="+(($ips|%{$_.IPAddressToString}) -join ", "))
    }catch{L($hostn+" DNS FEL="+$_.Exception.Message)}
}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L "Sensitive password/hash/token lines were redacted."
L ("Output="+$out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
