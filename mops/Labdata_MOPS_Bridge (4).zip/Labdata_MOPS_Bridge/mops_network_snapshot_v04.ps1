﻿# MOPS network snapshot v0.4
# READ-ONLY. Captures TCP connections owned by WinMOPS/MOPS processes.
# No network scan, no connection attempts, no writes to MOPS.

$ErrorActionPreference="SilentlyContinue"
$outFile=Join-Path $env:USERPROFILE "Downloads\MOPS_NETWORK_SNAPSHOT_v04.txt"
Remove-Item $outFile -ErrorAction SilentlyContinue

"MOPS network snapshot v0.4" | Set-Content $outFile
"Time=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Add-Content $outFile

"`r`n===== MOPS/WINMOPS PROCESSES =====" | Add-Content $outFile
$procs=Get-Process | Where-Object {
    $_.ProcessName -match 'mops|winmops|mcd3i|mclient'
}
$procs | Select-Object Id,ProcessName,Path | Format-Table -AutoSize | Out-String -Width 240 | Add-Content $outFile

"`r`n===== TCP CONNECTIONS FOR THOSE PROCESSES =====" | Add-Content $outFile
$pids=@($procs.Id)
if($pids.Count -eq 0){
    "No matching MOPS/WinMOPS processes found." | Add-Content $outFile
}else{
    Get-NetTCPConnection -ErrorAction SilentlyContinue |
      Where-Object { $pids -contains $_.OwningProcess } |
      Sort-Object OwningProcess,RemoteAddress,RemotePort |
      Select-Object OwningProcess,State,LocalAddress,LocalPort,RemoteAddress,RemotePort |
      Format-Table -AutoSize | Out-String -Width 240 | Add-Content $outFile
}

"`r`n===== SERVER NAME RESOLUTION =====" | Add-Content $outFile
try {
    Resolve-DnsName HOIGIBMOCLAP12 -ErrorAction Stop |
      Select-Object Name,Type,IPAddress |
      Format-Table -AutoSize | Out-String -Width 240 | Add-Content $outFile
}catch{
    "Resolve error: $($_.Exception.Message)" | Add-Content $outFile
}

Write-Host ""
Write-Host "KLAR"
Write-Host "VIKTIGT: låt WinMOPS vara öppet på en vy där historik visas när du kör denna."
Write-Host "Skicka sedan filen:"
Write-Host $outFile
