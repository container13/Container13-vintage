MOPS MDE CommandText probe v6.2

Varför:
v61 visade att Parameters byggdes korrekt, men ServiceName och FunctionName
förblev tomma. Därför är RPC-felet från v61 inte ett rent bevis mot mde.Data.

v62 byter till den väg som faktiskt lagras i produktions-MCD:n:
CommandText = ?MDE.GetPeriods()

Den strängen finns ordagrant i den MCD som körs idag.

Testet kör exakt EN ofarlig read-only MDE-kommandofunktion:
?MDE.GetPeriods()

Om detta fungerar har vi bevisat att fristående PowerShell kan använda MDE via
CommandText-vägen. Då går nästa steg direkt på ?MDE.Data(...).

Säkerhet:
- ingen Update/Insert/Delete/Write/Save
- ingen Session.Open
- ingen DDE
- ingen MQEUpdate
- ingen MCD ändras eller sparas

Resultat:
C:\Users\<user>\Downloads\MOPS_MDE_COMMANDTEXT_v62.txt
