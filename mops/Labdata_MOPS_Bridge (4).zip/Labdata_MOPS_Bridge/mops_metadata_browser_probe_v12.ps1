﻿# Nya MOPS - Metadata Browser probe v1.2
# READ-ONLY. Inspects MOPS browser/metadata COM interfaces only.
# No Execute(), no history query, no login, no writes.
# Run in Windows PowerShell (x86).

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_METADATA_BROWSER_PROBE_v12.txt"

function L([string]$s="") {
    Add-Content -LiteralPath $out -Value $s -Encoding UTF8
    Write-Host $s
}
function Members($obj,[string]$label) {
    L ("-- " + $label + " Get-Member --")
    try {
        $m = $obj | Get-Member | Sort-Object MemberType,Name
        foreach($x in $m) {
            L ($x.MemberType.ToString().PadRight(18) + " " + $x.Name + " :: " + $x.Definition)
        }
        L ("Count=" + $m.Count)
    } catch {
        L ("FEL=" + $_.Exception.Message)
    }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
L "MOPS Metadata Browser probe v1.2"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
L ""

$c=$null
$objs=@()

try {
    L "1. Ansluter MOPS.Connection ..."
    $c = New-Object -ComObject "MOPS.Connection"
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    $c.Connect()
    L ("IsConnected=" + $c.IsConnected)
    L ("TagBroker=" + $c.TagBroker)

    L ""
    L "2. Connection.Browser ..."
    try {
        $b = $c.Browser
        if($null -eq $b) {
            L "Connection.Browser=<null>"
        } else {
            L ("Connection.Browser type=" + $b.GetType().FullName)
            Members $b "Connection.Browser"
            $objs += $b
        }
    } catch {
        L ("Connection.Browser FEL=" + $_.Exception.Message)
    }

    L ""
    L "3. Fristaende browser-objekt - endast medlemslistor ..."
    foreach($progId in @(
        "MOPS.ServicesBrowser",
        "MOPS.ServiceBrowser",
        "MOPS.FunctionsBrowser",
        "MOPS.FunctionBrowser",
        "MOPS.ParametersBrowser",
        "MOPS.ParameterBrowser",
        "MOPS.NamespaceBrowser",
        "MOPS.NamespacesBrowser",
        "MOPS.CommandBuilder"
    )) {
        L ""
        L ("### " + $progId)
        try {
            $o = New-Object -ComObject $progId
            L ("Create " + $progId + "=OK")
            Members $o $progId
            $objs += $o
        } catch {
            L ("Create " + $progId + "=FEL: " + $_.Exception.Message)
        }
    }

    L ""
    L "4. Klart - inga browser-metoder har anropats."
}
catch {
    L ("OVANTAT FEL=" + $_.Exception.Message)
}
finally {
    foreach($o in $objs) {
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($o) } catch {}
    }
    if($null -ne $c) {
        try {
            if($c.IsConnected) {
                $c.Disconnect()
                L "Disconnect=OK"
            }
        } catch {}
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($c) } catch {}
    }
}

L ""
L "READ-ONLY."
L "Ingen Execute(), historikfraga, login eller skrivning."
L ("Output=" + $out)
