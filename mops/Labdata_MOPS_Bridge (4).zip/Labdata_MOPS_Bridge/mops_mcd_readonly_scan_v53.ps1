﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MCD_READONLY_SCAN_v53.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s){ L ""; L ("===== " + $s + " =====") }

$src = "\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd"

L "MOPS MCD Read-only Scan v5.3"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
L ("Source=" + $src)

if(-not (Test-Path -LiteralPath $src)){
    H "ERROR"
    L "Source MCD not accessible."
    L ("Output=" + $out)
    Write-Host ""
    Write-Host "KAN INTE LÄSA MCD-FILEN:"
    Write-Host $src
    Write-Host "Resultat:"
    Write-Host $out
    exit
}

$f = Get-Item -LiteralPath $src
H "FILE METADATA"
L ("Length=" + $f.Length)
L ("LastWriteTime=" + $f.LastWriteTime)
try {
    $hash = Get-FileHash -LiteralPath $src -Algorithm SHA256
    L ("SHA256=" + $hash.Hash)
} catch {}

# Read bytes only. No copy, no open in WinMOPS, no modification.
[byte[]]$bytes = [System.IO.File]::ReadAllBytes($src)

function Get-AsciiStrings([byte[]]$b, [int]$min=4){
    $sb = New-Object System.Text.StringBuilder
    foreach($x in $b){
        if($x -ge 32 -and $x -le 126){
            [void]$sb.Append([char]$x)
        } else {
            if($sb.Length -ge $min){ $sb.ToString() }
            [void]$sb.Clear()
        }
    }
    if($sb.Length -ge $min){ $sb.ToString() }
}

function Get-Utf16Strings([byte[]]$b, [int]$min=4){
    $results = New-Object System.Collections.Generic.List[string]
    for($offset=0; $offset -le 1; $offset++){
        $sb = New-Object System.Text.StringBuilder
        for($i=$offset; $i -lt ($b.Length-1); $i+=2){
            $lo=$b[$i]; $hi=$b[$i+1]
            if($hi -eq 0 -and $lo -ge 32 -and $lo -le 126){
                [void]$sb.Append([char]$lo)
            } else {
                if($sb.Length -ge $min){ $results.Add($sb.ToString()) }
                [void]$sb.Clear()
            }
        }
        if($sb.Length -ge $min){ $results.Add($sb.ToString()) }
    }
    return $results
}

H "TARGETED STRINGS"
$ascii = @(Get-AsciiStrings $bytes 4)
$utf16 = @(Get-Utf16Strings $bytes 4)
$all = @($ascii + $utf16 | Sort-Object -Unique)

$patterns = @(
    '(?i)MOPS3iHistory',
    '(?i)MOPS3iSnapshot',
    '(?i)MAccess',
    '(?i)CommandString',
    '(?i)ChangeCommand',
    '(?i)DataNavigator',
    '(?i)TagHistory',
    '(?i)StartTime',
    '(?i)EndTime',
    '(?i)NumValues',
    '(?i)Resolution',
    '(?i)Interpolation',
    '(?i)PeriodCriteria',
    '(?i)OutputData',
    '(?i)Parameters',
    '(?i)Fields',
    '(?i)Tags',
    '22=[0-9=._:-]+'
)

$hits = New-Object System.Collections.Generic.List[string]
foreach($s in $all){
    foreach($p in $patterns){
        if($s -match $p){
            # Avoid dumping suspicious credential-style text.
            if($s -notmatch '(?i)(password|passwd|pwd|token|secret)'){
                $hits.Add($s)
            }
            break
        }
    }
}

$hits = @($hits | Sort-Object -Unique)
L ("AsciiStrings=" + $ascii.Count)
L ("Utf16Strings=" + $utf16.Count)
L ("TargetHits=" + $hits.Count)

foreach($s in $hits){
    if($s.Length -gt 500){ $s=$s.Substring(0,500)+"..." }
    L $s
}

H "TAG CANDIDATES"
$tagMatches = New-Object System.Collections.Generic.List[string]
foreach($s in $all){
    foreach($m in [regex]::Matches($s,'22=[0-9]+(?:=[0-9A-Za-z_.:-]+)+')){
        $tagMatches.Add($m.Value)
    }
}
$tags = @($tagMatches | Sort-Object -Unique)
L ("UniqueTagCandidates=" + $tags.Count)
foreach($t in $tags){ L $t }

H "SUMMARY"
L "Exact known MCD scanned read-only."
L "Only file bytes and metadata were read."
L "No WinMOPS/DDE/COM object invoked."
L "No MOPS server query."
L "No login."
L "No Execute/Submit/Update/Write."
L "No source file copied or modified."
L "Credential-like strings are excluded from output."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
