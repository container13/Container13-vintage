﻿# Nya MOPS - Session live probe v0.8
# Read-only. Opens a MOPS connection, attaches it to a Session,
# and inspects session state. No login credentials, history, Execute(), or writes.

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_SESSION_LIVE_PROBE_v08.txt"
function L([string]$s="") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8; Write-Host $s }

Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS Session live probe v0.8"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
L ""

$c = $null
$s = $null
try {
    L "1. Skapar och ansluter MOPS.Connection ..."
    $c = New-Object -ComObject "MOPS.Connection"
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    $c.Connect()
    L ("   IsConnected=" + $c.IsConnected)
    L ("   TagBroker=" + $c.TagBroker)
    L ("   ConnectionErrorState=" + $c.ConnectionErrorState)

    L ""
    L "2. Skapar MOPS.Session ..."
    $s = New-Object -ComObject "MOPS.Session"
    L "   OK"

    L "3. Kopplar Session.Connection till fungerande anslutning ..."
    $s.Connection = $c
    L "   OK"

    L "4. Laser sessionslage FORE Open() ..."
    try { L ("   IsOpen=" + $s.IsOpen) } catch { L ("   IsOpen ERROR=" + $_.Exception.Message) }
    try { L ("   SessionString=" + $s.SessionString) } catch { L ("   SessionString ERROR=" + $_.Exception.Message) }
    try { L ("   SessionErrorState=" + $s.SessionErrorState) } catch { L ("   SessionErrorState ERROR=" + $_.Exception.Message) }

    L ""
    L "5. Anropar Session.Open() utan credentials ..."
    $s.Open()
    L "   Open() returnerade"

    L "6. Laser sessionslage EFTER Open() ..."
    try { L ("   IsOpen=" + $s.IsOpen) } catch { L ("   IsOpen ERROR=" + $_.Exception.Message) }
    try { L ("   SessionString=" + $s.SessionString) } catch { L ("   SessionString ERROR=" + $_.Exception.Message) }
    try { L ("   SessionErrorState=" + $s.SessionErrorState) } catch { L ("   SessionErrorState ERROR=" + $_.Exception.Message) }

    L ""
    L "RESULTAT: Session-proben klar."
}
catch {
    L ("FEL=" + $_.Exception.Message)
}
finally {
    if ($null -ne $s) {
        try {
            if ($s.IsOpen) {
                L "7. Session.Close() ..."
                $s.Close()
                L "   OK"
            }
        } catch { L ("Session.Close ERROR=" + $_.Exception.Message) }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($s) } catch {}
    }
    if ($null -ne $c) {
        try {
            if ($c.IsConnected) {
                L "8. Connection.Disconnect() ..."
                $c.Disconnect()
                L "   OK"
            }
        } catch { L ("Disconnect ERROR=" + $_.Exception.Message) }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($c) } catch {}
    }
}

L ""
L "Read-only. Inga credentials, ingen historik och ingen skrivning."
L ("Output=" + $out)
