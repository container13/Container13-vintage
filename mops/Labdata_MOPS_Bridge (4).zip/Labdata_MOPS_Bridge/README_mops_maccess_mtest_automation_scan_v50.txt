MOPS MAccess / MTest Automation Scan v5.0

Manualspår:
- MAccess är WinMOPS-objektet för queries/commands.
- Command Builder konfigurerar MAccess via CommandString/ChangeCommand.
- MTest bygger/sparar/submittar queries.

Syfte:
Kartlägga lokala binärer, ProgID/CLSID/TypeLib och möjliga automation-objekt
för MAccess/MTest/MOPS3iHistory utan att göra någon serverfråga.

Säkerhet:
- Read-only.
- Ingen serveranslutning.
- Ingen login.
- Ingen query/Submit/Execute.
- Ingen write/update.

Resultat:
C:\Users\<user>\Downloads\MOPS_MACCESS_MTEST_AUTOMATION_SCAN_v50.txt
