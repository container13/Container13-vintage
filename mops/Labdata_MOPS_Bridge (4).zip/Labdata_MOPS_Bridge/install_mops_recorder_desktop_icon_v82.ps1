$ErrorActionPreference='Stop'
$scriptDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$launcher=Join-Path $scriptDir 'start_mops_save_flow_recorder_v82.bat'
$desktop=[Environment]::GetFolderPath('Desktop')
$shortcutPath=Join-Path $desktop 'MOPS - spela in inloggning och sparning.lnk'
$shell=New-Object -ComObject WScript.Shell
$shortcut=$shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath=$launcher
$shortcut.WorkingDirectory=$scriptDir
$shortcut.Description='Passiv MOPS-inspelningsrobot v8.2 - lagrar aldrig lösenord'
$shortcut.Save()
Write-Host 'Skrivbordsikonen skapades:' -ForegroundColor Green
Write-Host $shortcutPath
