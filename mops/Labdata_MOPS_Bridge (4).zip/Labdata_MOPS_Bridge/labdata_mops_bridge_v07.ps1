﻿# Labdata MOPS Bridge v0.7
# Read-only. 127.0.0.1 only.
# v31: exact IDispatch type-info inspection for MOPS.Command.Parameters.
# No TagHistory Execute yet.

$ErrorActionPreference = "Stop"
$addr = "127.0.0.1"
$port = 8765
$connectionString = "//HOIGIBMOCLAP12/"

if (-not ("ComTypeInspectorV31" -as [type])) {
$src = @"
using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Collections.Generic;

[ComImport]
[Guid("00020400-0000-0000-C000-000000000046")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IDispatchNativeV31
{
    [PreserveSig] int GetTypeInfoCount(out uint pctinfo);
    [PreserveSig] int GetTypeInfo(uint iTInfo, uint lcid, out ITypeInfo ppTInfo);
    [PreserveSig] int GetIDsOfNames(ref Guid riid,
        [MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPWStr)] string[] rgszNames,
        uint cNames, uint lcid,
        [Out, MarshalAs(UnmanagedType.LPArray)] int[] rgDispId);
    [PreserveSig] int Invoke(int dispIdMember, ref Guid riid, uint lcid, ushort wFlags,
        IntPtr pDispParams, IntPtr pVarResult, IntPtr pExcepInfo, IntPtr puArgErr);
}

public static class ComTypeInspectorV31
{
    static string Inv(INVOKEKIND k) {
        switch(k) {
            case INVOKEKIND.INVOKE_FUNC: return "METHOD";
            case INVOKEKIND.INVOKE_PROPERTYGET: return "PROPERTYGET";
            case INVOKEKIND.INVOKE_PROPERTYPUT: return "PROPERTYPUT";
            case INVOKEKIND.INVOKE_PROPERTYPUTREF: return "PROPERTYPUTREF";
            default: return k.ToString();
        }
    }

    public static string[] Inspect(object obj)
    {
        var rows = new List<string>();
        if (obj == null) { rows.Add("OBJECT=NULL"); return rows.ToArray(); }

        IDispatchNativeV31 disp = (IDispatchNativeV31)obj;
        uint count;
        int hr = disp.GetTypeInfoCount(out count);
        rows.Add("GetTypeInfoCount hr=0x" + hr.ToString("X8") + " count=" + count);
        if (hr != 0 || count == 0) return rows.ToArray();

        ITypeInfo ti;
        hr = disp.GetTypeInfo(0, 0, out ti);
        rows.Add("GetTypeInfo hr=0x" + hr.ToString("X8"));
        if (hr != 0 || ti == null) return rows.ToArray();

        IntPtr pAttr = IntPtr.Zero;
        ti.GetTypeAttr(out pAttr);
        try {
            TYPEATTR attr = (TYPEATTR)Marshal.PtrToStructure(pAttr, typeof(TYPEATTR));
            rows.Add("Functions=" + attr.cFuncs + " Variables=" + attr.cVars);

            for (int i=0; i<attr.cFuncs; i++) {
                IntPtr pFunc = IntPtr.Zero;
                ti.GetFuncDesc(i, out pFunc);
                try {
                    FUNCDESC fd = (FUNCDESC)Marshal.PtrToStructure(pFunc, typeof(FUNCDESC));
                    string[] names = new string[Math.Max(1, fd.cParams + 1)];
                    int got;
                    ti.GetNames(fd.memid, names, names.Length, out got);

                    string method = got > 0 ? names[0] : ("DISPID_" + fd.memid);
                    var pars = new List<string>();
                    for (int n=1; n<got; n++) pars.Add(names[n]);

                    rows.Add(
                        Inv(fd.invkind) +
                        " | DISPID=" + fd.memid +
                        " | " + method +
                        "(" + String.Join(", ", pars.ToArray()) + ")" +
                        " | Params=" + fd.cParams +
                        " Optional=" + fd.cParamsOpt
                    );
                }
                finally {
                    if (pFunc != IntPtr.Zero) ti.ReleaseFuncDesc(pFunc);
                }
            }
        }
        finally {
            if (pAttr != IntPtr.Zero) ti.ReleaseTypeAttr(pAttr);
        }
        return rows.ToArray();
    }
}
"@
    Add-Type -TypeDefinition $src -Language CSharp
}

function Send-Json($stream,$statusCode,$obj) {
    $json = $obj | ConvertTo-Json -Depth 12 -Compress
    $body = [Text.Encoding]::UTF8.GetBytes($json)
    $reason = @{200="OK";400="Bad Request";404="Not Found";500="Internal Server Error"}[$statusCode]
    if (-not $reason) {$reason="OK"}
    $header = "HTTP/1.1 $statusCode $reason`r`nContent-Type: application/json; charset=utf-8`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
    $hb=[Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($hb,0,$hb.Length);$stream.Write($body,0,$body.Length);$stream.Flush()
}

function New-MopsConnection {
    $c=New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString=$connectionString
    $c.Connect()
    return $c
}

function Get-QueryValue([string]$query,[string]$name) {
    if ([string]::IsNullOrEmpty($query)) { return $null }
    foreach($pair in $query.TrimStart('?') -split '&') {
        $parts=$pair -split '=',2
        $key=[Uri]::UnescapeDataString(($parts[0] -replace '\+',' '))
        $val=""
        if($parts.Count -gt 1){$val=[Uri]::UnescapeDataString(($parts[1] -replace '\+',' '))}
        if($key -eq $name){return $val}
    }
    return $null
}

function Get-Health {
    $c=$null
    try {
        $c=New-MopsConnection
        $b=$c.Browser;$b.Refresh()
        return @{
            ok=$true;read_only=$true;version="0.7"
            mops_connected=[bool]$c.IsConnected
            server_time=[string]$c.ServerTime
            service_names=@($b.Services|%{$_.Name})
        }
    } catch {
        return @{ok=$false;read_only=$true;version="0.7";error=$_.Exception.Message}
    } finally { if($c){try{$c.Disconnect()}catch{}} }
}

function Inspect-Params($tag) {
    $c=$null
    try {
        $c=New-MopsConnection
        $cmd=New-Object -ComObject "MOPS.Command.1"
        $cmd.Connection=$c
        $cmd.ServiceName="hist"
        $cmd.FunctionName="TagHistory"

        $p=$cmd.Parameters
        $rows=[ComTypeInspectorV31]::Inspect($p)

        return @{
            code=200
            body=@{
                ok=$true
                read_only=$true
                tag=$tag
                mops_connected=[bool]$c.IsConnected
                service="hist"
                function="TagHistory"
                parameters_typeinfo=$rows
                note="No Execute was performed."
            }
        }
    } catch {
        return @{
            code=500
            body=@{
                ok=$false;read_only=$true
                stage="inspect_parameters_typeinfo"
                error=$_.Exception.Message
                hresult=("0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
            }
        }
    } finally {if($c){try{$c.Disconnect()}catch{}}}
}

$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Parse($addr),$port)
$listener.Start()
Write-Host "Labdata MOPS Bridge v0.7"
Write-Host "Lyssnar pa http://$addr`:$port/"
Write-Host "READ-ONLY. Stoppa genom att stanga PowerShell-fonstret."

try {
    while($true) {
        $client=$listener.AcceptTcpClient()
        $stream=$client.GetStream()
        try {
            $reader=New-Object IO.StreamReader($stream,[Text.Encoding]::ASCII,$false,4096,$true)
            $first=$reader.ReadLine()
            while($true){$line=$reader.ReadLine();if($null -eq $line -or $line -eq ""){break}}
            $parts=$first.Split(" ")
            $method=$parts[0]

            if($method -eq "OPTIONS"){Send-Json $stream 200 @{ok=$true};continue}
            if($method -ne "GET"){Send-Json $stream 400 @{ok=$false;error="GET only";read_only=$true};continue}

            $u=[Uri]("http://localhost"+$parts[1])
            switch($u.AbsolutePath) {
                "/health" {
                    $h=Get-Health
                    Send-Json $stream ($(if($h.ok){200}else{500})) $h
                }
                "/history" {
                    $tag=Get-QueryValue $u.Query "tag"
                    $x=Inspect-Params $tag
                    Send-Json $stream $x.code $x.body
                }
                default {Send-Json $stream 404 @{ok=$false;error="not_found"}}
            }
        } catch {
            try{Send-Json $stream 500 @{ok=$false;read_only=$true;error=$_.Exception.Message}}catch{}
        } finally {
            try{$stream.Dispose()}catch{}
            try{$client.Close()}catch{}
        }
    }
} finally {$listener.Stop()}
