﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MTEST_ROOTDIR_SCAN_v49.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s="") { Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s) { L ""; L ("===== " + $s + " =====") }

L "MOPS MTest RootDir Scan v4.9"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)

$iniCandidates = @(
  "$env:LOCALAPPDATA\VirtualStore\Windows\SysWOW64\MTEST.INI",
  "$env:LOCALAPPDATA\VirtualStore\Windows\System32\MTEST.INI",
  "C:\Windows\SysWOW64\MTEST.INI",
  "C:\Windows\System32\MTEST.INI"
) | Where-Object { Test-Path $_ }

$rootDirs = New-Object System.Collections.Generic.List[string]

H "MTEST.INI"
foreach($ini in $iniCandidates){
  L ("FILE: " + $ini)
  try{
    foreach($line in Get-Content -LiteralPath $ini -ErrorAction Stop){
      if($line -match '^\s*rootDir\s*=\s*(.+?)\s*$'){
        $rd = $matches[1].Trim()
        L ("rootDir=" + $rd)
        if(Test-Path $rd){ $rootDirs.Add($rd) }
      } elseif($line -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){
        $key = ($line -split '=',2)[0]
        L ($key + "=<REDACTED>")
      }
    }
  } catch { L ("READ ERROR: " + $_.Exception.Message) }
}

# Add exact paths suggested by the discovered v48 config and Windows virtualization.
$searchRoots = @(
  $rootDirs,
  "C:\Windows\System32",
  "C:\Windows\SysWOW64",
  "$env:LOCALAPPDATA\VirtualStore\Windows\System32",
  "$env:LOCALAPPDATA\VirtualStore\Windows\SysWOW64"
) | ForEach-Object { $_ } | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

H "SEARCH ROOTS"
foreach($r in $searchRoots){ L $r }

# Likely query/script/config file extensions used by MTest.
$exts = @(".qry",".scr",".ini",".cfg",".txt",".log")
$nameHints = @("mtest","query","qry","script")

H "CANDIDATE FILES"
$candidates = @()
foreach($r in $searchRoots){
  $candidates += Get-ChildItem -LiteralPath $r -File -ErrorAction SilentlyContinue |
    Where-Object {
      ($exts -contains $_.Extension.ToLowerInvariant()) -or
      ($nameHints | Where-Object { $_ -and ($_.Name -like "*$_*") })
    }
}
$candidates = $candidates | Sort-Object FullName -Unique
L ("CandidateFiles=" + (($candidates | Measure-Object).Count))
foreach($f in $candidates){
  L ($f.FullName + " | " + $f.Length + " bytes | " + $f.LastWriteTime)
}

H "QUERY / SCRIPT CONTENT"
$qryScr = $candidates | Where-Object { $_.Extension -in ".qry",".scr" }
L ("QryScrFiles=" + (($qryScr | Measure-Object).Count))

foreach($f in $qryScr){
  L ""
  L ("FILE: " + $f.FullName)
  try{
    $n=0
    foreach($line in Get-Content -LiteralPath $f.FullName -ErrorAction Stop){
      $n++
      $shown=$line
      if($shown -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){
        $shown=(($shown -split '=',2)[0]+"=<REDACTED>")
      }
      if($shown.Length -gt 1000){$shown=$shown.Substring(0,1000)+" ..."}
      L ("  ["+$n+"] "+$shown)
      if($n -ge 400){ L "  ... TRUNCATED AFTER 400 LINES ..."; break }
    }
  } catch { L ("  READ ERROR: " + $_.Exception.Message) }
}

H "MTEST/QUERY REFERENCES IN TEXT CONFIG"
$textCandidates = $candidates | Where-Object { $_.Extension -in ".ini",".cfg",".txt",".log" }
$patterns = @("qryString","lastQry","SUBMIT","TagHistory","Tag history","StartTime","EndTime","NumValues","Command Builder")
foreach($f in $textCandidates){
  try{
    $hits=Select-String -LiteralPath $f.FullName -Pattern $patterns -SimpleMatch -CaseSensitive:$false
    if($hits){
      L ""
      L ("FILE: " + $f.FullName)
      foreach($m in $hits){
        $txt=$m.Line
        if($txt -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){
          $txt=(($txt -split '=',2)[0]+"=<REDACTED>")
        }
        L ("  ["+$m.LineNumber+"] "+$txt)
      }
    }
  } catch {}
}

H "SUMMARY"
L "Read-only local scan of MTest rootDir and Windows VirtualStore equivalents."
L "No COM object created."
L "No MOPS/MQE server query executed."
L "No login attempted."
L "No file modified."
L "Password/token-like values are redacted."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
