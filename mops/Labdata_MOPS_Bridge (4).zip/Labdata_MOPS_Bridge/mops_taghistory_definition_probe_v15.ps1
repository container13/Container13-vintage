﻿# MOPS TagHistory definition probe v1.5 - READ ONLY
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_TAGHISTORY_DEFINITION_PROBE_v15.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
function Dump($obj,[string]$label){
 L ("-- "+$label+" --")
 if($null-eq $obj){L "<null>";return}
 try{$obj|Get-Member|ForEach-Object{L ("MEMBER "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{L ("Get-Member FEL="+$_.Exception.Message)}
 try{L ("Count="+$obj.Count)}catch{}
 $n=0
 try{
  foreach($x in $obj){
   $n++;L ("ITEM #"+$n)
   foreach($p in @("Name","Description","Type","DataType","Direction","Required","DefaultValue","Value")){
    try{L (" "+$p+"="+[string]$x.$p)}catch{}
   }
   try{$x|Get-Member|ForEach-Object{L (" ITEMMEMBER "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)}}catch{}
  }
 }catch{L ("Enumerering FEL="+$_.Exception.Message)}
 L ("Enumerated="+$n)
}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS TagHistory definition probe v1.5"
$c=$null
try{
 $c=New-Object -ComObject "MOPS.Connection";$c.ConnectionString="//HOIGIBMOCLAP12/";$c.Connect()
 L ("IsConnected="+$c.IsConnected)
 $hist=$null
 foreach($svc in $c.Browser.Services){if($svc.Name -eq "hist"){$hist=$svc;break}}
 $th=$null
 foreach($f in $hist.Functions){if($f.Name -eq "TagHistory"){$th=$f;break}}
 if($null-eq $th){L "FEL: TagHistory hittades inte";return}
 L "TagHistory hittad"
 Dump $th.Parameters "TagHistory.Parameters"
 Dump $th.Fields "TagHistory.Fields"
 L "KLAR"
}catch{L ("OVANTAT FEL="+$_.Exception.Message)}
finally{
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY. Ingen Execute(), login eller skrivning."
L ("Output="+$out)
