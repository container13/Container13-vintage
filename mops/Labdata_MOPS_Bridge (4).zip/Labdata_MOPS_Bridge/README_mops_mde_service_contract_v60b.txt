MOPS MDE Service Contract probe v6.0b

Fix av v60:
v60 försökte skapa fristående ServiceBrowser-objekt. Det fungerar inte i denna
MOPS-installation (CLASS_E_CLASSNOTAVAILABLE).

Tidigare fungerande probes visar den korrekta vägen:
MOPS.Connection.1
 -> Connection.Browser
 -> Browser.Refresh()
 -> Browser.Services
 -> service "mde"
 -> Functions

v60b använder exakt den vägen.

Endast metadata/schema läses.
Ingen servicefunktion körs.
Ingen Command.Execute.
Ingen Session.Open.
Ingen DDE.
Ingen skrivning.

Resultat:
C:\Users\<user>\Downloads\MOPS_MDE_SERVICE_CONTRACT_v60b.txt
