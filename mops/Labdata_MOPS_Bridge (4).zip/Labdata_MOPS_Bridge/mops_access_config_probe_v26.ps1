﻿# mops_access_config_probe_v26.ps1
# READ-ONLY.
# Fokuserar på de MOPS-specifika ledtrådarna som v25 hittade:
#   AC-FSC-Path -> \\hoigibmoclap12\winmops\config\winmops-users.xml
#   MOPSCallbackUser -> HOLMEN\sys_mopsIBCB
#   MOPS config/log-mappar
#
# Ingen Command.Execute()
# Ingen Session.Open()
# Ingen credential skrivs
# Ingen MOPS-data skrivs
# Lösenords-/secret-/tokenrader skrivs aldrig ut.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_ACCESS_CONFIG_PROBE_v26.txt"

function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function Sensitive([string]$s){return ($s -match '(?i)pass(word)?|pwd|secret|token|credential|hash|salt|private.?key')}

Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS Access/config probe v2.6"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity="+[System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

S "SYSTEM PROPERTIES"
$reg="HKLM:\SOFTWARE\WOW6432Node\MOPS Systems\System Properties"
try{
  $r=Get-ItemProperty $reg -ErrorAction Stop
  foreach($n in @("DefaultPortal","AC-FSC-Path","MOPSCallbackUser","ProgramDataDir","ConfigFilesDirectory","LogFilesDirectory","ErrorLogDirectory")){
    L ($n+"="+$r.$n)
  }
}catch{L("Registry FEL="+$_.Exception.Message)}

S "ACCESS CONTROL FILE - METADATA ONLY"
$ac="\\hoigibmoclap12\winmops\config\winmops-users.xml"
L ("Path="+$ac)
L ("TestPath="+(Test-Path $ac))
if(Test-Path $ac){
  try{
    $fi=Get-Item $ac
    L ("Length="+$fi.Length)
    L ("LastWriteTime="+$fi.LastWriteTime)
    L ("Attributes="+$fi.Attributes)

    $txt=Get-Content -LiteralPath $ac -Raw -ErrorAction Stop

    # Skriv INTE ut XML-innehåll. Rapportera bara struktur och säkra förekomster.
    try{
      [xml]$xml=$txt
      L ("XmlRoot="+$xml.DocumentElement.Name)
      $names=@()
      function Walk($node){
        if($null -eq $node){return}
        if($node.NodeType -eq [System.Xml.XmlNodeType]::Element){
          $script:names += $node.Name
        }
        foreach($ch in @($node.ChildNodes)){Walk $ch}
      }
      Walk $xml
      $uniq=@($names|Sort-Object -Unique)
      L ("ElementNames="+($uniq -join ", "))

      # Endast booleska träffar för användarnamn; inga omgivande XML-rader.
      L ("Contains_winmops="+($txt -match '(?i)(^|[^A-Za-z0-9_])winmops([^A-Za-z0-9_]|$)'))
      L ("Contains_iiblabl4="+($txt -match '(?i)iiblabl4'))
      L ("Contains_sys_mopsIBCB="+($txt -match '(?i)sys_mopsIBCB'))

      # Lista attributnamn men aldrig attributvärden.
      $attrs=@()
      $all=$xml.SelectNodes("//*")
      foreach($n in $all){
        foreach($a in @($n.Attributes)){
          if(-not (Sensitive $a.Name)){$attrs += $a.Name}
          else{$attrs += ($a.Name+"[SENSITIVE]")}
        }
      }
      L ("AttributeNames="+(($attrs|Sort-Object -Unique) -join ", "))
    }catch{
      L ("XML parse FEL="+$_.Exception.Message)
    }
  }catch{L("AC file read FEL="+$_.Exception.Message)}
}

S "MOPS CONFIG FILE INVENTORY"
$configRoots=@("C:\ProgramData\MOPS\config","C:\Program Files (x86)\MOPS\config")
foreach($root in $configRoots){
  L ("ROOT "+$root+" Exists="+(Test-Path $root))
  if(Test-Path $root){
    Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
      Sort-Object FullName |
      Select-Object -First 200 |
      ForEach-Object {L ("FILE "+$_.Length+" | "+$_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")+" | "+$_.FullName)}
  }
}

S "SAFE CONFIG HINTS"
$patterns=@("hist","MHISTSP","MPORTAL","TagBroker","Callback","Session","Access","FSC","HOIGIBMOCLAP12")
$seen=0
foreach($root in $configRoots){
 if(-not(Test-Path $root)){continue}
 Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
   Where-Object {$_.Length -lt 2MB -and $_.Extension -match '(?i)\.(ini|cfg|conf|config|xml|txt)$'} |
   ForEach-Object {
     if($seen -ge 160){return}
     try{
       $hits=@(Select-String -LiteralPath $_.FullName -SimpleMatch -Pattern $patterns -ErrorAction Stop|Select-Object -First 20)
       if($hits){
         L ("FILE "+$_.FullName)
         foreach($h in $hits){
           $line=$h.Line.Trim()
           if(Sensitive $line){L("  L"+$h.LineNumber+": <REDACTED SENSITIVE LINE>")}
           else{L("  L"+$h.LineNumber+": "+$line)}
           $seen++
           if($seen -ge 160){break}
         }
       }
     }catch{}
   }
}

S "RECENT MOPS SYSTEM LOGS - SAFE ERROR HINTS"
$logRoots=@("C:\ProgramData\MOPS\log","C:\Program Files (x86)\MOPS\log")
foreach($root in $logRoots){
 L ("ROOT "+$root+" Exists="+(Test-Path $root))
 if(Test-Path $root){
   Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
     Where-Object {$_.LastWriteTime -ge (Get-Date).AddDays(-3) -and $_.Length -lt 5MB} |
     Sort-Object LastWriteTime -Descending |
     Select-Object -First 40 |
     ForEach-Object{
       L ("LOG "+$_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")+" | "+$_.FullName)
       try{
         Select-String -LiteralPath $_.FullName -Pattern "RPC","hist","MHIST","callback","session","access","denied","error" -SimpleMatch -ErrorAction Stop |
           Select-Object -Last 15 |
           ForEach-Object{
             $line=$_.Line.Trim()
             if(Sensitive $line){L("  L"+$_.LineNumber+": <REDACTED SENSITIVE LINE>")}
             else{L("  L"+$_.LineNumber+": "+$line)}
           }
       }catch{}
     }
 }
}

S "NETWORK REACHABILITY - NO AUTH"
foreach($hostn in @("hoigibmoclap12")){
 try{
   $ips=[System.Net.Dns]::GetHostAddresses($hostn)
   L ($hostn+" IPs="+(($ips|%{$_.IPAddressToString}) -join ", "))
 }catch{L($hostn+" DNS FEL="+$_.Exception.Message)}
 foreach($port in @(135,445)){
   try{
     $tcp=New-Object Net.Sockets.TcpClient
     $iar=$tcp.BeginConnect($hostn,$port,$null,$null)
     $ok=$iar.AsyncWaitHandle.WaitOne(1500,$false)
     if($ok -and $tcp.Connected){$tcp.EndConnect($iar);L($hostn+":"+$port+" reachable=True")}
     else{L($hostn+":"+$port+" reachable=False")}
     $tcp.Close()
   }catch{L($hostn+":"+$port+" FEL="+$_.Exception.Message)}
 }
}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L "winmops-users.xml content was NOT dumped; only safe structure/presence checks."
L ("Output="+$out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
