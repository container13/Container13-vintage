﻿# Nya MOPS - first live history Execute probe v1.0
# READ-ONLY: one known tag, small time window. No login, no writes.
$ErrorActionPreference="Stop"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_HISTORY_EXECUTE_PROBE_v10.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue

L "MOPS History Execute probe v1.0"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Is64BitProcess="+[Environment]::Is64BitProcess)
L ""

$c=$null;$cmd=$null
try {
 L "1. Ansluter MOPS.Connection ..."
 $c=New-Object -ComObject "MOPS.Connection"
 $c.ConnectionString="//HOIGIBMOCLAP12/"
 $c.Connect()
 L ("   IsConnected="+$c.IsConnected)
 L ("   TagBroker="+$c.TagBroker)

 L "2. Skapar MOPS.Command och kopplar live Connection ..."
 $cmd=New-Object -ComObject "MOPS.Command"
 $cmd.Connection=$c
 L ("   Command.Connection.IsConnected="+$cmd.Connection.IsConnected)

 L "3. Forbereder EN read-only historikfraga ..."
 $cmd.ServiceName="History"
 $cmd.FunctionName="TagHistory"
 $p=$cmd.Parameters
 $now=Get-Date
 $from=$now.AddHours(-2)
 $p.Item("Tag").Value="22=3120=7264"
 $p.Item("StartTime").Value=$from
 $p.Item("EndTime").Value=$now
 L ("   Tag=22=3120=7264")
 L ("   StartTime="+$from.ToString("yyyy-MM-dd HH:mm:ss"))
 L ("   EndTime="+$now.ToString("yyyy-MM-dd HH:mm:ss"))

 L "4. Execute() ..."
 $result=$cmd.Execute($null,$false)
 L "   Execute() returnerade"
 if($null-eq $result){L "   Result=<null>"}
 else {
   L ("   ResultType="+$result.GetType().FullName)
   L ("   Result="+[string]$result)
 }
 L ""
 L "RESULTAT: Execute-proben klar."
}
catch {
 L ("FEL="+$_.Exception.Message)
 if($_.Exception.InnerException){L ("INNER="+$_.Exception.InnerException.Message)}
}
finally {
 if($null-ne $cmd){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd)}catch{}}
 if($null-ne $c){
   try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{}
   try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}
 }
}
L ""
L "READ-ONLY. En historikfraga mot kand tagg. Ingen login eller skrivning."
L ("Output="+$out)
