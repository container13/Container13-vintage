﻿# mops_mqe_query_shape_probe_v40.ps1
# READ-ONLY metadata/query-shape preparation for MQECOM.
# Destination is set to the confirmed MQE endpoint.
# Does NOT call DoTransaction(), Login(), ExecuteDDE(), Command.Execute(), Session.Open().
# No write/update object is created.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_QUERY_SHAPE_PROBE_v40.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}
Remove-Item $out -ErrorAction SilentlyContinue

L "MOPS MQE Query Shape probe v4.0"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

try{
 $q=New-Object -ComObject "Mqecom.MQEQuery.5"
 S "DESTINATION"
 L("Version="+$q.GetVersion())
 $r=$q.SetDestination("//HOIGIBMOCLAP12/?mqe")
 L("SetDestination="+$r)
 L("ErrorCode="+$q.GetErrorCode())
 L("ErrorType="+$q.GetErrorType())

 S "QUERY PROPERTY WRITE/READBACK - NO TRANSACTION"
 # Use the exact read-side TagHistory function already exposed by Browser.
 # Only configure the query object; no transaction is sent.
 $tests=@(
   @("Table","TagHistory"),
   @("Columns","Tag,Data,Time,Value,Status"),
   @("SelFunction","TagHistory"),
   @("SelParam",""),
   @("OrderingFunction",""),
   @("MaxRows",10)
 )
 foreach($t in $tests){
   $n=$t[0]; $v=$t[1]
   try{
     $q.$n=$v
     L("$n SET=$v | READBACK="+(P $q $n))
   }catch{
     L("$n SET FEL="+$_.Exception.Message+" | READBACK="+(P $q $n))
   }
 }

 S "ERROR STATE"
 try{L("ErrorCode="+$q.GetErrorCode())}catch{}
 try{L("ErrorType="+$q.GetErrorType())}catch{}
 try{
   $ec=$q.GetErrorCode()
   $et=$q.GetErrorType()
   L("ErrorString="+$q.GetErrorString([int16]$ec,[int16]$et))
 }catch{L("ErrorString FEL="+$_.Exception.Message)}

}catch{L("TOP FEL="+$_.Exception.Message)}

S "SUMMARY"
L "NO DoTransaction()"
L "NO Login()/LoginFromIni()"
L "NO MQE update object"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
