param([switch]$Worker,[string]$StopFile,[string]$OutputFile)
$ErrorActionPreference='Stop'
function AddLog([string]$path,[string]$text=''){Add-Content -LiteralPath $path -Value ((Get-Date -Format 'HH:mm:ss.fff')+' | '+$text) -Encoding UTF8}
function SafeText([string]$text){if($null-eq$text){return ''};return ($text-replace"`r?`n",' ' -replace"`t",' ')}

if($Worker){
  try{
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes
    AddLog $OutputFile 'WORKER_START'
    $seenProcesses=@{}
    $seenConnections=@{}
    $lastFocus=''
    $lastWindow=''
    $deadline=(Get-Date).AddMinutes(30)
    while(-not(Test-Path -LiteralPath $StopFile)-and(Get-Date)-lt$deadline){
      $mops=@(Get-Process -Name winmops -ErrorAction SilentlyContinue)
      $mopsIds=@($mops|ForEach-Object{$_.Id})
      foreach($p in$mops){
        if(-not$seenProcesses.ContainsKey($p.Id)){
          $seenProcesses[$p.Id]=$true
          AddLog $OutputFile ('PROCESS_START | Name='+$p.ProcessName+' | PID='+$p.Id+' | Path='+(SafeText $p.Path))
        }
        $windowKey=$p.Id.ToString()+'|'+$p.MainWindowTitle
        if($p.MainWindowTitle-and$windowKey-ne$lastWindow){AddLog $OutputFile ('WINDOW | PID='+$p.Id+' | Title='+(SafeText $p.MainWindowTitle));$lastWindow=$windowKey}
      }

      if($mopsIds.Count-gt0){
        try{
          $focused=[Windows.Automation.AutomationElement]::FocusedElement
          if($focused-and$mopsIds-contains$focused.Current.ProcessId){
            $isPassword=$false
            try{$isPassword=[bool]$focused.Current.IsPassword}catch{}
            if($isPassword){$name='[PASSWORD CONTROL REDACTED]'}else{$name=SafeText $focused.Current.Name}
            $focusKey=$focused.Current.ProcessId.ToString()+'|'+$focused.Current.ControlType.ProgrammaticName+'|'+$name+'|'+$focused.Current.AutomationId+'|'+$focused.Current.ClassName
            if($focusKey-ne$lastFocus){
              AddLog $OutputFile ('FOCUS | PID='+$focused.Current.ProcessId+' | Type='+$focused.Current.ControlType.ProgrammaticName+' | Name='+$name+' | AutomationId='+(SafeText $focused.Current.AutomationId)+' | Class='+(SafeText $focused.Current.ClassName)+' | IsPassword='+$isPassword)
              $lastFocus=$focusKey
            }
          }
        }catch{AddLog $OutputFile ('FOCUS_READ_ERROR | '+(SafeText $_.Exception.Message))}

        try{
          $lines=@(& "$env:SystemRoot\System32\netstat.exe" -ano -p tcp 2>$null)
          foreach($line in$lines){
            if($line-match'^\s*TCP\s+(\S+)\s+(\S+)\s+(\S+)\s+(\d+)\s*$'){
              $pidNumber=[int]$matches[4]
              if($mopsIds-contains$pidNumber){
                $key=$pidNumber.ToString()+'|'+$matches[1]+'|'+$matches[2]+'|'+$matches[3]
                if(-not$seenConnections.ContainsKey($key)){$seenConnections[$key]=$true;AddLog $OutputFile ('TCP | PID='+$pidNumber+' | Local='+$matches[1]+' | Remote='+$matches[2]+' | State='+$matches[3])}
              }
            }
          }
        }catch{AddLog $OutputFile ('TCP_READ_ERROR | '+(SafeText $_.Exception.Message))}

        try{
          $allProc=@(Get-CimInstance Win32_Process -ErrorAction Stop)
          foreach($child in$allProc){
            if(($mopsIds-contains([int]$child.ParentProcessId))-and(-not$seenProcesses.ContainsKey([int]$child.ProcessId))){
              $seenProcesses[[int]$child.ProcessId]=$true
              AddLog $OutputFile ('CHILD_PROCESS | Name='+(SafeText $child.Name)+' | PID='+$child.ProcessId+' | ParentPID='+$child.ParentProcessId+' | ExecutablePath='+(SafeText $child.ExecutablePath))
            }
          }
        }catch{}
      }
      Start-Sleep -Milliseconds 500
    }
    AddLog $OutputFile ('WORKER_STOP | StopSignal='+(Test-Path -LiteralPath $StopFile))
    foreach($p in@(Get-Process -Name winmops -ErrorAction SilentlyContinue)){
      try{foreach($module in$p.Modules){AddLog $OutputFile ('MODULE | PID='+$p.Id+' | Name='+$module.ModuleName+' | Path='+(SafeText $module.FileName))}}catch{AddLog $OutputFile ('MODULE_READ_ERROR | PID='+$p.Id+' | '+(SafeText $_.Exception.Message))}
    }
  }catch{AddLog $OutputFile ('WORKER_FATAL | '+(SafeText $_.Exception.Message))}
  exit
}

$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_SAVE_FLOW_v82.txt'
$stop=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_SAVE_FLOW_v82.stop'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $stop -ErrorAction SilentlyContinue
AddLog $out 'MOPS WinMOPS Login/Edit/Save Flow Recorder v8.2'
AddLog $out ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
AddLog $out 'PASSWORD_POLICY=Password values and keystrokes are never read or logged.'
AddLog $out 'RECORDER_MODE=Passive observation only; user performs all WinMOPS actions.'

$self=$MyInvocation.MyCommand.Path
$workerArgs='-NoProfile -ExecutionPolicy Bypass -STA -File "'+$self+'" -Worker -StopFile "'+$stop+'" -OutputFile "'+$out+'"'
$workerProcess=Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList $workerArgs -WindowStyle Hidden -PassThru
AddLog $out ('WorkerPID='+$workerProcess.Id)

$running=@(Get-Process -Name winmops -ErrorAction SilentlyContinue)
if($running.Count-eq0){
  $roots=@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'),[Environment]::GetFolderPath('StartMenu'),[Environment]::GetFolderPath('CommonStartMenu'))|Select-Object -Unique
  $links=@()
  foreach($root in$roots){if($root-and(Test-Path -LiteralPath $root)){$links+=@(Get-ChildItem -LiteralPath $root -Filter '*.lnk' -Recurse -ErrorAction SilentlyContinue|Where-Object{$_.BaseName-match'(?i)winmops|mops'})}}
  $link=$links|Sort-Object @{Expression={if($_.BaseName-match'(?i)winmops'){0}else{1}}},FullName|Select-Object -First 1
  if($link){
    $shell=New-Object -ComObject WScript.Shell
    $resolved=$shell.CreateShortcut($link.FullName)
    AddLog $out ('LaunchShortcut='+$link.FullName)
    AddLog $out ('LaunchTarget='+$resolved.TargetPath)
    Start-Process -FilePath $link.FullName
  }else{
    AddLog $out 'LaunchShortcut=NOT_FOUND; user must start WinMOPS manually.'
    Write-Host 'WinMOPS shortcut was not found. Start WinMOPS manually now.' -ForegroundColor Yellow
  }
}else{AddLog $out ('WinMOPSAlreadyRunning='+($running.Id-join','))}

Write-Host ''
Write-Host 'RECORDER IS RUNNING.' -ForegroundColor Green
Write-Host '1. Log in to WinMOPS manually.'
Write-Host '2. Navigate to the correct department.'
Write-Host '3. Enter a real authorized lab value and save normally.'
Write-Host '4. Return here after saving.'
[void](Read-Host 'Press ENTER only when the complete test is finished')
New-Item -ItemType File -Path $stop -Force|Out-Null
if(-not$workerProcess.WaitForExit(15000)){AddLog $out 'WorkerStopTimeout=True'}
$note=Read-Host 'Optional: type the lab value or a short note for correlation, then ENTER'
if($note){AddLog $out ('USER_NOTE='+(SafeText $note))}
AddLog $out 'SESSION_COMPLETE'
Remove-Item -LiteralPath $stop -ErrorAction SilentlyContinue
Write-Host ''
Write-Host 'DONE - send this file:' -ForegroundColor Green
Write-Host $out
