﻿# mops_dde_open_probe_v36.ps1
# Kontrollerat DDE-test mot den redan körande WinMOPS-instansen.
# Testet öppnar endast en BEFINTLIG WinMOPS .mcd-fil via samma DDE "open"-mekanism
# som Windows själv använder för WinMOPS.Document.
#
# Ingen Command.Execute()
# Ingen Session.Open()
# Inga credentials sätts
# Ingen MOPS-data skrivs
# Ingen save-funktion anropas

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_DDE_OPEN_PROBE_v36.txt"

function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function S([string]$s){ L ""; L ("===== " + $s + " =====") }
function P($o,[string]$n){
    try {
        $v = $o.$n
        if($null -eq $v){ return "<null>" }
        return [string]$v
    } catch {
        return "<ERR: " + $_.Exception.Message + ">"
    }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

L "MOPS DDE open probe v3.6"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

# Kända, read-only kandidater från WinMOPS-konfiguration/prober.
$candidates = @(
    "\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata.mcd",
    "\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd",
    "I:\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata.mcd"
)

S "TARGET FILE"
$target = $null
foreach($p in $candidates){
    $ok = $false
    try { $ok = Test-Path -LiteralPath $p } catch {}
    L ("Candidate=" + $p + " | Exists=" + $ok)
    if($ok -and -not $target){ $target = $p }
}

if(-not $target){
    L "NO EXISTING TARGET FOUND - ExecuteDDE WILL NOT BE CALLED."
} else {
    L ("SelectedTarget=" + $target)
}

S "WINMOPS BEFORE"
$before = $null
try {
    $before = Get-Process winmops -ErrorAction Stop | Select-Object -First 1
    L ("PID=" + $before.Id)
    L ("MainWindowTitle=" + $before.MainWindowTitle)
} catch {
    L ("WinMOPS process FEL=" + $_.Exception.Message)
}

$d = $null
try {
    S "DDE INITIALIZE"
    $d = New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
    L ("IsWinMOPSRunning.Before=" + (P $d "IsWinMOPSRunning"))
    L ("IsInitialized.Before=" + (P $d "IsInitialized"))

    $d.Initialize()
    L "Initialize=OK"
    L ("IsInitialized.After=" + (P $d "IsInitialized"))

    if($target){
        S "DDE OPEN EXISTING MCD"
        # Registry grammar for WinMOPS.Document: [open("%1")]
        $dde = '[open("' + $target + '")]'
        L ("DDECommand=" + $dde)
        L "Calling ExecuteDDE once..."
        try {
            $d.ExecuteDDE($dde)
            L "ExecuteDDE=OK"
        } catch {
            L ("ExecuteDDE=FEL: " + $_.Exception.Message)
            try { L ("HRESULT=0x{0:X8}" -f ([uint32]$_.Exception.HResult)) } catch {}
        }

        Start-Sleep -Milliseconds 1200

        S "WINMOPS AFTER"
        try {
            $after = Get-Process winmops -ErrorAction Stop | Select-Object -First 1
            L ("PID=" + $after.Id)
            L ("MainWindowTitle=" + $after.MainWindowTitle)
            L ("SamePID=" + ($before -and ($before.Id -eq $after.Id)))
        } catch {
            L ("WinMOPS process FEL=" + $_.Exception.Message)
        }
    }

} catch {
    L ("TOP FEL=" + $_.Exception.Message)
} finally {
    if($d){
        S "DDE CLEANUP"
        try {
            $d.Cleanup()
            L "Cleanup=OK"
            L ("IsInitialized.AfterCleanup=" + (P $d "IsInitialized"))
        } catch {
            L ("Cleanup=FEL: " + $_.Exception.Message)
        }
    }
}

S "SUMMARY"
if($target){
    L "ExecuteDDE() WAS called once with WinMOPS [open()] for an existing .mcd file."
} else {
    L "ExecuteDDE() was NOT called because no known existing .mcd file was found."
}
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS write/save function called"
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
