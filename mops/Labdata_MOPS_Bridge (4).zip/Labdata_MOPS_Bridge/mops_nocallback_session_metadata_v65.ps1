﻿$ErrorActionPreference = "Continue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_NOCALLBACK_SESSION_METADATA_v65.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s = "") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Members($o, [string]$label) {
    L ("-- " + $label + " --")
    try {
        $o | Get-Member | Sort-Object MemberType, Name | ForEach-Object {
            L ("  {0} {1} :: {2}" -f $_.MemberType, $_.Name, $_.Definition)
        }
    } catch { L ("  GetMemberError=" + $_.Exception.Message) }
}
function SafeProperty($o, [string]$name) {
    try {
        $value = $o.$name
        if ($null -eq $value) { return '<null>' }
        return [string]$value
    } catch { return ('<unavailable> | ' + $_.Exception.Message) }
}
function DumpKey([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    L ("Key=" + $path)
    try {
        $item = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
        foreach ($p in $item.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }) {
            L ("  {0}={1}" -f $p.Name, [string]$p.Value)
        }
        Get-ChildItem -LiteralPath $path -ErrorAction SilentlyContinue | ForEach-Object {
            L ("  SubKey=" + $_.PSChildName)
            $sub = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
            foreach ($p in $sub.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }) {
                L ("    {0}={1}" -f $p.Name, [string]$p.Value)
            }
        }
    } catch { L ("  RegistryReadError=" + $_.Exception.Message) }
}
function ExtractTargetStrings([string]$path) {
    L ("-- File=" + $path)
    if (-not (Test-Path -LiteralPath $path)) { L "  Missing"; return }
    try {
        $bytes = [IO.File]::ReadAllBytes($path)
        $ascii = [Text.Encoding]::ASCII.GetString($bytes)
        $unicode = [Text.Encoding]::Unicode.GetString($bytes)
        $pattern = '(?i)[ -~]{4,180}(callback|detach|session|async|execute|immediate|service provider|commandtype)[ -~]{0,180}'
        $hits = New-Object System.Collections.Generic.List[string]
        foreach ($text in @($ascii, $unicode)) {
            foreach ($m in [regex]::Matches($text, $pattern)) {
                $s = ($m.Value -replace '\s+', ' ').Trim()
                if ($s.Length -gt 220) { $s = $s.Substring(0, 220) }
                if ($s -and -not $hits.Contains($s)) { [void]$hits.Add($s) }
            }
        }
        if ($hits.Count -eq 0) { L "  No target strings found." }
        foreach ($s in $hits | Select-Object -First 250) { L ("  " + $s) }
        if ($hits.Count -gt 250) { L ("  ... truncated; total unique hits=" + $hits.Count) }
    } catch { L ("  StringScanError=" + $_.Exception.Message) }
}

$session = $null
$connection = $null
$command = $null
$recordset = $null

try {
    L "MOPS NoCallback/Session Metadata Probe v6.5"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
    L "PURPOSE=Identify documented COM/session/callback controls before any further Execute test."

    if ([Environment]::Is64BitProcess) {
        throw "64-bit process detected. This probe requires 32-bit Windows PowerShell."
    }

    L ""
    L "===== COM CLASS REGISTRATION ====="
    $classes = [ordered]@{
        'MOPS.Connection.1' = '{69B558C2-0464-11D2-8E1D-0060B0B5BE47}'
        'MOPS.Command.1'    = '{69B558C1-0464-11D2-8E1D-0060B0B5BE47}'
        'MOPS.RecordSet.1'  = '{C1C2BA83-005D-11D2-8E1C-0060B0B5BE47}'
        'MOPS.Session.1'    = '{B4DAF181-B99A-43B6-BD21-B2114D5AB461}'
    }
    foreach ($entry in $classes.GetEnumerator()) {
        L ("-- ProgID=" + $entry.Key + " CLSID=" + $entry.Value)
        foreach ($root in @(
            'Registry::HKEY_CLASSES_ROOT\CLSID',
            'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID',
            'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID'
        )) { DumpKey (Join-Path $root $entry.Value) }
    }

    L ""
    L "===== COM AUTOMATION MEMBERS - OBJECTS CREATED, NOTHING OPENED ====="
    $connection = New-Object -ComObject 'MOPS.Connection.1'
    $command = New-Object -ComObject 'MOPS.Command.1'
    $recordset = New-Object -ComObject 'MOPS.RecordSet.1'
    $session = New-Object -ComObject 'MOPS.Session.1'
    Members $connection 'MOPS.Connection.1'
    Members $command 'MOPS.Command.1'
    Members $recordset 'MOPS.RecordSet.1'
    Members $session 'MOPS.Session.1'

    L ""
    L "===== SAFE DEFAULT PROPERTY VALUES ====="
    L ('Command.CommandType=' + (SafeProperty $command 'CommandType'))
    L ('Command.Context=' + (SafeProperty $command 'Context'))
    L ('Command.Session=' + (SafeProperty $command 'Session'))
    L ('RecordSet.Idle=' + (SafeProperty $recordset 'Idle'))
    L ('RecordSet.AllowsUpdates=' + (SafeProperty $recordset 'AllowsUpdates'))

    L ""
    L "===== TARGETED LOCAL BINARY STRINGS ====="
    $bin = Join-Path ${env:ProgramFiles(x86)} 'MOPS\sys\bin'
    foreach ($name in @('mclient.dll', 'mportalps.dll', 'MDEGrid.mcx', 'winmops.exe')) {
        ExtractTargetStrings (Join-Path $bin $name)
    }

    L ""
    L "===== SAFETY ====="
    L "Local COM registration, member metadata, default properties, and binary strings only."
    L "COM objects were instantiated only to enumerate their automation members."
    L "No Connection.Connect."
    L "No Session.Open."
    L "No CommandText set and no Execute."
    L "No Browser.Refresh and no service function."
    L "No DDE."
    L "No MCD opened, modified, or saved."
    L "No Update/Insert/Delete/Write/Save."
} catch {
    L ""
    L ("ERROR=" + $_.Exception.Message)
    try { L ("HRESULT=0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff)) } catch {}
} finally {
    foreach ($o in @($session, $recordset, $command, $connection)) {
        if ($null -ne $o) { try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o) } catch {} }
    }
    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
