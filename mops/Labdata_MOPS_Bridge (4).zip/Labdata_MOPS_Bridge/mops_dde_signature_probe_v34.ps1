﻿# mops_dde_signature_probe_v34.ps1
# READ-ONLY introspection of WinMOPS DDE helper COM type information.
# Does NOT call Initialize(), ExecuteDDE(), Session.Open(), or Command.Execute().

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_DDE_SIGNATURE_PROBE_v34.txt"
function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}

Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS DDE signature probe v3.4"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

S "DDE HELPER"
try{
 $d=New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
 L("Created=True")
 L("IsWinMOPSRunning="+$d.IsWinMOPSRunning)
 L("IsInitialized="+$d.IsInitialized)
 L("WinMOPSExecPath="+$d.WinMOPSExecPath)

 S "POWERSHELL METHOD DEFINITIONS"
 foreach($n in @("Initialize","ExecuteDDE","Cleanup")){
  try{
   $m=$d.PSObject.Methods[$n]
   L($n+"="+$m.Definition)
   try{
    L($n+".OverloadDefinitions:")
    foreach($x in $m.OverloadDefinitions){L("  "+$x)}
   }catch{}
  }catch{L($n+" FEL="+$_.Exception.Message)}
 }

 S "COM TYPELIB REGISTRY"
 $prog=@("MOPS.WinMOPSDDEHelper","MOPS.WinMOPSDDEHelper.1")
 foreach($pr in $prog){
  foreach($base in @("Registry::HKEY_CLASSES_ROOT","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes")){
   $k="$base\$pr"
   if(Test-Path $k){
    L("KEY="+$k)
    try{
     $cls=(Get-ItemProperty "$k\CLSID" -ErrorAction Stop)."(default)"
     if(!$cls){$cls=(Get-Item "$k\CLSID").GetValue("")}
     L("CLSID="+$cls)
     if($cls){
      foreach($cb in @("Registry::HKEY_CLASSES_ROOT\CLSID\$cls","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID\$cls")){
       if(Test-Path $cb){
        L("CLSIDKEY="+$cb)
        try{L("Default="+(Get-Item $cb).GetValue(""))}catch{}
        foreach($sub in @("InprocServer32","LocalServer32","ProgID","TypeLib","Version")){
         if(Test-Path "$cb\$sub"){
          try{L($sub+"="+(Get-Item "$cb\$sub").GetValue(""))}catch{}
         }
        }
       }
      }
     }
    }catch{L("CLSID lookup FEL="+$_.Exception.Message)}
   }
  }
 }

 S "WINMOPS DOCUMENT REGISTRY"
 foreach($base in @("Registry::HKEY_CLASSES_ROOT","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes")){
  $k="$base\WinMOPS.Document"
  if(Test-Path $k){
   L("KEY="+$k)
   try{L("Default="+(Get-Item $k).GetValue(""))}catch{}
   Get-ChildItem $k -Recurse -ErrorAction SilentlyContinue|Select-Object -First 50|%{
    try{L($_.PSPath+" | "+(Get-Item $_.PSPath).GetValue(""))}catch{}
   }
  }
 }

}catch{L("TOP FEL="+$_.Exception.Message)}

S "SUMMARY"
L "NO Initialize()"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
