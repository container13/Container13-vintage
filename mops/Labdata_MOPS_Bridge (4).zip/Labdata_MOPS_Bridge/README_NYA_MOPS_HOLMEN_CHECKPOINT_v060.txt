NYA MOPS HOLMEN – CHECKPOINT v0.60
Datum: 2026-09-08

Utgångspunkt:
- v0.59 responsiv bredd + höjd.

Ändrat i v0.60:
- Datumetiketten anpassas efter hur många timrader datumblocket faktiskt omfattar.
- Färre än 8 synliga timmar: kort format, t.ex. "7 sep".
- 8 eller fler synliga timmar: lång form, t.ex. "måndag den 7 sep 2026".
- Detta sker automatiskt när den rullande 25-timmarsvyn ändras.

INTE ändrat:
- MOPS-/data-/connect-/bridge-/login-/historik-/sparlogik.
- TABDATA/taggregister.
- Responsiv bredd/höjd från v0.58/v0.59.
- Bridge v15.
