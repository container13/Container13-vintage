﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDEGRID_COMPONENT_SCAN_v57.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s){ L ""; L ("===== " + $s + " =====") }

L "MOPS MDEGrid Component Scan v5.7"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

H "ACTIVE MCD FACTS"
L 'Object=MDEGrid'
L 'StoredVersion=14.1.57.20274/NotSet'
L 'MOPSPortal=LoginNode'
L 'MOPSPortalUsed=//HOIGIBMOCLAP12/'
L 'MDESPName=mde'
L 'Department=22'
L 'Areas=1'
L 'Locations=2'
L 'PeriodName=Timme'
L 'NumDataPeriods=24'
L 'RefreshFrequency=60'
L 'SelectedTag=hist::22=3120=7210-B'
L 'InputTrigging=1'
L 'GetDataOnOpen=0'

H "REGISTRY - MDEGRID"
$roots = @(
  "Registry::HKEY_CLASSES_ROOT",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes"
)
$seen = @{}
foreach($root in $roots){
    if(Test-Path $root){
        Get-ChildItem $root -ErrorAction SilentlyContinue | Where-Object {
            $_.PSChildName -match '(?i)MDEGrid'
        } | ForEach-Object {
            $p=$_.PSPath
            if(-not $seen.ContainsKey($p)){
                $seen[$p]=$true
                L ("Key=" + $p)
                try{
                    $v=Get-ItemProperty $p
                    foreach($prop in $v.PSObject.Properties){
                        if($prop.Name -notmatch '^PS'){
                            L ("  " + $prop.Name + "=" + $prop.Value)
                        }
                    }
                }catch{}
                foreach($sub in @("CLSID","ProgID","InprocServer32","TypeLib","Version")){
                    $sp=Join-Path $p $sub
                    if(Test-Path $sp){
                        try{
                            $sv=Get-ItemProperty $sp
                            L ("  " + $sub + "=" + $sv.'(default)')
                        }catch{}
                    }
                }
            }
        }
    }
}

H "CLSID NAMES CONTAINING MDEGRID"
$clsRoots=@(
 "Registry::HKEY_CLASSES_ROOT\CLSID",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID"
)
foreach($cr in $clsRoots){
    if(Test-Path $cr){
        Get-ChildItem $cr -ErrorAction SilentlyContinue | ForEach-Object {
            try{
                $d=(Get-ItemProperty $_.PSPath).'(default)'
                if($d -match '(?i)MDEGrid'){
                    L ("CLSID=" + $_.PSChildName + " | Name=" + $d)
                    $ip=Join-Path $_.PSPath "InprocServer32"
                    if(Test-Path $ip){
                        $dll=(Get-ItemProperty $ip).'(default)'
                        L ("  InprocServer32=" + $dll)
                    }
                    $pr=Join-Path $_.PSPath "ProgID"
                    if(Test-Path $pr){ L ("  ProgID=" + (Get-ItemProperty $pr).'(default)') }
                    $tl=Join-Path $_.PSPath "TypeLib"
                    if(Test-Path $tl){ L ("  TypeLib=" + (Get-ItemProperty $tl).'(default)') }
                }
            }catch{}
        }
    }
}

H "MOPS BINARIES / COMPONENTS"
$bin = "C:\Program Files (x86)\MOPS\sys\bin"
$cands = @()
if(Test-Path $bin){
    $cands = @(Get-ChildItem $bin -File -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -match '(?i)(mde|grid|mops3i|maccess)' -or $_.Extension -match '(?i)\.(mcx|ocx|dll)$'
    })
    foreach($f in $cands | Sort-Object Name){
        if($f.Name -match '(?i)(mde|grid)'){
            $vi=$f.VersionInfo
            L ("Candidate=" + $f.FullName + " | " + $f.Length + " bytes | FileVersion=" + $vi.FileVersion)
        }
    }
}

H "TARGETED BINARY STRING HITS"
$terms='MDEGrid|MDESPName|GetDataOnOpen|NumDataPeriods|RefreshFrequency|DoSaveGridData|DoRefresh|SelectedTag|PeriodCriteria|GetDepartments|GetDepartmentAreas|GetAreaLocations|GetPeriods'
foreach($f in $cands){
    try{
        # Limit to likely binaries to keep this fast.
        if($f.Length -gt 12000000){ continue }
        [byte[]]$bb=[IO.File]::ReadAllBytes($f.FullName)
        $sb=New-Object Text.StringBuilder
        $hits=New-Object Collections.Generic.List[string]
        foreach($x in $bb){
            if($x -ge 32 -and $x -le 126){
                [void]$sb.Append([char]$x)
            }else{
                if($sb.Length -ge 4){
                    $s=$sb.ToString()
                    if($s -match $terms){$hits.Add($s)}
                }
                [void]$sb.Clear()
            }
        }
        if($hits.Count -gt 0){
            L ("--- File=" + $f.FullName + " | Hits=" + $hits.Count + " ---")
            foreach($s in ($hits | Sort-Object -Unique)){
                $t=$s
                if($t -match '(?i)(password|passwd|pwd|token|secret)'){ continue }
                if($t.Length -gt 500){$t=$t.Substring(0,500)+"..."}
                L $t
            }
        }
    }catch{}
}

H "SAFETY"
L "Local registry and binary metadata/string inspection only."
L "No COM object created."
L "No WinMOPS/DDE action."
L "No server connection/login/query."
L "No Execute/Submit/Update/Write."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
