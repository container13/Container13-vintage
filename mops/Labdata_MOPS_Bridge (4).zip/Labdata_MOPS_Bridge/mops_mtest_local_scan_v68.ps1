﻿$ErrorActionPreference = 'Continue'

$out = Join-Path $env:USERPROFILE 'Downloads\MOPS_MTEST_LOCAL_SCAN_v68.txt'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
function L([string]$s='') { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Redact([string]$s) {
    if ($s -match '(?i)(password|passwd|pwd|secret|token|credential)\s*=') {
        return (($s -split '=',2)[0] + '=<filtered>')
    }
    return $s
}
function ExtractContext([string]$path) {
    L ('-- Binary=' + $path)
    try {
        $bytes=[IO.File]::ReadAllBytes($path)
        L ('  Length=' + $bytes.Length)
        L ('  SHA256=' + (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash)
        foreach($enc in @([Text.Encoding]::ASCII,[Text.Encoding]::Unicode)) {
            $strings=@([regex]::Matches($enc.GetString($bytes),'[\x20-\x7E]{4,260}') | ForEach-Object {$_.Value.Trim()})
            $idx=New-Object System.Collections.Generic.HashSet[int]
            for($i=0;$i -lt $strings.Count;$i++) {
                if($strings[$i] -match '(?i)(Create.?Session|SessionString|No.?CallBack|Immediate.?Detach|CallbackHandler|ReturnSP|bNo|bDetach|CommandType)') {
                    for($j=[Math]::Max(0,$i-10);$j -le [Math]::Min($strings.Count-1,$i+10);$j++){[void]$idx.Add($j)}
                }
            }
            L ('  Encoding=' + $enc.WebName + ' | Strings=' + $strings.Count + ' | ContextRows=' + $idx.Count)
            foreach($i in ($idx|Sort-Object)){L ('    S[{0}] {1}' -f $i,$strings[$i])}
        }
    } catch { L ('  ScanError=' + $_.Exception.Message) }
}

try {
    L 'MOPS MTest Local Scan v6.8'
    L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ('Is64BitProcess='+[Environment]::Is64BitProcess)
    L 'PURPOSE=Find official MTest session/no-callback implementation locally.'

    L ''
    L '===== MOPS-RELATED ENVIRONMENT ====='
    Get-ChildItem Env: | Where-Object {$_.Name -match '(?i)(MOPS|ROOT|TI_)'} | Sort-Object Name | ForEach-Object {
        L ($_.Name+'='+(Redact ([string]$_.Value)))
    }

    L ''
    L '===== MTEST EXECUTABLES AND FILES ====='
    $roots=@(
        (Join-Path ${env:ProgramFiles(x86)} 'MOPS'),
        (Join-Path $env:ProgramData 'MOPS'),
        (Join-Path $env:APPDATA 'MOPS'),
        (Join-Path $env:LOCALAPPDATA 'MOPS')
    ) | Where-Object {$_ -and (Test-Path -LiteralPath $_)} | Select-Object -Unique
    $candidates=@()
    foreach($root in $roots) {
        $candidates += Get-ChildItem -LiteralPath $root -File -Recurse -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '(?i)(mtest|mops.?test)' -or
            ($_.Extension -match '(?i)\.(ini|scr|qry)$' -and $_.FullName -match '(?i)mops')
        }
    }
    $candidates=$candidates|Sort-Object FullName -Unique
    if(-not $candidates){L 'No candidate files found.'}
    foreach($f in $candidates){L ('File={0} | Length={1} | Modified={2}' -f $f.FullName,$f.Length,$f.LastWriteTime)}

    L ''
    L '===== TEXT CONFIG CONTEXT ====='
    foreach($f in $candidates | Where-Object {$_.Extension -match '(?i)\.(ini|scr|qry|txt)$'}) {
        try {
            $hits=Select-String -LiteralPath $f.FullName -Pattern '(?i)(session|callback|detach|commandtype|lastconnect|query)' -Context 3,3 -ErrorAction SilentlyContinue
            if($hits){
                L ('-- File='+$f.FullName)
                foreach($h in $hits|Select-Object -First 200){L ('  '+(Redact $h.Line))}
            }
        } catch { L ('TextReadError='+$f.FullName+' | '+$_.Exception.Message) }
    }

    L ''
    L '===== MTEST BINARY CONTEXT ====='
    foreach($f in $candidates | Where-Object {$_.Extension -ieq '.exe'}) {ExtractContext $f.FullName}

    L ''
    L '===== SAFETY ====='
    L 'Local environment, filenames, selected text context, and binary strings only.'
    L 'No executable launched and no COM object created.'
    L 'No network, Connect, Session.Open, CommandText, Execute, DDE, or MCD access.'
    L 'No Update/Insert/Delete/Write/Save.'
} catch {L ('ERROR='+$_.Exception.Message)} finally {L ('Output='+$out)}

Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
