﻿# mops_auth_session_artifact_probe_v25.ps1
# READ-ONLY.
# Syfte: hitta spår av WinMOPS-applikationsinloggningen (winmops) och eventuell
# sessions-/RPC-kontext som skiljer sig från Windows-identiteten HOLMEN\iiblabl4.
#
# Ingen Command.Execute()
# Ingen Session.Open()
# Inga credentials skrivs
# Ingen MOPS-data skrivs
#
# Känsliga värden (password/pwd/token/secret) maskeras i loggen.

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_AUTH_SESSION_ARTIFACT_PROBE_v25.txt"

function L([string]$s="") {
    Add-Content -LiteralPath $out -Value $s -Encoding UTF8
}
function S([string]$s) {
    L ""
    L ("===== " + $s + " =====")
}
function RedactNameValue([string]$name, $value) {
    if ($name -match '(?i)pass|pwd|secret|token|credential|key') {
        return "<REDACTED>"
    }
    if ($null -eq $value) { return "<null>" }
    return [string]$value
}
function SafeProp($obj,[string]$name) {
    try {
        $v = $obj.$name
        return (RedactNameValue $name $v)
    } catch {
        return "<ERR: $($_.Exception.Message)>"
    }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

L "MOPS Auth/session artifact probe v2.5"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Computer=" + $env:COMPUTERNAME)
L ("WindowsIdentity=" + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

S "WINMOPS PROCESS / WMI"
try {
    $wps = @(Get-CimInstance Win32_Process -Filter "Name='winmops.exe'" -ErrorAction Stop)
    if ($wps.Count -eq 0) {
        L "winmops.exe=<not running>"
    } else {
        foreach ($p in $wps) {
            L ("PID=" + $p.ProcessId)
            L ("ParentPID=" + $p.ParentProcessId)
            L ("SessionId=" + $p.SessionId)
            L ("ExecutablePath=" + $p.ExecutablePath)
            L ("CommandLine=" + $p.CommandLine)
            try {
                $owner = Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction Stop
                L ("ProcessOwner=" + $owner.Domain + "\" + $owner.User)
            } catch {
                L ("ProcessOwner=<ERR: " + $_.Exception.Message + ">")
            }
        }
    }
} catch {
    L ("WMI/CIM FEL=" + $_.Exception.Message)
}

S "NAMED PIPES"
try {
    $pipes = @(Get-ChildItem \\.\pipe\ -ErrorAction Stop |
        Where-Object { $_.Name -match '(?i)mops|winmops|portal|broker|hist|rpc' } |
        Sort-Object Name)
    if ($pipes.Count -eq 0) {
        L "<inga matchande pipes>"
    } else {
        foreach ($p in $pipes) { L ("PIPE " + $p.Name) }
    }
} catch {
    L ("Pipe enumeration FEL=" + $_.Exception.Message)
}

S "RUNNING OBJECT TABLE (ROT)"
try {
$src = @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

public static class RotDump {
    [DllImport("ole32.dll")]
    static extern int GetRunningObjectTable(int reserved, out IRunningObjectTable pprot);

    [DllImport("ole32.dll", CharSet=CharSet.Unicode)]
    static extern int CreateBindCtx(int reserved, out IBindCtx ppbc);

    public static string[] GetDisplayNames() {
        var names = new List<string>();
        IRunningObjectTable rot;
        if (GetRunningObjectTable(0, out rot) != 0 || rot == null)
            return names.ToArray();

        IEnumMoniker enumMoniker;
        rot.EnumRunning(out enumMoniker);
        enumMoniker.Reset();

        IBindCtx bindCtx;
        CreateBindCtx(0, out bindCtx);

        IMoniker[] monikers = new IMoniker[1];
        IntPtr fetched = Marshal.AllocCoTaskMem(4);
        try {
            while (enumMoniker.Next(1, monikers, fetched) == 0) {
                try {
                    string name;
                    monikers[0].GetDisplayName(bindCtx, null, out name);
                    names.Add(name ?? "<null>");
                } catch {
                    names.Add("<display-name-error>");
                }
            }
        } finally {
            Marshal.FreeCoTaskMem(fetched);
        }
        return names.ToArray();
    }
}
"@
    Add-Type -TypeDefinition $src -ErrorAction Stop
    $all = [RotDump]::GetDisplayNames()
    $hits = @($all | Where-Object { $_ -match '(?i)mops|winmops|portal|broker|hist|mde' })
    L ("ROT total=" + $all.Count)
    if ($hits.Count -eq 0) {
        L "<inga MOPS-liknande ROT entries>"
    } else {
        foreach ($n in $hits) { L ("ROT " + $n) }
    }
} catch {
    L ("ROT FEL=" + $_.Exception.Message)
}

S "REGISTRY - MOPS/WINMOPS"
$roots = @(
    "HKCU:\Software",
    "HKLM:\SOFTWARE\WOW6432Node",
    "HKLM:\SOFTWARE"
)

foreach ($root in $roots) {
    L ("ROOT " + $root)
    try {
        $keys = @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue |
            Where-Object { $_.PSChildName -match '(?i)mops|winmops' })

        foreach ($k in $keys) {
            L ("KEY " + $k.PSPath)
            try {
                $props = Get-ItemProperty -LiteralPath $k.PSPath -ErrorAction Stop
                foreach ($pn in $props.PSObject.Properties.Name) {
                    if ($pn -match '^PS(Path|ParentPath|ChildName|Drive|Provider)$') { continue }
                    L ("  " + $pn + "=" + (RedactNameValue $pn $props.$pn))
                }
            } catch {
                L ("  read FEL=" + $_.Exception.Message)
            }

            try {
                Get-ChildItem -LiteralPath $k.PSPath -Recurse -ErrorAction SilentlyContinue |
                    Select-Object -First 120 |
                    ForEach-Object {
                        L ("SUBKEY " + $_.PSPath)
                        try {
                            $sp = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction Stop
                            foreach ($pn in $sp.PSObject.Properties.Name) {
                                if ($pn -match '^PS(Path|ParentPath|ChildName|Drive|Provider)$') { continue }
                                L ("  " + $pn + "=" + (RedactNameValue $pn $sp.$pn))
                            }
                        } catch {}
                    }
            } catch {}
        }
    } catch {
        L ("Registry FEL=" + $_.Exception.Message)
    }
}

S "RECENT MOPS/WINMOPS CONFIG FILES"
$scanRoots = @(
    "$env:APPDATA",
    "$env:LOCALAPPDATA",
    "C:\ProgramData",
    "C:\Program Files (x86)\MOPS"
)

$since = (Get-Date).AddDays(-14)
$count = 0

foreach ($root in $scanRoots) {
    if (-not (Test-Path $root)) { continue }
    try {
        Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.LastWriteTime -ge $since -and
                $_.Length -lt 5MB -and
                (
                    $_.FullName -match '(?i)mops|winmops|portal|broker|hist' -or
                    $_.Name -match '(?i)mops|winmops|portal|broker|hist'
                )
            } |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 120 |
            ForEach-Object {
                L ("FILE " + $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") +
                   " | " + $_.Length + " bytes | " + $_.FullName)
                $count++
            }
    } catch {}
}
L ("RecentFileCount=" + $count)

S "TEXT HINTS IN SMALL CONFIG FILES"
$patterns = @(
    "winmops",
    "UserName",
    "Username",
    "Domain",
    "Session",
    "TagBroker",
    "HOIGIBMOCLAP12"
)

$seen = 0
foreach ($root in $scanRoots) {
    if (-not (Test-Path $root)) { continue }

    try {
        Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Length -lt 2MB -and
                $_.Extension -match '(?i)\.(ini|cfg|conf|config|xml|txt|json)$' -and
                (
                    $_.FullName -match '(?i)mops|winmops|portal|broker' -or
                    $_.DirectoryName -match '(?i)mops|winmops'
                )
            } |
            ForEach-Object {
                if ($seen -ge 120) { return }
                try {
                    $matches = @(Select-String -LiteralPath $_.FullName -SimpleMatch -Pattern $patterns -ErrorAction Stop |
                        Select-Object -First 12)
                    if ($matches.Count -gt 0) {
                        L ("FILE " + $_.FullName)
                        foreach ($m in $matches) {
                            $line = $m.Line.Trim()
                            if ($line -match '(?i)pass|pwd|secret|token|credential') {
                                $line = "<REDACTED LINE>"
                            }
                            L ("  L" + $m.LineNumber + ": " + $line)
                            $seen++
                            if ($seen -ge 120) { break }
                        }
                    }
                } catch {}
            }
    } catch {}
}

S "MOPS CONNECTION IDENTITY (NO SESSION OPEN)"
$c = $null
try {
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    $c.Connect()

    L ("IsConnected=" + (SafeProp $c "IsConnected"))
    L ("ConnectionString=" + (SafeProp $c "ConnectionString"))
    L ("TagBroker=" + (SafeProp $c "TagBroker"))
    L ("ServerTime=" + (SafeProp $c "ServerTime"))

    try {
        $ui = $c.UserIdentity
        foreach ($pn in @("Domain","UserName","UseThreadIdentity")) {
            L ("UserIdentity." + $pn + "=" + (SafeProp $ui $pn))
        }
    } catch {
        L ("UserIdentity FEL=" + $_.Exception.Message)
    }
} catch {
    L ("MOPS Connection FEL=" + $_.Exception.Message)
}
finally {
    if ($c) {
        try { $c.Disconnect(); L "Disconnect=OK" } catch {}
    }
}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
