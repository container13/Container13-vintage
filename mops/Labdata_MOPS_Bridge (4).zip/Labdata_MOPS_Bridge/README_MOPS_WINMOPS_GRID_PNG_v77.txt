NYA MOPS - WINMOPS GRID PNG CAPTURE v7.7
Datum: 2026-09-09

SLUTSATS FRAN v7.3-v7.6
v7.3 gjorde bara Button_Print synlig medan CheckboxEnablePrint fortfarande var
0. Knappen forsvann nar kopplingen uppdaterades och DoCopyAll utfordes inte.
Bildformatet i v7.3 var sannolikt gammalt innehall i Urklipp. v7.6 tomde
Urklipp och bekraftade att Print inte skapade nagot nytt.

v7.7 satter bade CheckboxEnablePrint.Value och Button_Print.Visible till 1 i
den lokala kopian. Scriptet bevakar sedan Urklipp i 60 sekunder och sparar den
forsta bild som WinMOPS skapar.

KORNING
1. Packa upp ZIP-filen.
2. Dubbelklicka start_mops_winmops_grid_png_capture_v77.bat.
3. Navigera i den lokala testkopian till en avdelning.
4. Vanta tills riktiga varden syns.
5. Ga tillbaka till svarta fonstret och tryck Enter INNAN du klickar Print.
6. Byt genast till WinMOPS och klicka Print inom 60 sekunder.
7. Skicka bada filerna till ChatGPT:

C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_GRID_v77.png
C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_GRID_PNG_v77.txt

SAKERHET
- Produktions-MCD verifieras med SHA-256 och lamnas orord.
- Exakt tva byte andras i en lokal kopia: CheckboxEnablePrint.Value och
  Button_Print.Visible, bada 0 till 1.
- WinMOPS anvander sin befintliga, fungerande lasanslutning.
- Scriptet sparar bara den bild som WinMOPS lagt i Urklipp.
- Ingen ny MOPS COM-session, Execute, Session.Open eller skrivning till MDE.
- Stang testkopian utan att spara efterat.
