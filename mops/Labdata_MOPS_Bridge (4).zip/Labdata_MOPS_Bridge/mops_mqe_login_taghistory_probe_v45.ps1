﻿$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_LOGIN_TAGHISTORY_PROBE_v45.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR>"}}
Remove-Item $out -ErrorAction SilentlyContinue
$tag="22=3120=7264";$st=(Get-Date).AddHours(-2);$en=Get-Date
L "MOPS MQE Login + TagHistory probe v4.5";L("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"));L("WindowsIdentity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
try{
$q=New-Object -ComObject "Mqecom.MQEQuery.5"
S "DESTINATION";L("SetDestination="+$q.SetDestination("//HOIGIBMOCLAP12/?mqe"));L("ErrorCode="+$q.GetErrorCode())
S "LOGIN";L "ApplicationUser=MOPSuser";L "Password=<blank, not logged>"
try{L("LoginReturn="+$q.Login("MOPSuser","",""))}catch{L("Login=FEL: "+$_.Exception.Message)}
L("LoginErrorCode="+$q.GetErrorCode());L("LoginErrorType="+$q.GetErrorType())
S "READ-ONLY QUERY AFTER LOGIN"
$q.Table="mqe";$q.SelFunction="TagHistory";$q.Columns="Tag,Data,Time,Value,Status";$q.OrderingFunction="";$q.MaxRows=10
$q.SelParam='Tags="'+$tag+'",StartTime="'+$st.ToString("yyyy-MM-dd HH:mm:ss")+'",EndTime="'+$en.ToString("yyyy-MM-dd HH:mm:ss")+'",NumValues=10'
foreach($n in @("Table","SelFunction","Columns","OrderingFunction","SelParam","MaxRows")){L($n+"="+(P $q $n))}
S "DOTRANSACTION"
try{L("DoTransaction="+$q.DoTransaction())}catch{L("DoTransaction=FEL: "+$_.Exception.Message)}
try{L("ErrorCode="+$q.GetErrorCode());L("ErrorType="+$q.GetErrorType())}catch{}
try{$ec=[int16]$q.GetErrorCode();$et=[int16]$q.GetErrorType();L("ErrorString="+$q.GetErrorString($ec,$et))}catch{}
L("NumOfRows="+(P $q "NumOfRows"));L("NumOfColumns="+(P $q "NumOfColumns"))
}catch{L("TOP FEL="+$_.Exception.Message)}
S "SUMMARY";L "Login() used MOPSuser with blank password, then one READ-ONLY DoTransaction().";L "NO MQEUpdate object";L "NO ExecuteDDE()";L "NO Command.Execute()";L "NO Session.Open()";L "NO MOPS write/update function called";L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
