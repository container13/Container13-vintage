$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_RELOCATED_CHECKBOX_v79.txt'
$png=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_GRID_v79.png'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $png -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function FindBytes([byte[]]$hay,[byte[]]$needle,[int]$start=0){
  for($i=$start;$i-le$hay.Length-$needle.Length;$i++){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if($hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
function FindBytesReverse([byte[]]$hay,[byte[]]$needle,[int]$start){
  for($i=$start;$i-ge0;$i--){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if(($i+$j)-ge$hay.Length-or$hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
try{
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  $source='\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd'
  $expected='ACE84824DD638BCEEE1DFA5EF993CC93790FC7AE5F35B51674A20D7733405DEB'
  $work=Join-Path $env:USERPROFILE 'Downloads\Labdata_MOPS_Bridge'
  $copy=Join-Path $work 'Manuell labdata Alt1_RELOCATED_CHECKBOX_TEST_v79.mcd'

  L 'MOPS WinMOPS Relocated Checkbox Capture v7.9'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('Source='+$source)
  L ('TestCopy='+$copy)
  L ('PNG='+$png)

  if(-not(Test-Path -LiteralPath $source)){throw 'Production MCD could not be read.'}
  $sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
  L ('SourceSHA256='+$sourceHash)
  if($sourceHash-ne$expected){throw ('Wrong source version. Expected '+$expected+' but got '+$sourceHash+'.')}

  New-Item -ItemType Directory -Path $work -Force|Out-Null
  [byte[]]$original=[IO.File]::ReadAllBytes($source)
  [byte[]]$bytes=$original.Clone()

  [byte[]]$labelNeedle=[Text.Encoding]::ASCII.GetBytes('(Name "Num_Label_Print")')
  $labelOffset=FindBytes $bytes $labelNeedle 0
  if($labelOffset-lt0){throw 'Num_Label_Print was not found.'}
  if((FindBytes $bytes $labelNeedle ($labelOffset+1))-ge0){throw 'Num_Label_Print occurs more than once.'}
  [byte[]]$valueNeedle=[Text.Encoding]::ASCII.GetBytes('(Visible 0)')
  $labelVisibleOffset=FindBytesReverse $bytes $valueNeedle $labelOffset
  if($labelVisibleOffset-lt0-or$labelVisibleOffset-lt($labelOffset-300)){throw 'Safe Num_Label_Print Visible property was not found.'}
  $labelDigitOffset=$labelVisibleOffset+9
  if($bytes[$labelDigitOffset]-ne[byte][char]'0'){throw 'Label target byte was not zero.'}
  $bytes[$labelDigitOffset]=[byte][char]'1'
  [byte[]]$labelXNeedle=[Text.Encoding]::ASCII.GetBytes('(Basepoint_X 2800)')
  $labelXOffset=FindBytesReverse $bytes $labelXNeedle $labelOffset
  if($labelXOffset-lt0-or$labelXOffset-lt($labelOffset-300)){throw 'Safe Num_Label_Print X position was not found.'}
  $labelXDigitOffset=$labelXOffset+13
  if($bytes[$labelXDigitOffset]-ne[byte][char]'2'){throw 'Label X target byte was not 2.'}
  $bytes[$labelXDigitOffset]=[byte][char]'9'

  [byte[]]$checkNeedle=[Text.Encoding]::ASCII.GetBytes('(Name "CheckboxEnablePrint")')
  $checkOffset=FindBytes $bytes $checkNeedle 0
  if($checkOffset-lt0){throw 'CheckboxEnablePrint was not found.'}
  if((FindBytes $bytes $checkNeedle ($checkOffset+1))-ge0){throw 'CheckboxEnablePrint occurs more than once.'}
  $checkVisibleOffset=FindBytesReverse $bytes $valueNeedle $checkOffset
  if($checkVisibleOffset-lt0-or$checkVisibleOffset-lt($checkOffset-300)){throw 'Safe CheckboxEnablePrint Visible property was not found.'}
  $checkDigitOffset=$checkVisibleOffset+9
  if($bytes[$checkDigitOffset]-ne[byte][char]'0'){throw 'Checkbox visibility target byte was not zero.'}
  $bytes[$checkDigitOffset]=[byte][char]'1'
  [byte[]]$checkXNeedle=[Text.Encoding]::ASCII.GetBytes('(Basepoint_X 2500)')
  $checkXOffset=FindBytesReverse $bytes $checkXNeedle $checkOffset
  if($checkXOffset-lt0-or$checkXOffset-lt($checkOffset-300)){throw 'Safe CheckboxEnablePrint X position was not found.'}
  $checkXDigitOffset=$checkXOffset+13
  if($bytes[$checkXDigitOffset]-ne[byte][char]'2'){throw 'Checkbox X target byte was not 2.'}
  $bytes[$checkXDigitOffset]=[byte][char]'9'
  [IO.File]::WriteAllBytes($copy,$bytes)

  [byte[]]$verify=[IO.File]::ReadAllBytes($copy)
  $diffs=0;$lastDiff=-1
  for($i=0;$i-lt$original.Length;$i++){if($original[$i]-ne$verify[$i]){$diffs++;$lastDiff=$i}}
  L ('Patch1=Num_Label_Print.Visible | Offset='+$labelDigitOffset+' | 0 -> 1')
  L ('Patch2=Num_Label_Print.Basepoint_X | Offset='+$labelXDigitOffset+' | 2800 -> 9800')
  L ('Patch3=CheckboxEnablePrint.Visible | Offset='+$checkDigitOffset+' | 0 -> 1')
  L ('Patch4=CheckboxEnablePrint.Basepoint_X | Offset='+$checkXDigitOffset+' | 2500 -> 9500')
  L ('VerifiedDifferentBytes='+$diffs)
  if($diffs-ne4){throw 'Local copy does not differ by exactly the four intended bytes.'}
  if($verify[$labelDigitOffset]-ne[byte][char]'1'-or$verify[$labelXDigitOffset]-ne[byte][char]'9'-or$verify[$checkDigitOffset]-ne[byte][char]'1'-or$verify[$checkXDigitOffset]-ne[byte][char]'9'){throw 'One of the four intended patches was not verified.'}

  Start-Process -FilePath $copy
  Write-Host ''
  Write-Host 'LOCAL TEST COPY IS OPENING IN WINMOPS.' -ForegroundColor Yellow
  Write-Host '1. Find ENABLE PRINTING between RADer and SAMLINGSPROV and tick its checkbox.'
  Write-Host '2. Confirm that the PRINT button appears and stays visible.'
  Write-Host '3. Navigate to a department and wait until real values are visible.'
  Write-Host '4. Return here BEFORE clicking Print.'
  [void](Read-Host 'Press ENTER when Enable printing is checked and the table is ready')
  [Windows.Forms.Clipboard]::Clear()
  Write-Host 'MONITORING FOR 60 SECONDS - switch to WinMOPS and click PRINT now.' -ForegroundColor Yellow

  L ''
  L '===== CLIPBOARD IMAGE ====='
  L ('MonitorStart='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $deadline=(Get-Date).AddSeconds(60)
  $image=$null
  $formats=@()
  while((Get-Date)-lt$deadline-and$null-eq$image){
    try{
      $data=[Windows.Forms.Clipboard]::GetDataObject()
      if($data){$formats=@($data.GetFormats($false))}
      $image=[Windows.Forms.Clipboard]::GetImage()
    }catch{}
    if($null-eq$image){Start-Sleep -Milliseconds 100}
  }
  L ('CaptureTime='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('Formats='+($formats-join' | '))
  if($null-eq$image){throw 'No clipboard image was detected during 60 seconds.'}
  L ('Width='+$image.Width)
  L ('Height='+$image.Height)
  L ('PixelFormat='+$image.PixelFormat)
  $image.Save($png,[Drawing.Imaging.ImageFormat]::Png)
  $image.Dispose()
  L ('PNGBytes='+(Get-Item -LiteralPath $png).Length)
  L ('PNGSHA256='+(Get-FileHash -LiteralPath $png -Algorithm SHA256).Hash)

  L ''
  L '===== SAFETY ====='
  L 'Production MCD hash verified and production file left unchanged.'
  L 'Exactly four bytes changed in a local copy: label and checkbox visibility plus their X positions.'
  L 'WinMOPS performed its existing DoCopyAll action.'
  L 'The script only saved WinMOPS clipboard image as PNG.'
  L 'No new MOPS COM connection, Execute, Session.Open, or write to MDE.'
  L 'No Update/Insert/Delete/Write/Save.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
}finally{L ('Output='+$out)}
Write-Host ''
Write-Host 'DONE - send both files:' -ForegroundColor Green
Write-Host $out
Write-Host $png
