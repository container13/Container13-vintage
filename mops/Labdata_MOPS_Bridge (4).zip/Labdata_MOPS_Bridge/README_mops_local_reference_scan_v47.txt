MOPS Local Reference Scan v4.7

Syfte:
- Söker lokalt i installerade MOPS-mappar efter referenser som kan visa hur MQECOM/MQEQuery används.
- Läser endast text-/konfigfiler.
- Gör inga COM-anrop, ingen serverfråga, ingen login och ingen ändring.

Resultat:
C:\Users\<user>\Downloads\MOPS_LOCAL_REFERENCE_SCAN_v47.txt

Sökord:
MQEQuery, MQECOMDLL$QUERY, SelFunction, SelParam, LoginFromIni,
TagHistory, BrowseTags, TagValue, SetDestination, DoTransaction
