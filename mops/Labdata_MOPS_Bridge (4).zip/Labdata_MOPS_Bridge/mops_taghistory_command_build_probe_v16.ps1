﻿# MOPS TagHistory command build probe v1.6 - READ ONLY, NO Execute()
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_TAGHISTORY_COMMAND_BUILD_PROBE_v16.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS TagHistory command build probe v1.6"
$c=$null;$cmd=$null
try{
 $c=New-Object -ComObject "MOPS.Connection";$c.ConnectionString="//HOIGIBMOCLAP12/";$c.Connect()
 L ("IsConnected="+$c.IsConnected)
 $cmd=New-Object -ComObject "MOPS.Command";$cmd.Connection=$c
 L "1. ServiceName=hist"
 try{$cmd.ServiceName="hist";L "OK"}catch{L ("FEL="+$_.Exception.Message)}
 L "2. FunctionName=TagHistory"
 try{$cmd.FunctionName="TagHistory";L "OK"}catch{L ("FEL="+$_.Exception.Message)}
 L "3. Command.Parameters efter korrekt service/function"
 try{
   $p=$cmd.Parameters
   if($null-eq $p){L "Parameters=<null>"}
   else{
     try{L ("Count="+$p.Count)}catch{L ("Count FEL="+$_.Exception.Message)}
     try{
       $n=0
       foreach($x in $p){
         $n++
         try{L ("PARAM #"+$n+" Name="+$x.Name)}catch{L ("PARAM #"+$n)}
         try{L (" Type="+$x.Type)}catch{}
         try{L (" Value="+[string]$x.Value)}catch{}
       }
       L ("Enumerated="+$n)
     }catch{L ("Enumerering FEL="+$_.Exception.Message)}
   }
 }catch{L ("Parameters FEL="+$_.Exception.Message)}
 L "4. Command.Fields"
 try{
   $f=$cmd.Fields
   if($null-eq $f){L "Fields=<null>"}else{
     try{L ("Fields.Count="+$f.Count)}catch{}
     $n=0;foreach($x in $f){$n++;try{L ("FIELD #"+$n+" Name="+$x.Name)}catch{}}
     L ("Fields enumerated="+$n)
   }
 }catch{L ("Fields FEL="+$_.Exception.Message)}
 L "KLAR - Execute() anropades INTE."
}catch{L ("OVANTAT FEL="+$_.Exception.Message)}
finally{
 if($null-ne $cmd){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd)}catch{}}
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY. Ingen Execute(), login eller skrivning."
L ("Output="+$out)
