MOPS MDE.Data read probe v6.1

SYFTE
Första riktiga read-only-anropet mot den funktion som v60b visade bakom MDEGrid:
service = mde
function = Data

PARAMETRAR
Bygger på den aktiva MDEGrid-konfigurationen i den MCD som körs idag:
- DeptNo = 22
- AreaNo = 1
- LocNo = 2
- EndTime = nu
- PeriodName = Timme
- NumValues = 24
- PeriodOffset = 0

PeriodCriteria och Frequency lämnas bort eftersom de är valfria och inte behövs
för första rena lästestet.

EXEKVERING
- MOPS.Connection.1
- MOPS.Command.1
- MOPS.RecordSet.1
- cmd.ServiceName = mde
- cmd.FunctionName = Data
- cmd.Execute(recordset, true)

Den Execute-formen är redan använd i tidigare bridge/probe-kod.

SÄKERHET
- Exakt en serverfunktion exekveras: mde.Data
- Ingen Update/Insert/Delete/Write/Save
- Ingen Session.Open
- Ingen DDE
- Ingen MQEUpdate
- Ingen WinMOPS-fil sparas eller ändras

RESULTAT
C:\Users\<user>\Downloads\MOPS_MDE_DATA_READ_v61.txt
