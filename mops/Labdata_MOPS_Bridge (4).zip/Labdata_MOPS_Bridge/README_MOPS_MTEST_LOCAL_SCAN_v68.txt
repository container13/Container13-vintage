NYA MOPS - MTEST LOCAL SCAN v6.8
Datum: 2026-09-09

BAKGRUND
v6.7 visade att SessionString=mde följt av Session.Open ger E_FAIL 0x80004005,
inte det tidigare RPC-felet. Sessionformatet eller MDE:s sessionsstöd behöver
därför verifieras innan nästa serveranrop.

MOPS Client-manualen anger att officiella MOPS Test Application (MTest) har
funktionerna Create session, No CallBack och Immediate Detach.

SYFTE
Hitta MTest-programmet och dess lokala konfiguration/strängar för att se hur
dessa funktioner representeras i den installerade klientversionen.

KÖRNING
Packa upp och dubbelklicka:
start_mops_mtest_local_scan_v68.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_MTEST_LOCAL_SCAN_v68.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
Endast lokal läsning. MTest startas inte, inga COM-objekt skapas och ingen
nätverksanslutning, Session.Open, Execute, DDE eller MCD-ändring görs.

Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
