MOPS active MDEGrid path map v5.6

Built from the MCD file the user said is currently used.

Main result:
The active display's data path is centered on the MDEGrid object:
- portal: LoginNode -> //HOIGIBMOCLAP12/
- service provider: mde
- department/area/location: 22 / 1 / 2
- period: Timme
- 24 data periods
- selected tag uses hist::...
- InputTrigging=1

No separate MOPS3iHistory object exists in this active MCD.
The MAccessMethod query appears to retrieve metadata/method information for a selected tag.

Next target: map the MDEGrid/MDE service contract safely before any live read.
