﻿$ErrorActionPreference = "Stop"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDE_DATA_READ_v61.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Safe($o,[string]$p){
    try{
        $v=$o.$p
        if($null -eq $v){return "<null>"}
        if($v -is [System.Array]){ return (($v | ForEach-Object {[string]$_}) -join " | ") }
        return [string]$v
    }catch{return "<unavailable>"}
}

$c=$null
$cmd=$null
$rs=$null

try{
    L "MOPS MDE.Data read probe v6.1"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
    L ""

    if([Environment]::Is64BitProcess){
        throw "Körningen är 64-bit. Avbryter eftersom MOPS-klienten är verifierad i 32-bit."
    }

    L "===== CONNECTION ====="
    $c=New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString="//HOIGIBMOCLAP12/"
    $c.Connect()
    L ("IsConnected=" + $c.IsConnected)
    L ("ServerTime=" + $c.ServerTime)
    L ("TagBroker=" + [string]$c.TagBroker)
    L ""

    L "===== COMMAND ====="
    $cmd=New-Object -ComObject "MOPS.Command.1"
    $cmd.Connection=$c
    $cmd.ServiceName="mde"
    $cmd.FunctionName="Data"
    $cmd.MaxRows=5000
    $cmd.PageSize=5000

    L ("ServiceName=" + $cmd.ServiceName)
    L ("FunctionName=" + $cmd.FunctionName)

    # Reuse the exact active MDEGrid context discovered from the current MCD.
    # Do NOT include optional Frequency or PeriodCriteria unless needed.
    $endTime=Get-Date
    $p=$cmd.Parameters
    $p.RemoveAll()

    [void]$p.Add("DeptNo","22")
    [void]$p.Add("AreaNo","1")
    [void]$p.Add("LocNo","2")
    [void]$p.Add("EndTime",$endTime)
    [void]$p.Add("PeriodName","Timme")
    [void]$p.Add("NumValues",24)
    [void]$p.Add("PeriodOffset",0)

    L ("Parameters.Count=" + $p.Count)
    for($i=0;$i -lt $p.Count;$i++){
        $pi=$p.Item($i)
        $val=Safe $pi "Value"
        if(($pi.Name -match '(?i)password|token|secret')){$val="<filtered>"}
        L ("P["+$i+"] "+$pi.Name+"="+$val+" | Type="+(Safe $pi "Type"))
    }
    try{L ("ParametersText=" + [string]$p.ParametersText)}catch{}

    L ""
    L "===== EXECUTE READ-ONLY MDE.Data ====="
    $rs=New-Object -ComObject "MOPS.RecordSet.1"

    $sw=[Diagnostics.Stopwatch]::StartNew()
    $cmd.Execute($rs,$true)
    $sw.Stop()

    L ("Execute=OK")
    L ("ElapsedMs=" + $sw.ElapsedMilliseconds)

    L ""
    L "===== RECORDSET META ====="
    foreach($name in @("RecordCount","FlatRowCount","FlatFieldCount","EOF","BOF")){
        try{L ($name+"="+[string]$rs.$name)}catch{}
    }

    # Dump recordset member names, because layout can vary.
    try{
        L "-- RecordSet members --"
        $rs | Get-Member | Sort-Object MemberType,Name | ForEach-Object {
            L ("  "+$_.MemberType+" "+$_.Name+" :: "+$_.Definition)
        }
    }catch{}

    L ""
    L "===== RESULTARRAY ====="
    $arr=$null
    try{$arr=$rs.ResultArray}catch{}
    if($null -eq $arr){
        L "ResultArray=<null>"
    }else{
        try{
            $rank=$arr.Rank
            L ("Rank="+$rank)
            if($rank -eq 2){
                $r0=$arr.GetLowerBound(0); $r1=$arr.GetUpperBound(0)
                $c0=$arr.GetLowerBound(1); $c1=$arr.GetUpperBound(1)
                L ("RowsBounds="+$r0+".."+$r1)
                L ("ColsBounds="+$c0+".."+$c1)

                $maxRows=[Math]::Min($r1,$r0+199)
                for($r=$r0;$r -le $maxRows;$r++){
                    $vals=@()
                    for($cc=$c0;$cc -le $c1;$cc++){
                        $v=$arr.GetValue($r,$cc)
                        if($null -eq $v){$vals+="<null>"}
                        elseif($v -is [datetime]){$vals+=$v.ToString("yyyy-MM-dd HH:mm:ss")}
                        elseif($v -is [byte[]]){$vals+="<byte["+$v.Length+"]>"}
                        else{$vals+=[string]$v}
                    }
                    L ("ROW["+$r+"] "+($vals -join " | "))
                }
                if($r1 -gt $maxRows){
                    L ("... truncated, total array rows="+($r1-$r0+1))
                }
            } else {
                L ("ResultArrayString="+[string]$arr)
            }
        }catch{
            L ("ResultArrayDumpError="+$_.Exception.Message)
        }
    }

    L ""
    L "===== SAFETY ====="
    L "Executed exactly one service function: mde.Data."
    L "mde.Data was identified from service metadata as a read/data function."
    L "No Update/Insert/Delete/Write/Save function was invoked."
    L "No Session.Open()."
    L "No DDE."
    L "No MQEUpdate."
    L "No WinMOPS display was modified or saved."
}
catch{
    L ""
    L ("ERROR="+$_.Exception.Message)
    try{L ("HRESULT=0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))}catch{}
}
finally{
    if($c){
        try{$c.Disconnect();L "Disconnect=OK"}catch{}
    }
    L ("Output="+$out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
