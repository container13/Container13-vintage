﻿# mops_winmops_dde_context_probe_v33.ps1
# READ-ONLY. Kartlägger WinMOPS DDE-helper och om den kan se den redan körande WinMOPS-instansen.
# Kör INTE ExecuteDDE(), Initialize(), Session.Open() eller Command.Execute().
# Inga credentials sätts och ingen MOPS-data skrivs.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_WINMOPS_DDE_CONTEXT_PROBE_v33.txt"
function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function P($o,[string]$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}
Remove-Item $out -ErrorAction SilentlyContinue

L "MOPS WinMOPS DDE context probe v3.3"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

S "WINMOPS PROCESS"
try{
 Get-CimInstance Win32_Process -Filter "name='winmops.exe'"|%{
  L("PID="+$_.ProcessId)
  L("ParentPID="+$_.ParentProcessId)
  L("SessionId="+$_.SessionId)
  L("ExecutablePath="+$_.ExecutablePath)
  L("CommandLine="+$_.CommandLine)
 }
}catch{L("Process FEL="+$_.Exception.Message)}

S "DDE HELPER - BEFORE ANY INITIALIZE"
try{
 $d=New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
 L("Created=True")
 L("IsInitialized="+(P $d "IsInitialized"))
 L("IsWinMOPSRunning="+(P $d "IsWinMOPSRunning"))
 L("WinMOPSExecPath="+(P $d "WinMOPSExecPath"))
 L "-- Members --"
 $d.PSObject.Members|Sort-Object Name|%{L($_.MemberType.ToString()+" "+$_.Name+" :: "+$_.Definition)}
 L "Initialize NOT called"
 L "ExecuteDDE NOT called"
}catch{L("DDE helper FEL="+$_.Exception.Message)}

S "RUNNING OBJECT TABLE - MOPS/WINMOPS NAMES"
try{
 $sig=@'
using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
public static class Rot33 {
 [DllImport("ole32.dll")] static extern int GetRunningObjectTable(int r, out IRunningObjectTable p);
 [DllImport("ole32.dll")] static extern int CreateBindCtx(int r, out IBindCtx p);
 public static string[] Names(){
  IRunningObjectTable rot; IBindCtx ctx;
  GetRunningObjectTable(0,out rot); CreateBindCtx(0,out ctx);
  IEnumMoniker en; rot.EnumRunning(out en); en.Reset();
  var a=new System.Collections.Generic.List<string>();
  IMoniker[] m=new IMoniker[1]; IntPtr f=IntPtr.Zero;
  while(en.Next(1,m,f)==0){
   try{string n; m[0].GetDisplayName(ctx,null,out n); a.Add(n);}catch{}
  }
  return a.ToArray();
 }
}
'@
 if(-not ("Rot33" -as [type])){Add-Type $sig}
 [Rot33]::Names()|Where-Object {$_ -match '(?i)mops|winmops|mde|mqe|hist'}|%{L($_)}
}catch{L("ROT FEL="+$_.Exception.Message)}

S "DDE-RELATED REGISTRY HINTS"
foreach($root in @("HKLM:\SOFTWARE\Classes","HKLM:\SOFTWARE\WOW6432Node\Classes")){
 if(!(Test-Path $root)){continue}
 try{
  Get-ChildItem $root -ErrorAction SilentlyContinue|
   Where-Object {$_.PSChildName -match '(?i)WinMOPS|DDEHelper'}|%{
    $def="";try{$def=(Get-Item $_.PSPath).GetValue("")}catch{}
    L("KEY "+$_.PSChildName+" | Default="+$def)
   }
 }catch{}
}

S "SUMMARY"
L "NO Initialize()"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L ("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
