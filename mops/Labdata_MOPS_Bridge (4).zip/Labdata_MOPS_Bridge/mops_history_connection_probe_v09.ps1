﻿# Nya MOPS - History via verified Connection v0.9
# Read-only. No login and no writes.
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_HISTORY_CONNECTION_PROBE_v09.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS History connection probe v0.9"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Is64BitProcess="+[Environment]::Is64BitProcess)
L ""

$c=$null;$cmd=$null
try{
 L "1. Ansluter MOPS.Connection ..."
 $c=New-Object -ComObject "MOPS.Connection"
 $c.ConnectionString="//HOIGIBMOCLAP12/"
 $c.Connect()
 L ("   IsConnected="+$c.IsConnected)
 L ("   TagBroker="+$c.TagBroker)

 L "2. Skapar MOPS.Command ..."
 $cmd=New-Object -ComObject "MOPS.Command"
 L "   OK"

 L "3. Kopplar Command.Connection till den verifierade anslutningen ..."
 $cmd.Connection=$c
 L "   OK"

 L "4. Kontrollerar kopplingen utan Execute() ..."
 try {
   $cc=$cmd.Connection
   L ("   Command.Connection.IsConnected="+$cc.IsConnected)
   L ("   Command.Connection.ConnectionString="+$cc.ConnectionString)
   L ("   Command.Connection.TagBroker="+$cc.TagBroker)
 } catch { L ("   Kontroll FEL="+$_.Exception.Message) }

 L ""
 L "RESULTAT: Command ar kopplad till live MOPS Connection."
}catch{L ("FEL="+$_.Exception.Message)}
finally{
 if($null-ne $cmd){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd)}catch{}}
 if($null-ne $c){
   try{if($c.IsConnected){$c.Disconnect();L "5. Disconnect=OK"}}catch{}
   try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}
 }
}
L ""
L "Read-only. Execute() anropades INTE. Ingen historik, login eller skrivning."
L ("Output="+$out)
