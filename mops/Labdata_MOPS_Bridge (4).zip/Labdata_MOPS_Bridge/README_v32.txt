Labdata MOPS Bridge v32 / bridge v0.8

Fix:
  C#-kompileringen i PowerShell x86 fick en tvetydig INVOKEKIND-referens.
  v0.8 använder det fullständiga namnet:
  System.Runtime.InteropServices.ComTypes.INVOKEKIND

Syfte:
  Läsa exakt IDispatch type-info från MOPS.Command.Parameters.
  Ingen TagHistory Execute ännu.

Read-only:
  Ja.
