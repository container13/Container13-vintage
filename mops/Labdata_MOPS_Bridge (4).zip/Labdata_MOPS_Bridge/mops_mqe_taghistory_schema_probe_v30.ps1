﻿# mops_mqe_taghistory_schema_probe_v30.ps1
# READ-ONLY. Jämför TagHistory-definitionen under service "mqe" och "hist".
# Ingen Execute(), ingen Session.Open(), inga credentials, ingen MOPS-skrivning.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_TAGHISTORY_SCHEMA_PROBE_v30.txt"

function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function P($o,[string]$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}

function Dump-ServiceTagHistory($browser,[string]$serviceName){
    S ("SERVICE "+$serviceName+" / TagHistory")
    $svc=$null
    try{
        $svcs=$browser.Services
        $cnt=[int]$svcs.Count
        for($i=0;$i-lt$cnt;$i++){
            $x=$svcs.Item($i)
            if((P $x "Name") -ieq $serviceName){$svc=$x;break}
        }
    }catch{L("Service lookup FEL="+$_.Exception.Message)}
    if(-not $svc){L("Service not found");return}

    L("Service.Name="+(P $svc "Name"))
    L("Service.Node="+(P $svc "Node"))
    L("Service.ProviderClassID="+(P $svc "ProviderClassID"))
    L("Service.ServiceID="+(P $svc "ServiceID"))

    $fn=$null
    try{
        $fns=$svc.Functions
        $fc=[int]$fns.Count
        L("FunctionCount="+$fc)
        for($j=0;$j-lt$fc;$j++){
            $f=$fns.Item($j)
            if((P $f "Name") -ieq "TagHistory"){$fn=$f;break}
        }
    }catch{L("Function lookup FEL="+$_.Exception.Message)}

    if(-not $fn){L("TagHistory not found");return}

    L("Function.Name="+(P $fn "Name"))
    foreach($n in @("FunctionID","Node","ProviderClassID","Description","Type","Context","Server","Host")){
        L("Function."+$n+"="+(P $fn $n))
    }

    L "-- Function members --"
    try{
        $fn.PSObject.Members|Sort-Object Name|ForEach-Object{
            L($_.MemberType.ToString()+" "+$_.Name+" :: "+$_.Definition)
        }
    }catch{L("Member dump FEL="+$_.Exception.Message)}

    # Leta efter schema-/parameterkollektioner som browser-objektet exponerar.
    foreach($pn in @("Parameters","InputParameters","CommandParams","Fields","Arguments")){
        try{
            $col=$fn.$pn
            if($null -eq $col){L($pn+"=<null>");continue}
            L($pn+".Type="+$col.GetType().FullName)
            L($pn+".Count="+(P $col "Count"))
            try{
                $cc=[int]$col.Count
                for($k=0;$k-lt$cc;$k++){
                    try{
                        $p=$col.Item($k)
                        L($pn+"["+$k+"] Name="+(P $p "Name")+" | Type="+(P $p "Type")+" | SchemaType="+(P $p "SchemaType")+" | Options="+(P $p "Options")+" | Value="+(P $p "Value"))
                    }catch{L($pn+"["+$k+"] FEL="+$_.Exception.Message)}
                }
            }catch{}
        }catch{
            L($pn+"=<property unavailable>")
        }
    }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
L "MOPS MQE TagHistory schema probe v3.0"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

$c=$null
try{
    S "CONNECTION"
    $c=New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString="//HOIGIBMOCLAP12/"
    $c.Connect()
    L("IsConnected="+(P $c "IsConnected"))
    L("TagBroker="+(P $c "TagBroker"))

    $b=$c.Browser
    $b.Refresh()

    Dump-ServiceTagHistory $b "mqe"
    Dump-ServiceTagHistory $b "hist"

    S "COMMAND BUILD - MQE TAGHISTORY (NO EXECUTE)"
    try{
        $cmd=New-Object -ComObject "MOPS.Command.1"
        $cmd.Connection=$c
        $cmd.ServiceName="mqe"
        $cmd.FunctionName="TagHistory"
        L("Assigned ServiceName=mqe")
        L("Assigned FunctionName=TagHistory")
        L("Readback ServiceName="+(P $cmd "ServiceName"))
        L("Readback FunctionName="+(P $cmd "FunctionName"))
        L("Parameters.Count="+(P $cmd.Parameters "Count"))
        L("Command.Session="+(P $cmd "Session"))
        L("CommandType="+(P $cmd "CommandType"))
        L("PageSize="+(P $cmd "PageSize"))
    }catch{L("Command build FEL="+$_.Exception.Message)}

}catch{L("TOP FEL="+$_.Exception.Message)}
finally{
    if($c){try{$c.Disconnect();L("Disconnect=OK")}catch{}}
}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L ("Output="+$out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
