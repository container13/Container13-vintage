﻿# Nya MOPS - Connection live probe v0.7
# Read-only: connects MOPS.Connection to the same portal used by WinMOPS.
# No history, session login, Execute(), or writes.

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_CONNECTION_LIVE_PROBE_v07.txt"
function L([string]$s="") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8; Write-Host $s }

Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS Connection live probe v0.7"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
L ""

$c = $null
try {
    L "1. Skapar MOPS.Connection ..."
    $c = New-Object -ComObject "MOPS.Connection"
    L "   OK"

    L "2. Satter ConnectionString=//HOIGIBMOCLAP12/ ..."
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    L "   OK"

    L "3. Anropar Connect() ..."
    $c.Connect()
    L "   Connect() returnerade"

    L "4. Laser sakra anslutningsegenskaper ..."
    try { L ("IsConnected=" + $c.IsConnected) } catch { L ("IsConnected ERROR=" + $_.Exception.Message) }
    try { L ("ConnectionString=" + $c.ConnectionString) } catch { L ("ConnectionString ERROR=" + $_.Exception.Message) }
    try { L ("TagBroker=" + $c.TagBroker) } catch { L ("TagBroker ERROR=" + $_.Exception.Message) }
    try { L ("ConnectionErrorState=" + $c.ConnectionErrorState) } catch { L ("ConnectionErrorState ERROR=" + $_.Exception.Message) }
    try { L ("ServerTime=" + $c.ServerTime) } catch { L ("ServerTime ERROR=" + $_.Exception.Message) }

    L ""
    L "RESULTAT: Connection-proben klar."
}
catch {
    L ("FEL=" + $_.Exception.Message)
}
finally {
    if ($null -ne $c) {
        try {
            if ($c.IsConnected) {
                L "5. Disconnect() ..."
                $c.Disconnect()
                L "   OK"
            }
        } catch { L ("Disconnect ERROR=" + $_.Exception.Message) }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($c) } catch {}
    }
}

L ""
L "Read-only. Ingen historik, login eller skrivning utford."
L ("Output=" + $out)
