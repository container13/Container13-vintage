﻿# mops_taghistory_execute_probe_v22.ps1
# FORSTA riktiga READ-ONLY TagHistory-testet.
# Kor endast hist.TagHistory mot en redan verifierad testtagg.
# Ingen skrivfunktion anropas.

$ErrorActionPreference="Stop"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_TAGHISTORY_EXECUTE_PROBE_v22.txt"
function L([string]$s=""){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function V($o,$n){try{$v=$o.$n;if($null -eq $v){"<null>"}else{[string]$v}}catch{"<ERR: $($_.Exception.Message)>"}}

Remove-Item $out -ErrorAction SilentlyContinue
$c=$null
try{
 L "MOPS TagHistory execute probe v2.2"
 L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
 L ("Is64BitProcess="+[Environment]::Is64BitProcess)
 L ""

 $c=New-Object -ComObject "MOPS.Connection.1"
 $c.ConnectionString="//HOIGIBMOCLAP12/"
 $c.Connect()
 L ("IsConnected="+$c.IsConnected)

 $cmd=New-Object -ComObject "MOPS.Command.1"
 $cmd.Connection=$c
 $cmd.ServiceName="hist"
 $cmd.FunctionName="TagHistory"

 $p=$cmd.Parameters
 $p.RemoveAll()

 # Litet, avgransat read-only test: en verifierad tagg, senaste 2 timmarna, max 10 varden.
 $tag="22=3120=7264"
 $end=Get-Date
 $start=$end.AddHours(-2)

 [void]$p.Add("Tags",$tag)
 [void]$p.Add("StartTime",$start)
 [void]$p.Add("EndTime",$end)
 [void]$p.Add("NumValues",10)

 L ("Tag="+$tag)
 L ("StartTime="+$start)
 L ("EndTime="+$end)
 L ("NumValues=10")
 L ("ParameterCount="+$p.Count)
 for($i=0;$i -lt [int]$p.Count;$i++){
   $x=$p.Item($i)
   L ("P"+$i+" Name="+(V $x "Name")+" | Value="+(V $x "Value")+" | Type="+(V $x "Type"))
 }
 L ""

 $rs=New-Object -ComObject "MOPS.RecordSet.1"
 L "EXECUTE: hist.TagHistory (READ-ONLY) ..."
 try{
   $cmd.Execute($rs,$true)
   L "Execute=OK"
 }catch{
   L ("Execute=FEL: "+$_.Exception.Message)
   L ("HRESULT=0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
   throw
 }

 L ("RecordCount="+(V $rs "RecordCount"))
 L ("FlatRowCount="+(V $rs "FlatRowCount"))
 L ("FlatFieldCount="+(V $rs "FlatFieldCount"))
 L ""

 try{
   $arr=$rs.ResultArray
   if($null -eq $arr){L "ResultArray=<null>"}
   elseif($arr -is [Array]){
     L ("ResultArray.Type="+$arr.GetType().FullName)
     L ("ResultArray.Rank="+$arr.Rank)
     L ("ResultArray.Length="+$arr.Length)
     for($d=0;$d -lt $arr.Rank;$d++){L ("  Dim"+$d+" Lower="+$arr.GetLowerBound($d)+" Upper="+$arr.GetUpperBound($d))}
     L "ResultArray sample (max 40 flattened values):"
     $n=0
     foreach($v in $arr){
       if($n -ge 40){break}
       L ("  ["+$n+"]="+[string]$v)
       $n++
     }
   }else{
     L ("ResultArray.Type="+$arr.GetType().FullName)
     L ("ResultArray="+[string]$arr)
   }
 }catch{L ("ResultArray FEL="+$_.Exception.Message)}

 L ""
 $p.RemoveAll()
 L "KLAR - endast read-only hist.TagHistory utfordes."
}catch{
 L ("SLUTFEL="+$_.Exception.Message)
}finally{
 if($c){try{$c.Disconnect();L "Disconnect=OK"}catch{}}
 L "Ingen skrivfunktion anropades."
 L ("Output="+$out)
}
Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
