NYA MOPS - NOCALLBACK/SESSION METADATA v6.5
Datum: 2026-09-09

BAKGRUND
v6.4 visade att WinMOPS tillåts ta emot inkommande trafik medan 32-bitars
Windows PowerShell har en uttrycklig inkommande Block-regel på domännätverket.
PowerShell kan ansluta till MOPS och läsa metadata men MDE Execute har tidigare
fallit på RPC 0x800706BA.

MOPS Client-manualen beskriver alternativen "No CallBack", "Immediate Detach"
och "Create session", men den visar inte vilka COM-egenskaper eller argument
som motsvarar alternativen.

SYFTE
Kartlägga exakt COM-/session-/callbackyta innan något nytt Execute-test byggs.

INNAN DU KÖR
WinMOPS får gärna vara öppet, men v6.5 ansluter inte till MOPS-servern och
påverkar inte den öppna bilden.

KÖRNING
Dubbelklicka:
start_mops_nocallback_session_metadata_v65.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_NOCALLBACK_SESSION_METADATA_v65.txt

Skicka resultatfilen till ChatGPT.

VAD SOM LÄSES
- COM-registrering för Connection, Command, RecordSet och Session
- objektens automationsegenskaper och metoder
- säkra standardvärden
- relevanta strängar i mclient.dll, mportalps.dll, MDEGrid.mcx och winmops.exe

SÄKERHET
- ingen Connection.Connect
- Session-objektet skapas endast för medlemslistan; Session.Open anropas inte
- ingen CommandText och ingen Execute
- ingen Browser.Refresh och ingen servicefunktion
- ingen DDE
- ingen MCD öppnas, ändras eller sparas
- ingen Update/Insert/Delete/Write/Save

Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
