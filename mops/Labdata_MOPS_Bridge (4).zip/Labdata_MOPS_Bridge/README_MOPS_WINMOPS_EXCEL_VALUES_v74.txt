NYA MOPS - WINMOPS EXCEL VALUE CAPTURE v7.4
Datum: 2026-09-09

SYFTE
WinMOPS egen Print-kedja innehåller bade MDEGrid.DoCopyAll och StartExcel.
MDE-manualen anger att hela rutnatets varderingar, tider och struktur kopieras
och att StartExcel kan fora rutnatet till Excel. Testet laser cellvardena fran
den Excel-arbetsbok som WinMOPS sjalv oppnar.

KORNING
1. Packa upp ZIP-filen.
2. Dubbelklicka start_mops_winmops_excel_value_capture_v74.bat.
3. Navigera i den lokala testkopian till en avdelning.
4. Vanta tills riktiga varden syns och klicka Print en gang.
5. Lamna Excel oppet.
6. Ga tillbaka till det svarta fonstret och tryck Enter.
7. Skicka resultatfilen till ChatGPT:

C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_EXCEL_VALUES_v74.txt

SAKERHET
- Produktions-MCD verifieras med SHA-256 och lamnas orord.
- Exakt en byte andras i en lokal kopia: Button_Print.Visible 0 till 1.
- WinMOPS anvander sin befintliga, fungerande lasanslutning.
- Scriptet laser bara celler ur Excel och sparar eller redigerar inget.
- Ingen ny MOPS COM-session, Execute, Session.Open eller skrivning till MDE.
- Stang testkopian utan att spara efterat.
