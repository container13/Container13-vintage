NYA MOPS - WINMOPS GRID PNG CAPTURE v7.6
Datum: 2026-09-09

SLUTSATS FRAN v7.3-v7.5
Print oppnade inte Excel. WinMOPS DoCopyAll lade i stallet rutnatet i Urklipp
som PNG/Bitmap. v7.6 sparar WinMOPS egen bild oforandrad som en PNG-fil sa att
rutnat, rubriker, tider och varden kan undersokas for stabil OCR-avlasning.

KORNING
1. Packa upp ZIP-filen.
2. Dubbelklicka start_mops_winmops_grid_png_capture_v76.bat.
3. Navigera i den lokala testkopian till en avdelning.
4. Vanta tills riktiga varden syns och klicka Print en gang.
5. Ga tillbaka till det svarta fonstret utan att kopiera nagot annat.
6. Tryck Enter.
7. Skicka bada filerna till ChatGPT:

C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_GRID_v76.png
C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_GRID_PNG_v76.txt

SAKERHET
- Produktions-MCD verifieras med SHA-256 och lamnas orord.
- Exakt en byte andras i en lokal kopia: Button_Print.Visible 0 till 1.
- WinMOPS anvander sin befintliga, fungerande lasanslutning.
- Scriptet sparar bara den bild som WinMOPS lagt i Urklipp.
- Ingen ny MOPS COM-session, Execute, Session.Open eller skrivning till MDE.
- Stang testkopian utan att spara efterat.
