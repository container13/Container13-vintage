﻿$ErrorActionPreference = "Stop"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDE_SERVICE_CONTRACT_v60b.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Safe($o,[string]$p){
    try{
        $v=$o.$p
        if($null -eq $v){return "<null>"}
        return [string]$v
    }catch{return "<unavailable>"}
}

$c=$null
try{
    L "MOPS MDE Service Contract probe v6.0b"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
    L ""

    $c=New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString="//HOIGIBMOCLAP12/"
    $c.Connect()

    L "===== CONNECTION ====="
    L ("IsConnected=" + $c.IsConnected)
    L ("ServerTime=" + $c.ServerTime)
    L ""

    # Correct route, verified in earlier working probes:
    # Connection.Browser -> Refresh() -> Browser.Services
    $b=$c.Browser
    $b.Refresh()

    L "===== CONNECTION.BROWSER ====="
    L ("BrowserType=" + $b.GetType().FullName)
    L ("BrowserEnabled=" + (Safe $b "Enabled"))
    L ("BrowserName=" + (Safe $b "Name"))
    L ("BrowserNode=" + (Safe $b "Node"))
    L ("Services.Count=" + $b.Services.Count)
    L ""

    $mde=@($b.Services | Where-Object { $_.Name -eq "mde" } | Select-Object -First 1)
    if(-not $mde){ throw "mde service not found in Connection.Browser.Services" }

    L "===== MDE SERVICE ====="
    foreach($p in @("Name","Node","ProviderClassID","ServiceID","DisplayName","Description","Type","Context","Server","Host")){
        L ($p + "=" + (Safe $mde $p))
    }

    $funcs=$mde.Functions
    L ("FunctionCount=" + $funcs.Count)
    L ""

    $interesting='(?i)(Get|Read|Data|Period|Department|Area|Location|Grid|Sample|Property|Tag|Value|Time|Config|Limit|Grade|Method)'
    $unsafe='(?i)(Update|Insert|Delete|Write|Save|Set|Create|Modify|Commit|Activate)'

    L "===== MDE FUNCTIONS ====="
    for($i=0;$i -lt $funcs.Count;$i++){
        $fn=$funcs.Item($i)
        if(-not $fn){continue}
        $name=[string]$fn.Name

        $flag=""
        if($name -match $unsafe){$flag=" [WRITE-LIKE NAME - NOT EXECUTED]"}
        elseif($name -match $interesting){$flag=" [READ/RELEVANT CANDIDATE]"}

        L ("FUNCTION["+$i+"] Name="+$name+$flag)

        if(($name -match $interesting) -and -not ($name -match $unsafe)){
            try{
                $pars=$fn.Parameters
                L ("  Parameters.Count="+$pars.Count)
                for($j=0;$j -lt $pars.Count;$j++){
                    $p=$pars.Item($j)
                    if($p){
                        L ("    P["+$j+"] Name="+(Safe $p "Name")+" | Type="+(Safe $p "Type")+" | Required="+(Safe $p "Required")+" | Default="+(Safe $p "DefaultValue"))
                    }
                }
            }catch{ L ("  ParametersError="+$_.Exception.Message) }

            try{
                $fields=$fn.Fields
                L ("  Fields.Count="+$fields.Count)
                for($j=0;$j -lt $fields.Count;$j++){
                    $f=$fields.Item($j)
                    if($f){
                        L ("    F["+$j+"] Name="+(Safe $f "Name")+" | Type="+(Safe $f "Type"))
                    }
                }
            }catch{ L ("  FieldsError="+$_.Exception.Message) }
        }
    }

    L ""
    L "===== SAFETY ====="
    L "Used verified route: Connection.Browser -> Refresh -> Services."
    L "Metadata/schema only."
    L "No MOPS.Command Execute()."
    L "No service function invocation."
    L "No Session.Open()."
    L "No DDE."
    L "No MQEUpdate."
    L "No Update/Insert/Delete/Write/Save."
}
catch{
    L ""
    L ("ERROR=" + $_.Exception.Message)
}
finally{
    if($c){
        try{$c.Disconnect(); L "Disconnect=OK"}catch{}
    }
    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
