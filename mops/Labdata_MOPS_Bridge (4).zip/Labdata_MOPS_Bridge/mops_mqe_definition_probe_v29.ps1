﻿# mops_mqe_definition_probe_v29.ps1
# READ-ONLY. Kartlägger mqe-tjänstens metadata/COM-aktivering och RPC-relaterad registrering.
# Ingen Execute(), ingen Session.Open(), inga credentials, ingen MOPS-skrivning.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_DEFINITION_PROBE_v29.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8}
function S([string]$s){L "";L("===== "+$s+" =====")}
function P($o,[string]$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}

Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS MQE definition probe v2.9"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

$c=$null
try{
 S "MOPS CONNECTION"
 $c=New-Object -ComObject MOPS.Connection.1
 $c.ConnectionString="//HOIGIBMOCLAP12/"
 $c.Connect()
 L("IsConnected="+(P $c "IsConnected"))
 L("TagBroker="+(P $c "TagBroker"))
 L("ServerTime="+(P $c "ServerTime"))

 S "SERVICE BROWSER - MQE"
 $b=$c.Browser
 $b.Refresh()
 $services=$b.Services
 L("ServiceCount="+(P $services "Count"))
 $mqe=$null
 try{
  $cnt=[int]$services.Count
  for($i=0;$i-lt$cnt;$i++){
   try{
    $s=$services.Item($i)
    $name=P $s "Name"
    L("SERVICE[$i] Name=$name")
    if($name -ieq "mqe"){$mqe=$s}
   }catch{L("SERVICE[$i] FEL="+$_.Exception.Message)}
  }
 }catch{L("Service enumeration FEL="+$_.Exception.Message)}

 if($mqe){
  S "MQE SERVICE PROPERTIES"
  foreach($n in @("Name","DisplayName","Description","Node","ProviderClassID","ServiceID","Type","Context","Server","Host")){
   L($n+"="+(P $mqe $n))
  }

  S "MQE SERVICE MEMBERS"
  $mqe.PSObject.Members|Sort-Object Name|%{L($_.MemberType.ToString()+" "+$_.Name+" :: "+$_.Definition)}

  S "MQE FUNCTIONS"
  try{
   $f=$mqe.Functions
   $fc=[int]$f.Count
   L("FunctionCount="+$fc)
   for($i=0;$i-lt$fc;$i++){
    try{
     $x=$f.Item($i)
     L("FUNCTION[$i] Name="+(P $x "Name")+" | FunctionID="+(P $x "FunctionID")+" | ProviderClassID="+(P $x "ProviderClassID")+" | Node="+(P $x "Node"))
    }catch{L("FUNCTION[$i] FEL="+$_.Exception.Message)}
   }
  }catch{L("Functions FEL="+$_.Exception.Message)}
 }else{L("MQE service not found")}

 S "MQE / MOPS COM REGISTRY SEARCH"
 $roots=@("HKLM:\SOFTWARE\Classes","HKLM:\SOFTWARE\WOW6432Node\Classes")
 foreach($root in $roots){
  L("ROOT "+$root+" Exists="+(Test-Path $root))
  if(Test-Path $root){
   try{
    Get-ChildItem $root -ErrorAction SilentlyContinue|
     Where-Object {$_.PSChildName -match '(?i)^MOPS|MQE|MPORTAL|MHIST'}|
     Select-Object -First 100|%{
      $def="";try{$def=(Get-Item $_.PSPath).GetValue("")}catch{}
      L("KEY "+$_.PSChildName+" | Default="+$def)
     }
   }catch{}
  }
 }

 S "MOPS BIN MQE/HIST/PORTAL FILES"
 $bin="C:\Program Files (x86)\MOPS\sys\bin"
 if(Test-Path $bin){
  Get-ChildItem $bin -File -ErrorAction SilentlyContinue|
   Where-Object {$_.Name -match '(?i)mqe|mhist|mport|portal|broker'}|
   Sort-Object Name|%{
    $ver="";try{$ver=$_.VersionInfo.FileVersion}catch{}
    L("FILE "+$_.Name+" | "+$_.Length+" | Version="+$ver)
   }
 }

 S "LOCAL COM APPID / CLSID TEXT HINTS"
 foreach($root in @("HKLM:\SOFTWARE\Classes\AppID","HKLM:\SOFTWARE\Classes\CLSID","HKLM:\SOFTWARE\WOW6432Node\Classes\AppID","HKLM:\SOFTWARE\WOW6432Node\Classes\CLSID")){
  if(!(Test-Path $root)){continue}
  try{
   Get-ChildItem $root -ErrorAction SilentlyContinue|ForEach-Object{
    try{
     $item=Get-Item $_.PSPath
     $d=[string]$item.GetValue("")
     $vals=Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
     $blob=$d+" "+$_.PSChildName+" "+($vals|Out-String)
     if($blob -match '(?i)mqe|mops|mhist|mport'){
      L("REG "+$_.PSPath+" | Default="+$d)
     }
    }catch{}
   }
  }catch{}
 }
}catch{L("TOP FEL="+$_.Exception.Message)}
finally{if($c){try{$c.Disconnect();L("Disconnect=OK")}catch{}}}

S "SUMMARY"
L "NO Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
