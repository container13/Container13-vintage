﻿$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_MDEGRID_CLIPBOARD_CAPTURE_v71.txt'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
try{
  Add-Type -AssemblyName System.Windows.Forms
  L 'MOPS MDEGrid Clipboard Capture v7.1'
  L ('StartTime='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('ApartmentState='+[Threading.Thread]::CurrentThread.ApartmentState)
  L 'PURPOSE=Capture exactly what existing WinMOPS MDEGrid places on the clipboard with Copy All.'
  L ''
  L '===== BEFORE USER COPY ====='
  try{
    $before=[Windows.Forms.Clipboard]::GetDataObject()
    if($before){L ('FormatsBefore='+($before.GetFormats($false)-join' | '))}else{L 'FormatsBefore=<empty>'}
  }catch{L ('BeforeClipboardError='+$_.Exception.Message)}

  Write-Host ''
  Write-Host 'GÖR NU DETTA I WINMOPS:' -ForegroundColor Yellow
  Write-Host '1. Öppna Manuell labdata Alt1 och kontrollera att riktiga värden syns.'
  Write-Host '2. Klicka i MDEGrid-tabellen.'
  Write-Host '3. Välj Kopiera allt / Copy All i tabellens meny eller med dess kopieringsknapp.'
  Write-Host '4. Gå tillbaka till detta svarta fönster utan att kopiera något annat.'
  Write-Host ''
  [void](Read-Host 'Tryck ENTER här när Kopiera allt är klart')

  L ''
  L '===== AFTER MDEGRID COPY ALL ====='
  L ('CaptureTime='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $data=[Windows.Forms.Clipboard]::GetDataObject()
  if(-not$data){throw 'Clipboard is empty.'}
  $formats=@($data.GetFormats($false))
  L ('FormatsCount='+$formats.Count)
  L ('Formats='+($formats-join' | '))
  foreach($format in $formats){
    L ''
    L ('--- FORMAT: '+$format+' ---')
    try{
      $value=$data.GetData($format,$false)
      if($null-eq$value){L 'Value=<null>';continue}
      L ('Type='+$value.GetType().FullName)
      if($value-is[string]){
        L ('Length='+$value.Length)
        L 'BEGIN_TEXT'
        L $value
        L 'END_TEXT'
      }elseif($value-is[System.IO.MemoryStream]){
        L ('MemoryStreamLength='+$value.Length)
      }elseif($value-is[byte[]]){
        L ('ByteLength='+$value.Length)
      }else{
        $text=[string]$value
        L ('StringLength='+$text.Length)
        L ('Value='+$text)
      }
    }catch{L ('FormatReadError='+$_.Exception.Message)}
  }
  L ''
  L '===== BASIC TEXT SHAPE ====='
  try{
    $text=[Windows.Forms.Clipboard]::GetText([Windows.Forms.TextDataFormat]::UnicodeText)
    L ('UnicodeTextLength='+$text.Length)
    $lines=@($text -split "`r?`n")
    L ('LineCount='+$lines.Count)
    $tabs=0
    foreach($line in $lines){$tabs+=[regex]::Matches($line,"`t").Count}
    L ('TabCount='+$tabs)
    if($lines.Count-gt0){L ('FirstLineColumns='+(($lines[0]-split"`t",-1).Count))}
  }catch{L ('TextShapeError='+$_.Exception.Message)}

  L ''
  L '===== SAFETY ====='
  L 'Read existing clipboard content after the user manually selected MDEGrid Copy All.'
  L 'Clipboard was not cleared or modified by this script.'
  L 'No MOPS COM object, network connection, DDE, Execute, Session.Open, or MCD modification.'
  L 'No value was entered and no Save/Update/Insert/Delete/Write was performed.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
}finally{
  L ('Output='+$out)
}
Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
