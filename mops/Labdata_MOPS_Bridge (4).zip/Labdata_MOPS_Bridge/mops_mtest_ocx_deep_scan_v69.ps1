﻿$ErrorActionPreference='Continue'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_MTEST_OCX_DEEP_SCAN_v69.txt'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function Context([string[]]$strings,[string]$label){
  L ('-- '+$label+' --')
  $pattern='(?i)(Create.?Session|SessionString|MOPSSession|No.?CallBack|Immediate.?Detach|Callback|Detach|ReturnSP|CommandType|Async|Submit|Session)'
  $indexes=New-Object System.Collections.Generic.HashSet[int]
  for($i=0;$i -lt $strings.Count;$i++){
    if($strings[$i] -match $pattern){
      for($j=[Math]::Max(0,$i-14);$j -le [Math]::Min($strings.Count-1,$i+14);$j++){[void]$indexes.Add($j)}
    }
  }
  L ('  Strings='+$strings.Count+' | ContextRows='+$indexes.Count)
  foreach($i in ($indexes|Sort-Object)){L ('  S[{0}] {1}' -f $i,$strings[$i])}
}
try{
  L 'MOPS MTest OCX Deep Scan v6.9'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('Is64BitProcess='+[Environment]::Is64BitProcess)
  L 'PURPOSE=Inspect official MTest OCX session/callback/detach implementation metadata.'
  $path=Join-Path ${env:ProgramFiles(x86)} 'MOPS\sys\bin\mtest.ocx'
  L ''
  L '===== FILE ====='
  L ('Path='+$path)
  if(-not(Test-Path -LiteralPath $path)){throw 'mtest.ocx not found.'}
  $bytes=[IO.File]::ReadAllBytes($path)
  L ('Length='+$bytes.Length)
  L ('FileVersion='+(Get-Item -LiteralPath $path).VersionInfo.FileVersion)
  L ('SHA256='+(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash)

  L ''
  L '===== ORDERED STRING CONTEXT ====='
  $ascii=@([regex]::Matches([Text.Encoding]::ASCII.GetString($bytes),'[\x20-\x7E]{4,300}')|ForEach-Object{$_.Value.Trim()})
  $wide=@([regex]::Matches([Text.Encoding]::Unicode.GetString($bytes),'[\x20-\x7E]{4,300}')|ForEach-Object{$_.Value.Trim()})
  Context $ascii 'ASCII'
  Context $wide 'UTF-16'

  L ''
  L '===== COM REGISTRATION REFERENCES ====='
  foreach($root in @('HKCR\CLSID','HKCR\TypeLib','HKLM\SOFTWARE\WOW6432Node\Classes\CLSID','HKLM\SOFTWARE\WOW6432Node\Classes\TypeLib')){
    L ('-- Root='+$root)
    try{
      $rows=& reg.exe query $root /s /f 'mtest.ocx' /d 2>&1
      foreach($row in $rows){L ('  '+[string]$row)}
    }catch{L ('  RegistryQueryError='+$_.Exception.Message)}
  }

  L ''
  L '===== SAFETY ====='
  L 'Local mtest.ocx bytes and registry references only.'
  L 'MTest not launched; no COM object, network, Connect, Session.Open, Execute, DDE, or MCD access.'
  L 'No Update/Insert/Delete/Write/Save.'
}catch{L ('ERROR='+$_.Exception.Message)}finally{L ('Output='+$out)}
Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
