NYA MOPS - ENABLE PRINT/COPY CAPTURE v7.3
Datum: 2026-09-09

FYND I PRODUKTIONS-MCD
- MDEGrid.DoCopyAll är kopplad till Button_Print.On_Clicked
- samma knapp aktiverar den befintliga StartExcel-funktionen
- Button_Print har texten Print men dess egen Visible är 0
- v7.2 ändrade felaktigt CheckboxEnablePrint.Value; kopplingsriktningen är
  Button_Print.Visible till CheckboxEnablePrint.Value, inte tvärtom

VAD TESTET GÖR
1. Verifierar produktions-MCD med SHA-256.
2. Skapar en lokal kopia i Downloads\Labdata_MOPS_Bridge.
3. Ändrar exakt en byte i kopian: Button_Print.Visible 0 till 1.
4. Verifierar att endast den byten ändrats.
5. Öppnar den lokala kopian genom Windows filassociation till WinMOPS.
6. Du klickar den nu synliga Print-knappen.
7. Scriptet läser tabellen som WinMOPS lägger i Urklipp.

KÖRNING
Packa upp och dubbelklicka:
start_mops_enable_print_copy_capture_v73.bat

Följ sedan instruktionerna i det svarta fönstret. Excel kan öppnas när Print
klickas eftersom detta är den befintliga WinMOPS-funktionen.

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_ENABLE_PRINT_COPY_CAPTURE_v73.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
- produktions-MCD lämnas orörd
- endast lokal testkopia ändras, med exakt en verifierad byte
- ingen Save eller skrivning till MDE
- ingen ny MOPS COM-anslutning, Execute eller Session.Open
- befintliga WinMOPS utför sin ordinarie read-only kopieringsfunktion

Stäng testkopian utan att spara efteråt.
