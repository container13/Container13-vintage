﻿$ErrorActionPreference = "SilentlyContinue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MOPS3I_TYPELIB_SCAN_v52.txt"
Remove-Item $out -ErrorAction SilentlyContinue
function L([string]$s=""){Add-Content $out $s -Encoding UTF8}
function H([string]$s){L "";L("===== "+$s+" =====")}

L "MOPS MOPS3i TypeLib Scan v5.2"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

$clsids=@(
 "{CCA277EA-1EA4-4976-8BC8-98AE72EC4AC6}",
 "{F4EF67F7-558D-4B67-AB0A-2566D99EBCE1}"
)

H "CLSID TYPELIB LINKS"
$typelibs=@()
foreach($id in $clsids){
 $ck="Registry::HKEY_CLASSES_ROOT\CLSID\$id"
 L("CLSID="+$id)
 foreach($sub in @("TypeLib","Version","InprocServer32","ProgID")){
   $sp=Join-Path $ck $sub
   if(Test-Path $sp){
     $v=(Get-Item $sp).GetValue("")
     L("  "+$sub+"="+$v)
     if($sub -eq "TypeLib" -and $v){$typelibs += $v}
   } else {L("  "+$sub+"=<not present>")}
 }
}

H "TYPELIBS REFERENCING MOPS3I.MCX"
$tlroot="Registry::HKEY_CLASSES_ROOT\TypeLib"
if(Test-Path $tlroot){
 foreach($tk in Get-ChildItem $tlroot){
   $hit=$false;$lines=@()
   foreach($vk in Get-ChildItem $tk.PSPath){
     $nm=$vk.GetValue("")
     foreach($lcid in Get-ChildItem $vk.PSPath){
       foreach($plat in @("win32","win64")){
         $pp=Join-Path $lcid.PSPath $plat
         if(Test-Path $pp){
           $pv=(Get-Item $pp).GetValue("")
           if($pv -match '(?i)mops3i\.mcx'){
             $hit=$true
             $lines += ("  Version="+$vk.PSChildName+" Name="+$nm+" LCID="+$lcid.PSChildName+" "+$plat+"="+$pv)
           }
         }
       }
     }
   }
   if($hit){
     L("TypeLib="+$tk.PSChildName)
     foreach($x in $lines){L $x}
   }
 }
}

H "OLEVIEW-STYLE TYPEINFO VIA TLBDUMP IF AVAILABLE"
$tools=@(
 "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\TlbExp.exe",
 "$env:WINDIR\Microsoft.NET\Framework\v2.0.50727\TlbExp.exe"
)
foreach($t in $tools){if(Test-Path $t){L("Found="+$t)}}

H "MCX FILE VERSION"
$f="C:\Program Files (x86)\MOPS\sys\bin\mops3i.mcx"
if(Test-Path $f){
 $vi=(Get-Item $f).VersionInfo
 L("File="+$f)
 L("FileVersion="+$vi.FileVersion)
 L("ProductVersion="+$vi.ProductVersion)
 L("ProductName="+$vi.ProductName)
 L("CompanyName="+$vi.CompanyName)
}

H "SUMMARY"
L "Registry/type-library metadata only."
L "No COM object created."
L "No server connection/login/query."
L "No Execute/Submit/Update/Write."
L ("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
