﻿# Labdata MOPS Bridge v0.12
# Read-only. Binds only to 127.0.0.1.
# Purpose: keep the working MOPS health check and inspect the exact COM
# type information exposed by MOPS.Command.Parameters.
# No TagHistory Execute and no write/update/delete calls.

$ErrorActionPreference = "Stop"

$addr = "127.0.0.1"
$port = 8765
$connectionString = "//HOIGIBMOCLAP12/"

if (-not ("ComTypeInspectorV10" -as [type])) {
$source = @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

[ComImport]
[Guid("00020400-0000-0000-C000-000000000046")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IDispatchNativeV10
{
    [PreserveSig]
    int GetTypeInfoCount(out uint pctinfo);

    [PreserveSig]
    int GetTypeInfo(uint iTInfo, uint lcid, out ITypeInfo ppTInfo);

    [PreserveSig]
    int GetIDsOfNames(
        ref Guid riid,
        [MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPWStr)] string[] rgszNames,
        uint cNames,
        uint lcid,
        [Out, MarshalAs(UnmanagedType.LPArray)] int[] rgDispId);

    [PreserveSig]
    int Invoke(
        int dispIdMember,
        ref Guid riid,
        uint lcid,
        ushort wFlags,
        IntPtr pDispParams,
        IntPtr pVarResult,
        IntPtr pExcepInfo,
        IntPtr puArgErr);
}

public static class ComTypeInspectorV10
{
    static string InvokeKindName(System.Runtime.InteropServices.ComTypes.INVOKEKIND kind)
    {
        switch (kind)
        {
            case System.Runtime.InteropServices.ComTypes.INVOKEKIND.INVOKE_FUNC:
                return "METHOD";
            case System.Runtime.InteropServices.ComTypes.INVOKEKIND.INVOKE_PROPERTYGET:
                return "PROPERTYGET";
            case System.Runtime.InteropServices.ComTypes.INVOKEKIND.INVOKE_PROPERTYPUT:
                return "PROPERTYPUT";
            case System.Runtime.InteropServices.ComTypes.INVOKEKIND.INVOKE_PROPERTYPUTREF:
                return "PROPERTYPUTREF";
            default:
                return kind.ToString();
        }
    }

    public static string[] Inspect(object obj)
    {
        var rows = new List<string>();

        if (obj == null)
        {
            rows.Add("OBJECT=NULL");
            return rows.ToArray();
        }

        var disp = (IDispatchNativeV10)obj;

        uint count;
        int hr = disp.GetTypeInfoCount(out count);
        rows.Add("GetTypeInfoCount hr=0x" + hr.ToString("X8") + " count=" + count);

        if (hr != 0 || count == 0)
            return rows.ToArray();

        ITypeInfo typeInfo;
        hr = disp.GetTypeInfo(0, 0, out typeInfo);
        rows.Add("GetTypeInfo hr=0x" + hr.ToString("X8"));

        if (hr != 0 || typeInfo == null)
            return rows.ToArray();

        IntPtr pTypeAttr = IntPtr.Zero;
        typeInfo.GetTypeAttr(out pTypeAttr);

        try
        {
            System.Runtime.InteropServices.ComTypes.TYPEATTR attr = (System.Runtime.InteropServices.ComTypes.TYPEATTR)Marshal.PtrToStructure(pTypeAttr, typeof(System.Runtime.InteropServices.ComTypes.TYPEATTR));
            rows.Add("Functions=" + attr.cFuncs + " Variables=" + attr.cVars);

            for (int i = 0; i < attr.cFuncs; i++)
            {
                IntPtr pFunc = IntPtr.Zero;
                typeInfo.GetFuncDesc(i, out pFunc);

                try
                {
                    System.Runtime.InteropServices.ComTypes.FUNCDESC fd = (System.Runtime.InteropServices.ComTypes.FUNCDESC)Marshal.PtrToStructure(pFunc, typeof(System.Runtime.InteropServices.ComTypes.FUNCDESC));

                    string[] names = new string[Math.Max(1, fd.cParams + 1)];
                    int got;
                    typeInfo.GetNames(fd.memid, names, names.Length, out got);

                    string memberName = got > 0 ? names[0] : ("DISPID_" + fd.memid);

                    var parameters = new List<string>();
                    for (int n = 1; n < got; n++)
                        parameters.Add(names[n]);

                    rows.Add(
                        InvokeKindName(fd.invkind) +
                        " | DISPID=" + fd.memid +
                        " | " + memberName +
                        "(" + String.Join(", ", parameters.ToArray()) + ")" +
                        " | Params=" + fd.cParams +
                        " Optional=" + fd.cParamsOpt
                    );
                }
                finally
                {
                    if (pFunc != IntPtr.Zero)
                        typeInfo.ReleaseFuncDesc(pFunc);
                }
            }
        }
        finally
        {
            if (pTypeAttr != IntPtr.Zero)
                typeInfo.ReleaseTypeAttr(pTypeAttr);
        }

        return rows.ToArray();
    }
}
"@

    Add-Type -TypeDefinition $source -Language CSharp
}

function Send-Json($stream, $statusCode, $obj) {
    $json = $obj | ConvertTo-Json -Depth 12 -Compress
    $body = [Text.Encoding]::UTF8.GetBytes($json)

    $reason = @{
        200 = "OK"
        400 = "Bad Request"
        404 = "Not Found"
        500 = "Internal Server Error"
    }[$statusCode]

    if (-not $reason) { $reason = "OK" }

    $header =
        "HTTP/1.1 $statusCode $reason`r`n" +
        "Content-Type: application/json; charset=utf-8`r`n" +
        "Access-Control-Allow-Origin: *`r`n" +
        "Access-Control-Allow-Methods: GET, OPTIONS`r`n" +
        "Access-Control-Allow-Headers: Content-Type`r`n" +
        "Content-Length: $($body.Length)`r`n" +
        "Connection: close`r`n`r`n"

    $headerBytes = [Text.Encoding]::ASCII.GetBytes($header)

    $stream.Write($headerBytes, 0, $headerBytes.Length)
    $stream.Write($body, 0, $body.Length)
    $stream.Flush()
}

function New-MopsConnection {
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = $connectionString
    $c.Connect()
    return $c
}

function Get-QueryValue([string]$query, [string]$name) {
    if ([string]::IsNullOrEmpty($query)) { return $null }

    foreach ($pair in $query.TrimStart('?') -split '&') {
        if ([string]::IsNullOrWhiteSpace($pair)) { continue }

        $parts = $pair -split '=', 2

        $key = [Uri]::UnescapeDataString(($parts[0] -replace '\+', ' '))
        $value = ""

        if ($parts.Count -gt 1) {
            $value = [Uri]::UnescapeDataString(($parts[1] -replace '\+', ' '))
        }

        if ($key -eq $name) {
            return $value
        }
    }

    return $null
}

function Get-Health {
    $c = $null

    try {
        $c = New-MopsConnection

        $browser = $c.Browser
        $browser.Refresh()

        return @{
            ok = $true
            read_only = $true
            version = "0.12"
            bridge = "labdata-mops-bridge"
            mops_connected = [bool]$c.IsConnected
            server_time = [string]$c.ServerTime
            service_names = @($browser.Services | ForEach-Object { $_.Name })
        }
    }
    catch {
        return @{
            ok = $false
            read_only = $true
            version = "0.12"
            error = $_.Exception.Message
            hresult = ("0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
        }
    }
    finally {
        if ($c) {
            try { $c.Disconnect() } catch {}
        }
    }
}

function Inspect-TagHistoryParameters([string]$tag) {
    if ($tag -notmatch '^\d+=\d+=.+$') {
        return @{ code=400; body=@{ok=$false;read_only=$true;error="invalid_tag"} }
    }

    $c=$null
    try {
        $c=New-MopsConnection
        $cmd=New-Object -ComObject "MOPS.Command.1"
        $cmd.Connection=$c
        $cmd.ServiceName="hist"
        $cmd.FunctionName="TagHistory"

        $p=$cmd.Parameters

        # We now know the real API:
        # Add(Name, Value), Item(Index), Count, Remove, RemoveAll,
        # SchemaAdd(vtSchema, Name, Value), ParametersText, SetParametersText.
        # Populate ONLY read parameters. Do NOT Execute yet.
        $endTime=[datetime]::Now
        $startTime=$endTime.AddDays(-2)

        $p.RemoveAll()
        $p.Add("Tags", $tag)
        $p.Add("StartTime", $startTime)
        $p.Add("EndTime", $endTime)
        $p.Add("NumValues", 20)

        $items=@()
        $count=[int]$p.Count
        for($i=0;$i -lt $count;$i++){
            $item=$p.Item($i)
            $items += [string]$item
        }

        $pt=$null
        try{$pt=[string]$p.ParametersText}catch{}

        $rs = New-Object -ComObject "MOPS.RecordSet.1"

        try {
            # READ ONLY: executes hist.TagHistory only.
            $cmd.Execute($rs, $true)
        } catch {
            return @{
                code=500
                body=@{
                    ok=$false
                    read_only=$true
                    version="0.12"
                    stage="execute_taghistory"
                    service="hist"
                    function="TagHistory"
                    tag=$tag
                    parameters_text=$pt
                    error=$_.Exception.Message
                    hresult=("0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
                }
            }
        }

        $resultArray=$null
        $recordCount=$null
        $flatRowCount=$null
        $flatFieldCount=$null
        try{$resultArray=$rs.ResultArray}catch{}
        try{$recordCount=$rs.RecordCount}catch{}
        try{$flatRowCount=$rs.FlatRowCount}catch{}
        try{$flatFieldCount=$rs.FlatFieldCount}catch{}

        return @{
            code=200
            body=@{
                ok=$true
                read_only=$true
                version="0.12"
                stage="taghistory_executed"
                mops_connected=[bool]$c.IsConnected
                service="hist"
                function="TagHistory"
                tag=$tag
                parameters_text=$pt
                record_count=$recordCount
                flat_row_count=$flatRowCount
                flat_field_count=$flatFieldCount
                result_array=$resultArray
                execute_performed=$true
            }
        }
    } catch {
        return @{
            code=500
            body=@{
                ok=$false;read_only=$true;version="0.11"
                stage="build_parameters"
                error=$_.Exception.Message
                hresult=("0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff))
            }
        }
    } finally {
        if($c){try{$c.Disconnect()}catch{}}
    }
}

$listener = [Net.Sockets.TcpListener]::new(
    [Net.IPAddress]::Parse($addr),
    $port
)

$listener.Start()

Write-Host "Labdata MOPS Bridge v0.12"
Write-Host "Lyssnar pa http://$addr`:$port/"
Write-Host "READ-ONLY."
Write-Host "Stoppa genom att stanga PowerShell-fonstret."

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()

        try {
            $reader = New-Object IO.StreamReader(
                $stream,
                [Text.Encoding]::ASCII,
                $false,
                4096,
                $true
            )

            $firstLine = $reader.ReadLine()

            while ($true) {
                $line = $reader.ReadLine()
                if ($null -eq $line -or $line -eq "") { break }
            }

            $parts = $firstLine.Split(" ")
            $method = $parts[0]

            if ($method -eq "OPTIONS") {
                Send-Json $stream 200 @{ ok = $true }
                continue
            }

            if ($method -ne "GET") {
                Send-Json $stream 400 @{
                    ok = $false
                    read_only = $true
                    error = "GET only"
                }
                continue
            }

            $uri = [Uri]("http://localhost" + $parts[1])

            switch ($uri.AbsolutePath) {
                "/health" {
                    $health = Get-Health
                    if ($health.ok) {
                        Send-Json $stream 200 $health
                    }
                    else {
                        Send-Json $stream 500 $health
                    }
                }

                "/history" {
                    $tag = Get-QueryValue $uri.Query "tag"
                    $result = Inspect-TagHistoryParameters $tag
                    Send-Json $stream $result.code $result.body
                }

                default {
                    Send-Json $stream 404 @{
                        ok = $false
                        error = "not_found"
                    }
                }
            }
        }
        catch {
            try {
                Send-Json $stream 500 @{
                    ok = $false
                    read_only = $true
                    error = $_.Exception.Message
                }
            }
            catch {}
        }
        finally {
            try { $stream.Dispose() } catch {}
            try { $client.Close() } catch {}
        }
    }
}
finally {
    $listener.Stop()
}
