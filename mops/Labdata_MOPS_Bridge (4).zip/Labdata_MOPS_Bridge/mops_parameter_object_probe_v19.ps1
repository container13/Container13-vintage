﻿# mops_parameter_object_probe_v19.ps1
# MOPS Parameter object probe v1.9
#
# Syfte:
#   Ta reda pa exakt hur ett IMOPSParameter-objekt ser ut.
#
# Sakerhet:
#   - Ansluter till MOPS pa samma satt som tidigare fungerande probes.
#   - Skapar ett MOPS.Command lokalt.
#   - Satter ServiceName=hist och FunctionName=TagHistory.
#   - Lagger EN lokal testparameter ("Tags","") i command.Parameters.
#   - Anropar ALDRIG Command.Execute().
#   - Gor ingen login, ingen historikbegaran och ingen skrivning till MOPS-data.
#   - RemoveAll() koras innan avslut for att tomma den lokala parametersamlingen.
#
# Kor helst med Windows PowerShell (x86), eftersom installerad MOPS-klient ar 32-bit.

$ErrorActionPreference = "Stop"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_PARAMETER_OBJECT_PROBE_v19.txt"

function L([string]$s = "") {
    Add-Content -LiteralPath $out -Value $s -Encoding UTF8
}

function SafeValue($obj, [string]$name) {
    try {
        $v = $obj.$name
        if ($null -eq $v) { return "<null>" }
        return [string]$v
    }
    catch {
        return "<ERROR: $($_.Exception.Message)>"
    }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

$c = $null
$cmd = $null
$p = $null

try {
    L "MOPS Parameter object probe v1.9"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("COMPUTERNAME=" + $env:COMPUTERNAME)
    L ("PowerShell=" + $PSVersionTable.PSVersion)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
    L ""

    if ([Environment]::Is64BitProcess) {
        L "VARNING: Detta ar 64-bit PowerShell. Tidigare fungerande MOPS-probes har korts i 32-bit."
    }

    L "1. Skapar och ansluter MOPS.Connection ..."
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    $c.Connect()
    L ("   IsConnected=" + $c.IsConnected)
    try { L ("   TagBroker=" + [string]$c.TagBroker) } catch {}
    L ""

    L "2. Skapar MOPS.Command och kopplar live Connection ..."
    $cmd = New-Object -ComObject "MOPS.Command.1"
    $cmd.Connection = $c
    $cmd.ServiceName = "hist"
    $cmd.FunctionName = "TagHistory"
    L ("   ServiceName=" + $cmd.ServiceName)
    L ("   FunctionName=" + $cmd.FunctionName)
    L ("   Parameters.Count fore Add=" + $cmd.Parameters.Count)
    L ""

    L "3. Lagger lokal testparameter: Add('Tags','') ..."
    try {
        $p = $cmd.Parameters.Add("Tags", "")
        L "   Add=OK"
        L ("   Parameters.Count efter Add=" + $cmd.Parameters.Count)
        L ("   Returned null=" + ($null -eq $p))
    }
    catch {
        L ("   Add=FEL: " + $_.Exception.Message)
    }
    L ""

    if ($null -ne $p) {
        L "4. IMOPSParameter via PSObject metadata ..."
        try {
            $p.PSObject.Members |
                Sort-Object MemberType, Name |
                ForEach-Object {
                    L ("   {0} {1} :: {2}" -f $_.MemberType, $_.Name, $_.Definition)
                }
        }
        catch {
            L ("   Metadata FEL: " + $_.Exception.Message)
        }
        L ""

        L "5. Forsoker lasa vanliga property-namn ..."
        foreach ($name in @(
            "Name",
            "Value",
            "Type",
            "DataType",
            "Direction",
            "Required",
            "DefaultValue",
            "Description",
            "DisplayName",
            "ReadOnly"
        )) {
            L ("   {0}={1}" -f $name, (SafeValue $p $name))
        }
        L ""

        L "6. Item('Tags') fran parametersamlingen ..."
        try {
            $item = $cmd.Parameters.Item("Tags")
            L ("   Item null=" + ($null -eq $item))
            if ($null -ne $item) {
                foreach ($name in @("Name","Value","Type")) {
                    L ("   Item.{0}={1}" -f $name, (SafeValue $item $name))
                }
            }
        }
        catch {
            L ("   Item=FEL: " + $_.Exception.Message)
        }
        L ""
    }
    else {
        L "4-6. Hoppas over eftersom Add inte gav nagot IMOPSParameter-objekt."
        L ""
    }

    L "7. Tommer ENDAST den lokala Command.Parameters-samlingen ..."
    try {
        $cmd.Parameters.RemoveAll()
        L ("   RemoveAll=OK, Count=" + $cmd.Parameters.Count)
    }
    catch {
        L ("   RemoveAll=FEL: " + $_.Exception.Message)
    }
    L ""

    L "KLAR - Command.Execute() anropades INTE."
}
catch {
    L ("FEL=" + $_.Exception.Message)
}
finally {
    if ($c -ne $null) {
        try {
            $c.Disconnect()
            L "Disconnect=OK"
        }
        catch {
            L ("Disconnect=FEL: " + $_.Exception.Message)
        }
    }

    L "NO EXECUTE. Ingen historikbegaran. Ingen MOPS-dataskrivning."
    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR"
Write-Host "Resultat sparat i:"
Write-Host $out
Write-Host ""
Write-Host "Skicka filen MOPS_PARAMETER_OBJECT_PROBE_v19.txt hit."
