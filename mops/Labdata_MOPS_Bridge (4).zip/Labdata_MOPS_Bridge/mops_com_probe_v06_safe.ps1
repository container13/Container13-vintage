﻿# Nya MOPS - COM probe v0.6 SAFE
# Read-only. Tests one COM object at a time and prints progress.
# Does NOT execute history, login/logout, or writes.
# Run in Windows PowerShell (x86).

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_COM_PROBE_v06_SAFE.txt"

function L([string]$s="") {
    Add-Content -LiteralPath $out -Value $s -Encoding UTF8
}
function S([string]$s) {
    L ""
    L ("===== " + $s + " =====")
    Write-Host ""
    Write-Host ("===== " + $s + " =====")
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

L "MOPS COM probe v0.6 SAFE"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("COMPUTERNAME=" + $env:COMPUTERNAME)
L ("PowerShell=" + $PSVersionTable.PSVersion)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

$progIds = @(
    "MOPS.Connection",
    "MOPS.Session",
    "MOPS3iHistory"
)

foreach ($progId in $progIds) {
    S $progId
    Write-Host ("1/3 Skapar " + $progId + " ...")

    $obj = $null
    try {
        $obj = New-Object -ComObject $progId
        Write-Host "   OK"
        L ("Create " + $progId + "=OK")
    } catch {
        Write-Host ("   FEL: " + $_.Exception.Message)
        L ("Create " + $progId + "=ERROR: " + $_.Exception.Message)
        continue
    }

    Write-Host "2/3 Hämtar endast medlemslista ..."
    try {
        $members = $obj | Get-Member | Sort-Object MemberType,Name
        foreach ($m in $members) {
            L ($m.MemberType.ToString().PadRight(18) + " " + $m.Name + " :: " + $m.Definition)
        }
        Write-Host ("   OK - " + $members.Count + " medlemmar")
    } catch {
        Write-Host ("   FEL: " + $_.Exception.Message)
        L ("Get-Member ERROR: " + $_.Exception.Message)
    }

    Write-Host "3/3 Frigör objekt ..."
    try {
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($obj)
        Write-Host "   OK"
        L "ReleaseComObject=OK"
    } catch {
        Write-Host ("   FEL: " + $_.Exception.Message)
        L ("ReleaseComObject ERROR: " + $_.Exception.Message)
    }

    Remove-Variable obj -ErrorAction SilentlyContinue
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

S "MOPS.Command"
Write-Host "Skapar MOPS.Command och hämtar endast medlemslista ..."
$cmd = $null
try {
    $cmd = New-Object -ComObject "MOPS.Command"
    L "Create MOPS.Command=OK"
    $members = $cmd | Get-Member | Sort-Object MemberType,Name
    foreach ($m in $members) {
        L ($m.MemberType.ToString().PadRight(18) + " " + $m.Name + " :: " + $m.Definition)
    }
    Write-Host ("OK - " + $members.Count + " medlemmar")
} catch {
    Write-Host ("FEL: " + $_.Exception.Message)
    L ("MOPS.Command ERROR: " + $_.Exception.Message)
}

if ($null -ne $cmd) {
    try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd) } catch {}
}

S "SUMMARY"
L "Probe complete."
L "No COM properties were read."
L "No Execute() call made."
L "No history request made."
L "No login/logout invoked."
L "No write invoked."
L ("Output=" + $out)

Write-Host ""
Write-Host "Klart."
Write-Host "Resultat:"
Write-Host $out
Write-Host ""
