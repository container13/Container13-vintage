﻿# mops_mqe_read_api_probe_v39.ps1
# Controlled READ-ONLY MQECOM API test.
# Uses MQEQuery (query object, not MQEUpdate), discovers version and initializes
# destination only. It does NOT call DoTransaction() yet.
# No DDE, no Session.Open, no MOPS write.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_READ_API_PROBE_v39.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS MQE Read API probe v3.9"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

S "MQE QUERY OBJECT"
try{
 $q=New-Object -ComObject "Mqecom.MQEQuery.5"
 L "Created=True"
 try{L("GetVersion="+$q.GetVersion())}catch{L("GetVersion FEL="+$_.Exception.Message)}
 try{L("IsMOPS3i="+$q.IsMOPS3i())}catch{L("IsMOPS3i FEL="+$_.Exception.Message)}

 S "INITIAL STATE"
 foreach($n in @("Table","Columns","SelFunction","SelParam","OrderingFunction","MaxRows","NumOfRows","NumOfColumns")){
  L($n+"="+(P $q $n))
 }

 S "DESTINATION TESTS - NO TRANSACTION"
 # Try the exact server forms already established in WinMOPS/MOPS configuration.
 foreach($dest in @("//HOIGIBMOCLAP12/?mqe","//HOIGIBMOCLAP12/")){
  try{
   $r=$q.SetDestination($dest)
   L("SetDestination("+$dest+")="+$r)
   try{L("ErrorCode="+$q.GetErrorCode())}catch{}
   try{L("ErrorType="+$q.GetErrorType())}catch{}
  }catch{
   L("SetDestination("+$dest+") FEL="+$_.Exception.Message)
  }
 }

 S "POST-DESTINATION STATE"
 foreach($n in @("Table","Columns","SelFunction","SelParam","OrderingFunction","MaxRows","NumOfRows","NumOfColumns")){
  L($n+"="+(P $q $n))
 }

}catch{L("TOP FEL="+$_.Exception.Message)}

S "SUMMARY"
L "NO DoTransaction()"
L "NO Login()/LoginFromIni()"
L "NO MQE update object"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
