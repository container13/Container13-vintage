MOPS MTest Query Files Scan v4.8

Bakgrund:
MOPS Client-manualen beskriver MTest som klienten som bygger/sparar/submittar queries.
Den anger också Mtest.ini, .qry-filer och script-parametern qryString.

Syfte:
- Hitta MTest-installation/config.
- Hitta sparade .qry-filer och läsa deras queryformat.
- Hitta .scr-exempel som refererar qryString/SUBMIT/TagHistory.
- Ingen servertrafik eller COM.

Säkerhet:
- Read-only.
- Inga loginanrop.
- Password/pwd/secret/token-liknande INI-värden maskas.

Resultat:
C:\Users\<user>\Downloads\MOPS_MTEST_QUERY_FILES_SCAN_v48.txt
