﻿$ErrorActionPreference = "Continue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_TYPELIB_SESSIONSTRING_CONTEXT_v66.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s = "") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function DumpKeyTree([string]$path, [int]$depth = 0) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $prefix = ('  ' * $depth)
    L ($prefix + 'Key=' + $path)
    try {
        $item = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
        foreach ($p in $item.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }) {
            L ($prefix + '  ' + $p.Name + '=' + [string]$p.Value)
        }
        if ($depth -lt 5) {
            foreach ($child in Get-ChildItem -LiteralPath $path -ErrorAction SilentlyContinue) {
                DumpKeyTree $child.PSPath ($depth + 1)
            }
        }
    } catch { L ($prefix + '  RegistryReadError=' + $_.Exception.Message) }
}
function ExtractStrings([byte[]]$bytes, [bool]$wide) {
    $list = New-Object System.Collections.Generic.List[string]
    if ($wide) {
        $text = [Text.Encoding]::Unicode.GetString($bytes)
    } else {
        $text = [Text.Encoding]::ASCII.GetString($bytes)
    }
    foreach ($m in [regex]::Matches($text, '[\x20-\x7E]{4,260}')) {
        $s = ($m.Value -replace '\s+', ' ').Trim()
        if ($s) { [void]$list.Add($s) }
    }
    return $list
}
function ContextHits($strings, [string]$label) {
    L ('-- ' + $label + ' --')
    $pattern = '(?i)(SessionString|IMOPSSession|TurnOffCallbackPing|CallbackHandler|ImmediateDetach|NoCallback|ExecuteContextQuery|CommandType|Session used|connection to service provider)'
    $indexes = New-Object System.Collections.Generic.HashSet[int]
    for ($i = 0; $i -lt $strings.Count; $i++) {
        if ($strings[$i] -match $pattern) {
            for ($j = [Math]::Max(0, $i - 12); $j -le [Math]::Min($strings.Count - 1, $i + 12); $j++) {
                [void]$indexes.Add($j)
            }
        }
    }
    if ($indexes.Count -eq 0) { L '  No context hits.'; return }
    foreach ($i in ($indexes | Sort-Object)) { L ('  S[{0}] {1}' -f $i, $strings[$i]) }
}

try {
    L 'MOPS TypeLib SessionString Context Probe v6.6'
    L ('Time=' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    L ('WindowsIdentity=' + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ('Is64BitProcess=' + [Environment]::Is64BitProcess)
    L 'PURPOSE=Resolve SessionString and callback/detach semantics before Session.Open or Execute.'

    if ([Environment]::Is64BitProcess) { throw '64-bit process detected; use supplied 32-bit launcher.' }

    L ''
    L '===== REGISTERED MOPS CLIENT TYPELIB ====='
    $tlb = '{CE7B5787-041A-11D2-8E1D-0060B0B5BE47}'
    foreach ($root in @(
        'Registry::HKEY_CLASSES_ROOT\TypeLib',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\TypeLib',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\TypeLib'
    )) { DumpKeyTree (Join-Path $root $tlb) }

    L ''
    L '===== MCLIENT TYPELIB STRING CONTEXT ====='
    $path = Join-Path ${env:ProgramFiles(x86)} 'MOPS\sys\bin\mclient.dll'
    L ('File=' + $path)
    if (-not (Test-Path -LiteralPath $path)) { throw 'mclient.dll not found.' }
    $bytes = [IO.File]::ReadAllBytes($path)
    L ('Length=' + $bytes.Length)
    L ('SHA256=' + (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash)
    $ascii = @(ExtractStrings $bytes $false)
    $wide = @(ExtractStrings $bytes $true)
    L ('AsciiStrings=' + $ascii.Count)
    L ('Utf16Strings=' + $wide.Count)
    ContextHits $ascii 'ASCII ordered context'
    ContextHits $wide 'UTF-16 ordered context'

    L ''
    L '===== SAFETY ====='
    L 'Registry and local mclient.dll byte inspection only.'
    L 'No COM object created.'
    L 'No Connection.Connect, Session.Open, CommandText, or Execute.'
    L 'No network call, DDE, MCD access, or write operation.'
} catch {
    L ''
    L ('ERROR=' + $_.Exception.Message)
    try { L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffff)) } catch {}
} finally {
    L ('Output=' + $out)
}

Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
