NYA MOPS - MDEGRID CLIPBOARD CAPTURE v7.1
Datum: 2026-09-09

SYFTE
Kontrollera om befintliga, brandväggsgodkända WinMOPS kan lämna hela den
aktuella MDEGrid-tabellen till Nya MOPS via funktionen Kopiera allt.

KÖRNING
1. Packa upp ZIP-filen.
2. Dubbelklicka start_mops_mdegrid_clipboard_capture_v71.bat.
3. Följ instruktionerna i det svarta fönstret:
   - öppna Manuell labdata Alt1 i WinMOPS
   - kontrollera att riktiga värden syns
   - klicka i själva MDEGrid-tabellen
   - välj Kopiera allt / Copy All i tabellens meny eller kopieringsknapp
   - återvänd till det svarta fönstret och tryck Enter

VIKTIGT
Kopiera ingenting annat mellan Kopiera allt och Enter. Resultatfilen kommer
att innehålla den text/tabell som ligger i Urklipp efter åtgärden.

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_MDEGRID_CLIPBOARD_CAPTURE_v71.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
- befintliga WinMOPS hämtar informationen
- scriptet läser endast Urklipp och ändrar det inte
- ingen ny MOPS-anslutning, COM, DDE, Execute eller Session.Open
- ingen MCD-ändring
- inga värden matas in och ingen Save/Update/Insert/Delete/Write utförs

Launchern använder sin egen mapp och 32-bitars PowerShell i STA-läge.
