﻿# mops_mqe_taghistory_execute_probe_v31.ps1
# CONTROLLED READ-ONLY SERVER CALL.
# Första kontrollerade Execute() mot service "mqe", function "TagHistory".
# Hämtar endast historik för EN verifierad tagg under ett kort tidsfönster.
# Ingen Session.Open(), inga credentials sätts, ingen MOPS-data skrivs.

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_TAGHISTORY_EXECUTE_PROBE_v31.txt"

function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function S([string]$s){ L ""; L ("===== " + $s + " =====") }
function P($o,[string]$n){
    try {
        $v = $o.$n
        if($null -eq $v){ return "<null>" }
        return [string]$v
    } catch {
        return "<ERR: " + $_.Exception.Message + ">"
    }
}
function HResultHex($ex){
    try { return ("0x{0:X8}" -f ([uint32]$ex.HResult)) } catch { return "<unknown>" }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

L "MOPS MQE TagHistory Execute probe v3.1"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

$tag = "22=3120=7264"
$start = (Get-Date).AddHours(-2)
$end = Get-Date
$num = 10

$c = $null
try {
    S "CONNECTION"
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    $c.Connect()

    L ("IsConnected=" + (P $c "IsConnected"))
    L ("ConnectionString=" + (P $c "ConnectionString"))
    L ("TagBroker=" + (P $c "TagBroker"))
    L ("ServerTime=" + (P $c "ServerTime"))

    S "COMMAND BUILD"
    $cmd = New-Object -ComObject "MOPS.Command.1"
    $cmd.Connection = $c
    $cmd.ServiceName = "mqe"
    $cmd.FunctionName = "TagHistory"

    $p = $cmd.Parameters
    $a0 = $p.Add("Tags", $tag)
    $a1 = $p.Add("StartTime", $start)
    $a2 = $p.Add("EndTime", $end)
    $a3 = $p.Add("NumValues", $num)

    L "ServiceName assigned=mqe"
    L "FunctionName assigned=TagHistory"
    L ("Tag=" + $tag)
    L ("StartTime=" + $start.ToString("yyyy-MM-dd HH:mm:ss"))
    L ("EndTime=" + $end.ToString("yyyy-MM-dd HH:mm:ss"))
    L ("NumValues=" + $num)
    L ("ParameterCount=" + (P $p "Count"))
    L ("Command.Session=" + (P $cmd "Session"))
    L ("CommandType=" + (P $cmd "CommandType"))
    L ("PageSize=" + (P $cmd "PageSize"))

    for($i=0; $i -lt [int]$p.Count; $i++){
        try {
            $x = $p.Item($i)
            L ("PARAM[$i] Name=" + (P $x "Name") + " | Value=" + (P $x "Value") + " | Type=" + (P $x "Type"))
        } catch {
            L ("PARAM[$i] FEL=" + $_.Exception.Message)
        }
    }

    S "EXECUTE MQE.TAGHISTORY"
    L "OBS: Detta är en read-only historikfråga mot MOPS-servern."
    $rs = New-Object -ComObject "MOPS.RecordSet.1"

    try {
        $ret = $cmd.Execute($rs, $true)
        L ("Execute=OK")
        L ("ExecuteReturn=" + [string]$ret)

        S "RECORDSET"
        foreach($n in @("RecordCount","FlatRowCount","FlatFieldCount","EOF","BOF")){
            L ($n + "=" + (P $rs $n))
        }

        try {
            $arr = $rs.ResultArray
            if($null -eq $arr){
                L "ResultArray=<null>"
            } else {
                L ("ResultArray.Type=" + $arr.GetType().FullName)
                try {
                    $rank = $arr.Rank
                    L ("ResultArray.Rank=" + $rank)
                    if($rank -eq 2){
                        $r0=$arr.GetLowerBound(0); $r1=$arr.GetUpperBound(0)
                        $c0=$arr.GetLowerBound(1); $c1=$arr.GetUpperBound(1)
                        L ("Bounds0=$r0..$r1 Bounds1=$c0..$c1")
                        $maxRows=[Math]::Min($r1,$r0+19)
                        for($r=$r0;$r-le$maxRows;$r++){
                            $vals=@()
                            for($cc=$c0;$cc-le$c1;$cc++){
                                try{$vals += [string]$arr.GetValue($r,$cc)}catch{$vals += "<ERR>"}
                            }
                            L ("ROW[$r] " + ($vals -join " | "))
                        }
                    } else {
                        $vals=@()
                        foreach($v in $arr){ $vals += [string]$v; if($vals.Count -ge 50){break} }
                        L ("ResultArray.Sample=" + ($vals -join " | "))
                    }
                } catch {
                    L ("ResultArray inspect FEL=" + $_.Exception.Message)
                }
            }
        } catch {
            L ("ResultArray FEL=" + $_.Exception.Message)
        }

        # Även fältmetadata om RecordSet exponerar det
        try {
            $fields = $rs.Fields
            L ("Fields.Count=" + (P $fields "Count"))
            for($i=0;$i-lt [int]$fields.Count;$i++){
                try{
                    $f=$fields.Item($i)
                    L ("FIELD[$i] Name=" + (P $f "Name") + " | Value=" + (P $f "Value") + " | Type=" + (P $f "Type"))
                }catch{}
            }
        } catch {}

    } catch {
        L ("Execute=FEL: " + $_.Exception.Message)
        L ("HRESULT=" + (HResultHex $_.Exception))
        try { L ("InnerException=" + $_.Exception.InnerException.Message) } catch {}
    }

} catch {
    L ("TOP FEL=" + $_.Exception.Message)
    L ("HRESULT=" + (HResultHex $_.Exception))
} finally {
    if($c){
        try { $c.Disconnect(); L "Disconnect=OK" } catch {}
    }
}

S "SUMMARY"
L "Execute() WAS called once against mqe.TagHistory."
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write function called"
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
