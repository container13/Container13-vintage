﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MOPS3IHISTORY_MEMBERS_v51.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s){ L ""; L ("===== " + $s + " =====") }

L "MOPS MOPS3iHistory Member Scan v5.1"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

$targets = @(
  @{ ProgID="MOPS3iHistory"; CLSID="{CCA277EA-1EA4-4976-8BC8-98AE72EC4AC6}" },
  @{ ProgID="MOPS3iSnapshot"; CLSID="{F4EF67F7-558D-4B67-AB0A-2566D99EBCE1}" }
)

H "REGISTRY - EXACT CLSID DETAILS"
foreach($t in $targets){
  L ("ProgID=" + $t.ProgID)
  foreach($base in @(
    "Registry::HKEY_CLASSES_ROOT\CLSID",
    "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID",
    "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID"
  )){
    $ck = Join-Path $base $t.CLSID
    if(Test-Path $ck){
      L ("  CLSIDKey=" + $ck)
      try{
        $default=(Get-Item $ck).GetValue("")
        if($default){ L ("  Name=" + $default) }
      }catch{}
      foreach($sub in @("InprocServer32","ProgID","VersionIndependentProgID","TypeLib","Version","Control","MiscStatus")){
        $sp=Join-Path $ck $sub
        if(Test-Path $sp){
          try{
            $v=(Get-Item $sp).GetValue("")
            if($v){ L ("  " + $sub + "=" + $v) } else { L ("  " + $sub + "=<present>") }
          }catch{}
        }
      }
      break
    }
  }
}

H "COM TYPE INFORMATION VIA GET-MEMBER - NO INVOCATION"
foreach($t in $targets){
  L ("--- " + $t.ProgID + " ---")
  try{
    $o = New-Object -ComObject $t.ProgID -ErrorAction Stop
    L ("Created=True | RuntimeType=" + $o.GetType().FullName)

    $members = @($o | Get-Member)
    L ("MemberCount=" + $members.Count)

    foreach($m in $members | Sort-Object MemberType, Name){
      L ("  " + $m.MemberType + " | " + $m.Name + " | " + $m.Definition)
    }

    try{
      [Runtime.InteropServices.Marshal]::FinalReleaseComObject($o) | Out-Null
    }catch{}
  }catch{
    L ("Created=False | Error=" + $_.Exception.Message)
  }
}

H "FOCUS NAMES"
$focus = '(?i)(tag|time|start|end|num|value|data|status|history|connect|connection|server|open|close|read|fetch|refresh|execute|query|command|parameter|field)'
foreach($t in $targets){
  L ("--- " + $t.ProgID + " focus ---")
  try{
    $o = New-Object -ComObject $t.ProgID -ErrorAction Stop
    $members = @($o | Get-Member | Where-Object { $_.Name -match $focus })
    foreach($m in $members | Sort-Object Name){
      L ("  " + $m.MemberType + " | " + $m.Name + " | " + $m.Definition)
    }
    try{ [Runtime.InteropServices.Marshal]::FinalReleaseComObject($o) | Out-Null }catch{}
  }catch{}
}

H "SUMMARY"
L "Read-only local introspection."
L "COM objects are created only to enumerate type/member metadata."
L "No COM method invoked."
L "No COM property explicitly read or written."
L "No MOPS server connection."
L "No login."
L "No query / Execute / Submit / Update / Write."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
