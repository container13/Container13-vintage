﻿$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_GETPERIODS_IMMEDIATE_DETACH_v70b.txt'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function Safe($o,[string]$p){
  try {
    $v=$o.$p
    if($null -eq $v){ return '<null>' }
    return [string]$v
  } catch {
    return '<unavailable>'
  }
}
function Tcp([string]$label){
  L ('-- '+$label+' PID='+$PID+' --')
  try{
    $rows=Get-NetTCPConnection -OwningProcess $PID -ErrorAction Stop|Sort-Object LocalPort,RemoteAddress,RemotePort
    if(-not$rows){L '  No TCP rows.'}
    foreach($t in $rows){L ('  State={0} | Local={1}:{2} | Remote={3}:{4}' -f $t.State,$t.LocalAddress,$t.LocalPort,$t.RemoteAddress,$t.RemotePort)}
  }catch{L ('  TcpError='+$_.Exception.Message)}
}
$c=$null;$cmd=$null;$rs=$null
try{
  L 'MOPS GetPeriods Immediate Detach Probe v7.0b'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('Is64BitProcess='+[Environment]::Is64BitProcess)
  L 'PURPOSE=Test exact read-only MDE.GetPeriods with documented Immediate Detach transport.'
  if([Environment]::Is64BitProcess){throw '64-bit process detected; use supplied 32-bit launcher.'}

  L ''
  L '===== CONNECTION ====='
  $c=New-Object -ComObject 'MOPS.Connection.1'
  $c.ConnectionString='//HOIGIBMOCLAP12/'
  $c.Connect()
  L 'Connect=OK'
  L ('IsConnected='+(Safe $c 'IsConnected'))
  L ('ServerTime='+(Safe $c 'ServerTime'))
  Tcp 'After Connect'

  L ''
  L '===== COMMAND ====='
  $cmd=New-Object -ComObject 'MOPS.Command.1'
  $cmd.Connection=$c
  $cmd.CommandText='?MDE.GetPeriods()'
  L ('CommandText='+(Safe $cmd 'CommandText'))
  L ('ServiceName='+(Safe $cmd 'ServiceName'))
  L ('FunctionName='+(Safe $cmd 'FunctionName'))
  L ('Parameters.Count='+(Safe $cmd.Parameters 'Count'))
  L 'ExecuteSecondArgument=False'
  L 'Meaning=Immediate Detach / do not return-retain Service Provider'

  L ''
  L '===== EXECUTE READ-ONLY IMMEDIATE DETACH ====='
  $rs=New-Object -ComObject 'MOPS.RecordSet.1'
  $sw=[Diagnostics.Stopwatch]::StartNew()
  $ret=$cmd.Execute($rs,$false)
  $sw.Stop()
  L 'Execute=OK'
  L ('ExecuteReturn='+(if($null-eq$ret){'<null>'}else{[string]$ret}))
  L ('ElapsedMs='+$sw.ElapsedMilliseconds)
  L ('RecordCount='+(Safe $rs 'RecordCount'))
  L ('FlatRowCount='+(Safe $rs 'FlatRowCount'))
  L ('FlatFieldCount='+(Safe $rs 'FlatFieldCount'))
  L ('AllowsUpdates='+(Safe $rs 'AllowsUpdates'))

  L ''
  L '===== RESULT ====='
  try{
    $arr=$rs.ResultArray
    if($null-eq$arr){L 'ResultArray=<null>'}
    elseif($arr-is[System.Array]){
      L ('Rank='+$arr.Rank)
      if($arr.Rank-eq2){
        $r0=$arr.GetLowerBound(0);$r1=$arr.GetUpperBound(0);$c0=$arr.GetLowerBound(1);$c1=$arr.GetUpperBound(1)
        L ('Rows='+$r0+'..'+$r1);L ('Cols='+$c0+'..'+$c1)
        for($r=$r0;$r-le[Math]::Min($r1,$r0+100);$r++){
          $vals=@();for($cc=$c0;$cc-le$c1;$cc++){$v=$arr.GetValue($r,$cc);if($null-eq$v){$vals+='<null>'}else{$vals+=[string]$v}}
          L ('ROW['+$r+'] '+($vals-join' | '))
        }
      }
    }else{L ('ResultArray='+[string]$arr)}
  }catch{L ('ResultReadError='+$_.Exception.Message)}
  Tcp 'After Execute'

  L ''
  L '===== SAFETY ====='
  L 'Executed exactly one read-only command: ?MDE.GetPeriods().'
  L 'Execute second argument was False, matching MTest Immediate Detach semantics.'
  L 'No Session.Open, callback configuration, DDE, MCD change, or write operation.'
  L 'No Data/Update/Insert/Delete/Write/Save function.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
  Tcp 'After error'
}finally{
  if($rs){try{$rs.Close();L 'RecordSet.Close=OK'}catch{}}
  if($c){try{$c.Disconnect();L 'Disconnect=OK'}catch{}}
  L ('Output='+$out)
}
Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
