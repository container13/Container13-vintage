MOPS MOPS3iHistory Member Scan v5.1

Syfte:
Kartlägga MOPS3iHistory och MOPS3iSnapshot efter v50c, utan serveranrop.

v51 gör:
- Exakt CLSID/registry-läsning för de två redan verifierade COM-objekten.
- Skapar objekten lokalt.
- Använder PowerShell Get-Member för att lista COM-medlemmarnas namn,
  medlemstyp och definition/signatur.
- Markerar särskilt namn som rör tagg, tid, data, status, anslutning,
  historik och query.

v51 gör INTE:
- Ingen serveranslutning.
- Ingen login.
- Ingen historikfråga.
- Ingen Execute/Submit/Update/Write.
- Ingen explicit läsning eller skrivning av COM-properties.

Resultat:
C:\Users\<user>\Downloads\MOPS_MOPS3IHISTORY_MEMBERS_v51.txt
