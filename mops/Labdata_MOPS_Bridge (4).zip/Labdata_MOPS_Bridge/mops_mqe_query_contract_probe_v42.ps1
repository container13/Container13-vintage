﻿# mops_mqe_query_contract_probe_v42.ps1
# READ-ONLY contract discovery for MQECOMDLL$QUERY.
# We now know destination works and DoTransaction reaches MQE but query shape is rejected (-2004).
# This probe inspects Browser metadata for MQECOMDLL$QUERY and TagHistory.
# NO DoTransaction, NO login, NO writes.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_QUERY_CONTRACT_PROBE_v42.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR>"}}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS MQE Query Contract probe v4.2"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

try{
 $c=New-Object -ComObject "MOPS.Connection.1"
 $c.ConnectionString="//HOIGIBMOCLAP12/"
 $c.Connect()
 $b=$c.Browser
 $b.Refresh()

 $mqe=$null
 for($i=0;$i-lt [int]$b.Services.Count;$i++){
  $x=$b.Services.Item($i)
  if((P $x "Name") -eq "mqe"){$mqe=$x;break}
 }
 if(!$mqe){throw "mqe service not found"}

 foreach($wanted in @("MQECOMDLL`$QUERY","TagHistory","BrowseTags","TagValue")){
  S ("FUNCTION "+$wanted)
  $fn=$null
  for($i=0;$i-lt [int]$mqe.Functions.Count;$i++){
   $x=$mqe.Functions.Item($i)
   if((P $x "Name") -eq $wanted){$fn=$x;break}
  }
  if(!$fn){L "NOT FOUND";continue}
  L("Name="+(P $fn "Name"))
  try{
   $p=$fn.Parameters
   L("Parameters.Count="+(P $p "Count"))
   for($j=0;$j-lt [int]$p.Count;$j++){
    $v=$p.Item($j)
    L("P[$j] Name="+(P $v "Name")+" | Type="+(P $v "Type")+" | Value="+(P $v "Value"))
   }
  }catch{L("Parameters FEL="+$_.Exception.Message)}
  try{
   $f=$fn.Fields
   L("Fields.Count="+(P $f "Count"))
   for($j=0;$j-lt [int]$f.Count;$j++){
    $v=$f.Item($j)
    L("F[$j] Name="+(P $v "Name")+" | Type="+(P $v "Type"))
   }
  }catch{L("Fields FEL="+$_.Exception.Message)}
 }
 $c.Disconnect();L "";L "Disconnect=OK"
}catch{L("TOP FEL="+$_.Exception.Message)}

S "SUMMARY"
L "NO DoTransaction()"
L "NO Login()/LoginFromIni()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
