﻿# MOPS hist provider probe v0.2
# READ-ONLY. Searches only local MOPS configuration/registry for the exact
# hist ProviderClassID and ServiceID. Does not execute hist and does not scan network.

$ErrorActionPreference="Stop"
$provider="{FEA51AAA-A507-4ED5-8075-7F9CFA8D06B9}"
$service="{7B54F571-D4C1-426E-A78B-1212F3E71B58}"
$outFile=Join-Path $env:USERPROFILE "Downloads\MOPS_HIST_PROVIDER_PROBE_v02.txt"

Remove-Item $outFile -ErrorAction SilentlyContinue
"Provider probe v0.2`r`nProviderClassID=$provider`r`nServiceID=$service" | Set-Content $outFile

"`r`n===== REGISTRY MATCHES =====" | Add-Content $outFile
$roots=@(
 "Registry::HKEY_CURRENT_USER\Software",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\MOPS",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\MOPS"
)
foreach($root in $roots){
 if(Test-Path $root){
   Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
     $p=$_.PSPath
     try{
       $v=Get-ItemProperty $p -ErrorAction Stop
       $s=($v.PSObject.Properties | Where-Object {$_.Name -notmatch '^PS'} |
          ForEach-Object {"$($_.Name)=$($_.Value)"}) -join " | "
       if($_.Name -like "*$provider*" -or $_.Name -like "*$service*" -or
          $s -like "*$provider*" -or $s -like "*$service*"){
         "$p`r`n  $s" | Add-Content $outFile
       }
     }catch{}
   }
 }
}

"`r`n===== LOCAL MOPS FILE MATCHES =====" | Add-Content $outFile
$mops="C:\Program Files (x86)\MOPS"
if(Test-Path $mops){
 Get-ChildItem $mops -Recurse -File -ErrorAction SilentlyContinue |
   Where-Object {$_.Length -lt 20MB} | ForEach-Object {
     try{
       $hit=Select-String -LiteralPath $_.FullName -SimpleMatch -Pattern $provider,$service `
             -Encoding Default -ErrorAction Stop
       if($hit){ $_.FullName | Add-Content $outFile }
     }catch{}
   }
}

Write-Host ""
Write-Host "KLAR"
Write-Host "Skicka denna fil hit:"
Write-Host $outFile
