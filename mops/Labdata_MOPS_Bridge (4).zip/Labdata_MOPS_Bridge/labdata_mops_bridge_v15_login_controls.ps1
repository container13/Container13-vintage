﻿# Labdata / Nya MOPS - lokal read-only testbridge v12
# Binder ENDAST till 127.0.0.1:8765.
# Ingen skrivning till MOPS är implementerad eller tillåten.

$ErrorActionPreference = "Stop"

$BridgeVersion = "15"
$BindAddress   = "127.0.0.1"
$Port          = 8765
$KnownTag      = "22=3120=7264"

function Json($obj) {
    return ($obj | ConvertTo-Json -Depth 8 -Compress)
}

function Send-Response {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$StatusCode,
        [string]$StatusText,
        [string]$Body,
        [string]$ContentType = "application/json; charset=utf-8"
    )

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
    $headers = @(
        "HTTP/1.1 $StatusCode $StatusText"
        "Content-Type: $ContentType"
        "Content-Length: $($bytes.Length)"
        "Access-Control-Allow-Origin: *"
        "Access-Control-Allow-Methods: GET, POST, OPTIONS"
        "Access-Control-Allow-Headers: Content-Type"
        "Cache-Control: no-store"
        "Connection: close"
        ""
        ""
    ) -join "`r`n"

    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($headers)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($bytes.Length -gt 0) {
        $Stream.Write($bytes, 0, $bytes.Length)
    }
    $Stream.Flush()
}

function Get-WinMopsInfo {
    $items = @()
    Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -match "mops|mde" } |
        ForEach-Object {
            $items += [ordered]@{
                process = $_.ProcessName
                pid     = $_.Id
            }
        }
    return $items
}

function Test-MopsCommandCom {
    $result = [ordered]@{
        progId    = "MOPS.Command"
        available = $false
        error     = $null
    }
    $obj = $null
    try {
        $obj = New-Object -ComObject "MOPS.Command"
        $result.available = $true
    }
    catch {
        $result.error = $_.Exception.Message
    }
    finally {
        if ($null -ne $obj) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($obj) } catch {}
        }
    }
    return $result
}

function Base-Info {
    return [ordered]@{
        bridgeVersion = $BridgeVersion
        machine       = $env:COMPUTERNAME
        user          = $env:USERNAME
        processId     = $PID
        is64BitProcess = [Environment]::Is64BitProcess
        powershell    = $PSVersionTable.PSVersion.ToString()
        time          = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssK")
    }
}


function Get-TagMapProbe {
    # Read-only placeholder contract for Nya MOPS v0.51.
    # Tomorrow this endpoint can be filled with real tag metadata from the
    # verified WinMOPS/MDE transport without changing the HTML contract.
    return [ordered]@{
        status = "prepared"
        endpoint = "/tag-map-test"
        readOnly = $true
        tags = @(
            [ordered]@{
                tag = $KnownTag
                name = "L4 Massa från Kokare"
                description = "Kappa"
                verified = $true
            }
        )
        note = "En verifierad tagg ingår. Övriga taggar fylls på först när riktig MOPS-tagmetadata kan läsas på Holmen."
    }
}

$listener = New-Object System.Net.Sockets.TcpListener(
    [System.Net.IPAddress]::Parse($BindAddress),
    $Port
)
$listener.Start()

Write-Host ""
Write-Host "Nya MOPS login-ready bridge v$BridgeVersion"
Write-Host "Lyssnar: http://$BindAddress`:$Port"
Write-Host "Read-only. /write är spärrad."
Write-Host "Stoppa med Ctrl+C."
Write-Host ""

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader(
                $stream,
                [System.Text.Encoding]::ASCII,
                $false,
                4096,
                $true
            )

            $requestLine = $reader.ReadLine()
            if ([string]::IsNullOrWhiteSpace($requestLine)) {
                continue
            }

            $parts = $requestLine.Split(" ")
            $method = $parts[0].ToUpperInvariant()
            $target = $parts[1]
            $path = ($target.Split("?"))[0]

            $contentLength = 0
            while ($true) {
                $line = $reader.ReadLine()
                if ([string]::IsNullOrEmpty($line)) { break }
                if ($line -match "^Content-Length:\s*(\d+)$") {
                    $contentLength = [int]$matches[1]
                }
            }

            $body = ""
            if ($contentLength -gt 0) {
                $chars = New-Object char[] $contentLength
                [void]$reader.ReadBlock($chars, 0, $contentLength)
                $body = -join $chars
            }

            if ($method -eq "OPTIONS") {
                Send-Response $stream 204 "No Content" ""
                continue
            }

            switch ($path) {
                "/health" {
                    $out = Base-Info
                    $out.status = "ok"
                    $out.endpoint = "/health"
                    $out.mode = "read-only"
                    $out.expectedHtml = "0.53"
                    $out.listener = "127.0.0.1:8765"
                    $out.contract = [ordered]@{
                        health = "/health"
                        mops = "/mops"
                        session = "/session"
                        tagTest = "/tag-test"
                        historyTest = "/history-test"
                        tagMapTest = "/tag-map-test"
                        history = "/history"
                        write = "/write (blocked)"
                    }
                    Send-Response $stream 200 "OK" (Json $out)
                }

                "/mops" {
                    $out = Base-Info
                    $out.status = "ok"
                    $out.endpoint = "/mops"
                    $out.winMopsProcesses = @(Get-WinMopsInfo)
                    $out.mopsCommand = Test-MopsCommandCom
                    $out.architectureCheck = [ordered]@{
                        bridgeProcess64Bit = [Environment]::Is64BitProcess
                        winMopsExpected = "32-bit"
                        recommendation = "Kör Windows PowerShell (x86)"
                    }
                    Send-Response $stream 200 "OK" (Json $out)
                }

                "/session" {
                    # Viktigt: den MCD-baserade loginmetoden är bevisad,
                    # men bridge-sessionen ska inte gissas fram.
                    $out = Base-Info
                    $out.status = "probe-ready"
                    $out.endpoint = "/session"
                    $out.loggedIn = $null
                    $out.authenticated = $null
                    $out.winMopsProcesses = @(Get-WinMopsInfo)
                    $out.note = "Sessionstatus är ännu okänd. Login/logout kopplas till verifierad MOPS-mekanism på Holmen; inga credentials lagras i HTML."
                    Send-Response $stream 200 "OK" (Json $out)
                }

                "/login" {
                    if ($method -ne "POST") {
                        Send-Response $stream 405 "Method Not Allowed" (Json @{status="error"; message="POST krävs"})
                        continue
                    }
                    Send-Response $stream 501 "Not Implemented" (Json @{
                        status="prepared"
                        endpoint="/login"
                        loggedIn=$false
                        message="Login-endpoint är förberedd men aktiveras först när MOPS-session/login verifierats på Holmen."
                    })
                }

                "/logout" {
                    if ($method -ne "POST") {
                        Send-Response $stream 405 "Method Not Allowed" (Json @{status="error"; message="POST krävs"})
                        continue
                    }
                    Send-Response $stream 501 "Not Implemented" (Json @{
                        status="prepared"
                        endpoint="/logout"
                        loggedIn=$null
                        message="Logout-endpoint är förberedd men aktiveras först när MOPS-session/logout verifierats på Holmen."
                    })
                }

                "/tag-test" {
                    $out = Base-Info
                    $out.status = "prepared"
                    $out.endpoint = "/tag-test"
                    $out.tag = $KnownTag
                    $out.note = "Känd verifierad testtagg. Historiktransport kopplas in först när WinMOPS-transporten är verifierad."
                    Send-Response $stream 200 "OK" (Json $out)
                }

                "/history-test" {
                    $out = Base-Info
                    $out.status = "prepared"
                    $out.endpoint = "/history-test"
                    $out.tag = $KnownTag
                    $out.rows = @()
                    $out.readOnly = $true
                    $out.contract = [ordered]@{
                        rowShape = [ordered]@{
                            timestamp = "YYYY-MM-DDTHH:00:00"
                            values = "array, same column count as active Nya MOPS view"
                        }
                    }
                    $out.note = "Historikkontrakt klart. rows lämnas tom tills riktig WinMOPS/MOPS-transport är verifierad på Holmen."
                    Send-Response $stream 200 "OK" (Json $out)
                }

                "/tag-map-test" {
                    $out = Base-Info
                    $probe = Get-TagMapProbe
                    foreach ($k in $probe.Keys) { $out[$k] = $probe[$k] }
                    Send-Response $stream 200 "OK" (Json $out)
                }

                "/history" {
                    if ($method -ne "POST") {
                        Send-Response $stream 405 "Method Not Allowed" (Json @{status="error"; message="POST krävs"})
                        continue
                    }
                    $out = [ordered]@{
                        status = "provider-not-connected"
                        endpoint = "/history"
                        readOnly = $true
                        requestReceived = $true
                        note = "API-kontrakt klart. MOPS history provider kopplas först efter transportverifiering."
                    }
                    Send-Response $stream 501 "Not Implemented" (Json $out)
                }

                "/write" {
                    Send-Response $stream 403 "Forbidden" (Json @{
                        status="disabled"
                        endpoint="/write"
                        writeEnabled=$false
                        message="Skrivning är avstängd tills läsning och login är verifierade."
                    })
                }

                default {
                    Send-Response $stream 404 "Not Found" (Json @{status="error"; message="Okänd endpoint"; path=$path})
                }
            }
        }
        catch {
            try {
                Send-Response $stream 500 "Internal Server Error" (Json @{
                    status="error"
                    message=$_.Exception.Message
                })
            } catch {}
        }
        finally {
            try { $client.Close() } catch {}
        }
    }
}
finally {
    $listener.Stop()
}
