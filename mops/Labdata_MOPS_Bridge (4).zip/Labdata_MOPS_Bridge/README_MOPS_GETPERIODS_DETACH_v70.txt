NYA MOPS - GETPERIODS IMMEDIATE DETACH v7.0b
Datum: 2026-09-09

TEKNISK GRUND
MTest OCX och MOPS-klientens typinformation visar att Execute-metodens andra
booleska argument är fReturnSP. MOPS-manualen beskriver Immediate Detach som
att recordsetet inte behåller anslutningen tillbaka till serviceprovidern.

Tidigare probes använde Execute(recordset, True), samtidigt som brandväggen
uttryckligen blockerar inkommande trafik till 32-bitars PowerShell.

v7.0b korrigerar ett syntaxfel i v7.0:s logghjälpfunktion och kör exakt det
redan verifierade read-only-kommandot:
?MDE.GetPeriods()

men med Execute(recordset, False), motsvarande Immediate Detach.

KÖRNING
Packa upp och dubbelklicka:
start_mops_getperiods_immediate_detach_v70.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_GETPERIODS_IMMEDIATE_DETACH_v70b.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
- exakt en read-only fråga: MDE.GetPeriods
- ingen Session.Open och ingen callbackinställning
- ingen DDE eller MCD-ändring
- ingen Data/Update/Insert/Delete/Write/Save

Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
