$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_WINDOW_CAPTURE_v80.txt'
$png=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_WINDOW_v80.png'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $png -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
try{
  Add-Type -AssemblyName System.Drawing
  Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class WinCaptureNative {
  [StructLayout(LayoutKind.Sequential)]
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
}
'@
  L 'MOPS WinMOPS Window Capture v8.0'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('PNG='+$png)
  L 'Mode=Screen capture only; no MCD file opened or modified.'

  Write-Host ''
  Write-Host 'PREPARE THE NORMAL WINMOPS WINDOW.' -ForegroundColor Yellow
  Write-Host '1. In WinMOPS, navigate to the department you want to capture.'
  Write-Host '2. Wait until the table and real values are visible.'
  Write-Host '3. Return here and press ENTER.'
  [void](Read-Host 'Press ENTER when ready')
  Write-Host ''
  Write-Host 'Switch to WinMOPS now. Capture occurs in 8 seconds.' -ForegroundColor Yellow
  for($n=8;$n-ge1;$n--){Write-Host ($n.ToString()+'...');Start-Sleep -Seconds 1}

  $hwnd=[WinCaptureNative]::GetForegroundWindow()
  if($hwnd-eq[IntPtr]::Zero){throw 'No foreground window was found.'}
  [uint32]$pidValue=0
  [void][WinCaptureNative]::GetWindowThreadProcessId($hwnd,[ref]$pidValue)
  $proc=Get-Process -Id $pidValue -ErrorAction Stop
  L ('ForegroundProcess='+$proc.ProcessName)
  L ('ForegroundPID='+$pidValue)
  L ('WindowTitle='+$proc.MainWindowTitle)
  if($proc.ProcessName-notmatch'(?i)^winmops$'){throw ('Foreground window was '+$proc.ProcessName+', not WinMOPS. Run again and switch to WinMOPS during countdown.')}

  $rect=New-Object WinCaptureNative+RECT
  if(-not[WinCaptureNative]::GetWindowRect($hwnd,[ref]$rect)){throw 'GetWindowRect failed.'}
  $width=$rect.Right-$rect.Left
  $height=$rect.Bottom-$rect.Top
  if($width-lt100-or$height-lt100){throw ('Invalid window size '+$width+'x'+$height+'.')}
  L ('Left='+$rect.Left)
  L ('Top='+$rect.Top)
  L ('Width='+$width)
  L ('Height='+$height)

  $bitmap=New-Object Drawing.Bitmap -ArgumentList $width,$height,([Drawing.Imaging.PixelFormat]::Format24bppRgb)
  $graphics=[Drawing.Graphics]::FromImage($bitmap)
  $captureSize=New-Object Drawing.Size -ArgumentList $width,$height
  $graphics.CopyFromScreen($rect.Left,$rect.Top,0,0,$captureSize,[Drawing.CopyPixelOperation]::SourceCopy)
  $graphics.Dispose()
  $bitmap.Save($png,[Drawing.Imaging.ImageFormat]::Png)
  $bitmap.Dispose()
  L ('PNGBytes='+(Get-Item -LiteralPath $png).Length)
  L ('PNGSHA256='+(Get-FileHash -LiteralPath $png -Algorithm SHA256).Hash)
  L 'CaptureResult=OK'

  L ''
  L '===== SAFETY ====='
  L 'Captured visible pixels from the foreground WinMOPS window only.'
  L 'No MCD file was created, opened, patched, or saved.'
  L 'No MOPS COM connection, Execute, Session.Open, clipboard operation, or write to MDE.'
  L 'No Update/Insert/Delete/Write/Save.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
}finally{L ('Output='+$out)}
Write-Host ''
Write-Host 'DONE - send both files:' -ForegroundColor Green
Write-Host $png
Write-Host $out
