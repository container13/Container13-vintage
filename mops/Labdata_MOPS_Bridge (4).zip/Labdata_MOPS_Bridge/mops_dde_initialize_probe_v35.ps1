﻿# mops_dde_initialize_probe_v35.ps1
# Kontrollerat test av DDE-helperns parameterlösa Initialize().
# Kör INTE ExecuteDDE(), Command.Execute() eller Session.Open().
# Ingen MOPS-data skrivs.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_DDE_INITIALIZE_PROBE_v35.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR: "+$_.Exception.Message+">"}}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS DDE Initialize probe v3.5"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
try{
 $d=New-Object -ComObject "MOPS.WinMOPSDDEHelper.1"
 L ""
 L "===== BEFORE INITIALIZE ====="
 L ("IsWinMOPSRunning="+(P $d "IsWinMOPSRunning"))
 L ("IsInitialized="+(P $d "IsInitialized"))
 L ("WinMOPSExecPath="+(P $d "WinMOPSExecPath"))
 L ""
 L "===== INITIALIZE ====="
 try{
   $d.Initialize()
   L "Initialize=OK"
 }catch{
   L ("Initialize=FEL: "+$_.Exception.Message)
   try{L ("HRESULT=0x{0:X8}" -f ([uint32]$_.Exception.HResult))}catch{}
 }
 L ""
 L "===== AFTER INITIALIZE ====="
 L ("IsWinMOPSRunning="+(P $d "IsWinMOPSRunning"))
 L ("IsInitialized="+(P $d "IsInitialized"))
 L ("WinMOPSExecPath="+(P $d "WinMOPSExecPath"))
 L ""
 L "===== CLEANUP ====="
 try{$d.Cleanup();L "Cleanup=OK"}catch{L ("Cleanup=FEL: "+$_.Exception.Message)}
 L ("IsInitializedAfterCleanup="+(P $d "IsInitialized"))
}catch{L ("TOP FEL="+$_.Exception.Message)}
L ""
L "===== SUMMARY ====="
L "Initialize() WAS called once."
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L ("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
