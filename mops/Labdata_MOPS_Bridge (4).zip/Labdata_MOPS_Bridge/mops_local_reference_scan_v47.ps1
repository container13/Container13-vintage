﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_LOCAL_REFERENCE_SCAN_v47.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s="") { Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s) { L ""; L ("===== " + $s + " =====") }

$roots = @(
  "C:\Program Files (x86)\MOPS",
  "C:\Program Files\MOPS"
) | Where-Object { Test-Path $_ }

$patterns = @(
  "MQEQuery",
  "MQECOMDLL`$QUERY",
  "SelFunction",
  "SelParam",
  "LoginFromIni",
  "TagHistory",
  "BrowseTags",
  "TagValue",
  "SetDestination",
  "DoTransaction"
)

$textExt = @(
  ".ini",".xml",".cfg",".conf",".config",".txt",".log",
  ".ps1",".psm1",".bat",".cmd",".vbs",".js",".hta",
  ".sql",".csv",".properties",".reg"
)

L "MOPS Local Reference Scan v4.7"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)

H "ROOTS"
foreach($r in $roots){ L $r }

if(-not $roots -or $roots.Count -eq 0){
  H "RESULT"
  L "No MOPS installation roots found under Program Files."
  L ("Output=" + $out)
  Write-Host ""
  Write-Host "KLAR - skicka hit:"
  Write-Host $out
  exit
}

H "TARGET DLL / RELATED FILES"
foreach($r in $roots){
  Get-ChildItem $r -File -Recurse | Where-Object {
    $_.Name -match 'mqecom|mops.*query|query.*mops|mqe'
  } | ForEach-Object {
    L ($_.FullName + " | " + $_.Length + " bytes | " + $_.LastWriteTime)
  }
}

H "TEXT REFERENCE HITS"
$files = foreach($r in $roots){
  Get-ChildItem $r -File -Recurse | Where-Object { $textExt -contains $_.Extension.ToLowerInvariant() }
}

L ("TextFilesScanned=" + (($files | Measure-Object).Count))

foreach($f in $files){
  $matched = Select-String -Path $f.FullName -Pattern $patterns -SimpleMatch -CaseSensitive:$false
  if($matched){
    L ""
    L ("FILE: " + $f.FullName)
    foreach($m in $matched){
      $line = ($m.Line -replace "`t"," " ).Trim()
      if($line.Length -gt 500){ $line = $line.Substring(0,500) + " ..." }
      L ("  [" + $m.LineNumber + "] " + $line)
    }
  }
}

H "POTENTIAL HELP / DOCUMENTATION FILES"
foreach($r in $roots){
  Get-ChildItem $r -File -Recurse | Where-Object {
    $_.Extension -in ".chm",".hlp",".pdf",".doc",".docx",".rtf",".html",".htm"
  } | ForEach-Object {
    L ($_.FullName + " | " + $_.Length + " bytes")
  }
}

H "SUMMARY"
L "Read-only local filesystem scan only."
L "NO COM object created."
L "NO server/network query executed."
L "NO login attempted."
L "NO file modified."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
