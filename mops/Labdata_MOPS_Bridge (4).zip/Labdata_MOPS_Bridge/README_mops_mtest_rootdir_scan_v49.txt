MOPS MTest RootDir Scan v4.9

Bakgrund:
v4.8 hittade MTEST.INI och rootDir=C:\WINDOWS\system32.

Syfte:
- Söka exakt i MTest rootDir.
- Söka även Windows SysWOW64 och VirtualStore-varianterna.
- Leta efter .qry/.scr och MTest/query-relaterade filer.
- Visa innehåll i query/script-filer om sådana finns.

Säkerhet:
- Read-only.
- Ingen COM.
- Ingen serverfråga.
- Ingen login.
- Inga filer ändras.
- Lösenords/token-liknande värden maskas.

Resultat:
C:\Users\<user>\Downloads\MOPS_MTEST_ROOTDIR_SCAN_v49.txt
