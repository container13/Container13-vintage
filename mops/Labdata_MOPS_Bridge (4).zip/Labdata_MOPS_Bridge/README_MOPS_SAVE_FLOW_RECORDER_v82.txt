NYA MOPS - LOGIN/EDIT/SAVE FLOW RECORDER v8.2
Datum: 2026-09-09

SYFTE
Passivt registrera vad WinMOPS gor nar anvandaren loggar in, navigerar,
registrerar ett riktigt behorigt labvarde och sparar. Roboten klickar, skriver
och sparar aldrig at anvandaren.

SKRIVBORDSIKON
1. Packa upp ZIP-filen till en permanent mapp.
2. Kor install_mops_recorder_desktop_icon_v82.bat en gang.
3. Darefter startas roboten fran ikonen:
   MOPS - spela in inloggning och sparning

TEST
1. Starta roboten fran ikonen eller start_mops_save_flow_recorder_v82.bat.
2. Roboten startar WinMOPS via befintlig genvag om WinMOPS inte redan kors.
3. Logga in manuellt.
4. Navigera till ratt avdelning.
5. Registrera ett riktigt labvarde som du ar behorig att spara.
6. Spara pa normalt satt.
7. Ga tillbaka till robotfonstret och tryck Enter.
8. Skicka resultatfilen:

C:\Users\iiblabl4\Downloads\MOPS_WINMOPS_SAVE_FLOW_v82.txt

REGISTRERAS
- WinMOPS-processens start, fonstertitlar och laddade moduler.
- Fokusbyten och UI-kontrollernas metadata, men aldrig faltenas textvarden.
- TCP-anslutningar som ags av WinMOPS.
- hjalpprocesser som startas direkt av WinMOPS.
- tidslinje fore, under och efter den manuella sparningen.

LOSENORDSSKYDD
- Tangenttryckningar registreras aldrig.
- ValuePattern eller faltinnehall avlases aldrig.
- Kontroller markerade som losenordsfalt loggas endast som REDACTED.
- Inga autentiseringshemligheter lagras i resultatfilen.

SAKERHET
- Ingen automatiserad inloggning, inmatning eller sparning.
- Ingen MCD oppnas eller andras av roboten.
- Ingen ny MOPS COM-session, Execute eller Session.Open.
- Den enda MOPS-skrivningen ar den normala sparning som anvandaren sjalv gor.
