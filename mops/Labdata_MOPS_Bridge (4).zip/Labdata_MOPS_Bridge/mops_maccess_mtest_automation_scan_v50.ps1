﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MACCESS_MTEST_AUTOMATION_SCAN_v50.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s="") { Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s) { L ""; L ("===== " + $s + " =====") }

L "MOPS MAccess / MTest Automation Scan v5.0"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

$roots = @(
  "C:\Program Files (x86)\MOPS",
  "C:\Program Files\MOPS"
) | Where-Object { Test-Path $_ }

H "LIKELY BINARIES"
$bins = @()
foreach($r in $roots){
  $bins += Get-ChildItem -LiteralPath $r -File -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '(?i)(maccess|mtest|mops3ihistory|history|commandbuilder|mclient|mqecom)' }
}
$bins = $bins | Sort-Object FullName -Unique
foreach($f in $bins){
  L ($f.FullName + " | " + $f.Length + " bytes | " + $f.LastWriteTime)
}

H "REGISTRY PROGID / CLSID MATCHES"
$regBases = @(
  "Registry::HKEY_CLASSES_ROOT",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes"
)

$seen = New-Object System.Collections.Generic.HashSet[string]
foreach($base in $regBases){
  if(!(Test-Path $base)){ continue }
  Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue | ForEach-Object {
    $name=$_.PSChildName
    if($name -match '(?i)(maccess|mtest|mops3i|mops.*history|history.*mops|mops.*command|command.*mops)'){
      $path=$_.PSPath
      if($seen.Add($path)){
        L ("KEY: " + $path)
        try{
          $p=Get-ItemProperty -LiteralPath $path -ErrorAction Stop
          foreach($prop in $p.PSObject.Properties){
            if($prop.Name -notmatch '^PS'){
              $val=[string]$prop.Value
              if($prop.Name -match '(?i)(pass|pwd|secret|token)'){ $val="<REDACTED>" }
              L ("  " + $prop.Name + "=" + $val)
            }
          }
        }catch{}
      }
    }
  }
}

H "CLSID SERVERS POINTING TO MOPS BINARIES"
$clsidBases = @(
  "Registry::HKEY_CLASSES_ROOT\CLSID",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID"
)
$seenClsid = New-Object System.Collections.Generic.HashSet[string]
foreach($cb in $clsidBases){
  if(!(Test-Path $cb)){continue}
  foreach($k in Get-ChildItem -LiteralPath $cb -ErrorAction SilentlyContinue){
    $id=$k.PSChildName
    $server=""
    foreach($sub in @("InprocServer32","LocalServer32")){
      $sp=Join-Path $k.PSPath $sub
      if(Test-Path $sp){
        try{$server=[string](Get-ItemProperty -LiteralPath $sp).'(default)'}catch{}
        if(!$server){try{$server=[string](Get-Item -LiteralPath $sp).GetValue("")}catch{}}
        if($server -match '(?i)\\MOPS\\|mtest\.ocx|maccess|mops3i|mclient|mqecom'){
          if($seenClsid.Add($id+"|"+$sub+"|"+$server)){
            L ("CLSID="+$id+" | "+$sub+"="+$server)
            try{
              $progid=(Get-ItemProperty -LiteralPath (Join-Path $k.PSPath "ProgID") -ErrorAction Stop).'(default)'
            }catch{$progid=$null}
            if(!$progid){try{$progid=(Get-Item -LiteralPath (Join-Path $k.PSPath "ProgID")).GetValue("")}catch{}}
            if($progid){L("  ProgID="+$progid)}
            try{
              $tl=(Get-Item -LiteralPath (Join-Path $k.PSPath "TypeLib")).GetValue("")
              if($tl){L("  TypeLib="+$tl)}
            }catch{}
          }
        }
      }
    }
  }
}

H "TYPELIB NAMES RELATED TO MOPS / MTEST / MACCESS"
$tlBases=@(
  "Registry::HKEY_CLASSES_ROOT\TypeLib",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\TypeLib",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\TypeLib"
)
$seenTl=New-Object System.Collections.Generic.HashSet[string]
foreach($tb in $tlBases){
  if(!(Test-Path $tb)){continue}
  foreach($tk in Get-ChildItem -LiteralPath $tb -ErrorAction SilentlyContinue){
    foreach($vk in Get-ChildItem -LiteralPath $tk.PSPath -ErrorAction SilentlyContinue){
      try{$nm=[string]$vk.GetValue("")}catch{$nm=""}
      if($nm -match '(?i)(MOPS|MTest|MAccess|History)'){
        $key=$tk.PSChildName+"|"+$vk.PSChildName+"|"+$nm
        if($seenTl.Add($key)){L("TypeLib="+$tk.PSChildName+" Version="+$vk.PSChildName+" Name="+$nm)}
      }
    }
  }
}

H "SAFE COM CREATION TESTS - LOCAL ONLY"
$progids=@(
  "MOPS3iHistory",
  "MOPS3iHistory.1",
  "MOPS.MAccess",
  "MOPS.MAccess.1",
  "MAccess.MAccess",
  "MAccess.MAccess.1"
)
foreach($pid in $progids){
  try{
    $o=New-Object -ComObject $pid -ErrorAction Stop
    L("ProgID="+$pid+" Created=True Type="+$o.GetType().FullName)
  }catch{
    L("ProgID="+$pid+" Created=False Error="+$_.Exception.Message)
  }
}

H "SUMMARY"
L "Read-only local registry/filesystem/COM creation introspection."
L "No MOPS server connection."
L "No login."
L "No query."
L "No Execute/Submit/Update/Write method invoked."
L "No file modified except this output."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
