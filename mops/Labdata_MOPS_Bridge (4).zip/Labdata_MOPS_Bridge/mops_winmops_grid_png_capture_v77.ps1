$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_GRID_PNG_v77.txt'
$png=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_GRID_v77.png'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $png -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function FindBytes([byte[]]$hay,[byte[]]$needle,[int]$start=0){
  for($i=$start;$i-le$hay.Length-$needle.Length;$i++){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if($hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
function FindBytesReverse([byte[]]$hay,[byte[]]$needle,[int]$start){
  for($i=$start;$i-ge0;$i--){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if(($i+$j)-ge$hay.Length-or$hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
try{
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  $source='\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd'
  $expected='ACE84824DD638BCEEE1DFA5EF993CC93790FC7AE5F35B51674A20D7733405DEB'
  $work=Join-Path $env:USERPROFILE 'Downloads\Labdata_MOPS_Bridge'
  $copy=Join-Path $work 'Manuell labdata Alt1_GRID_PNG_TEST_v77.mcd'

  L 'MOPS WinMOPS Grid PNG Capture v7.7 (dual enable patch)'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('Source='+$source)
  L ('TestCopy='+$copy)
  L ('PNG='+$png)

  if(-not(Test-Path -LiteralPath $source)){throw 'Production MCD could not be read.'}
  $sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
  L ('SourceSHA256='+$sourceHash)
  if($sourceHash-ne$expected){throw ('Wrong source version. Expected '+$expected+' but got '+$sourceHash+'.')}

  New-Item -ItemType Directory -Path $work -Force|Out-Null
  [byte[]]$original=[IO.File]::ReadAllBytes($source)
  [byte[]]$bytes=$original.Clone()

  [byte[]]$checkNameNeedle=[Text.Encoding]::ASCII.GetBytes('(Name "CheckboxEnablePrint")')
  $checkNameOffset=FindBytes $bytes $checkNameNeedle 0
  if($checkNameOffset-lt0){throw 'CheckboxEnablePrint was not found.'}
  if((FindBytes $bytes $checkNameNeedle ($checkNameOffset+1))-ge0){throw 'CheckboxEnablePrint occurs more than once.'}
  [byte[]]$checkValueNeedle=[Text.Encoding]::ASCII.GetBytes('(Value 0)')
  $checkValueOffset=FindBytes $bytes $checkValueNeedle $checkNameOffset
  if($checkValueOffset-lt0-or$checkValueOffset-gt($checkNameOffset+300)){throw 'Safe CheckboxEnablePrint Value property was not found.'}
  $checkDigitOffset=$checkValueOffset+7
  if($bytes[$checkDigitOffset]-ne[byte][char]'0'){throw 'Checkbox target byte was not zero.'}
  $bytes[$checkDigitOffset]=[byte][char]'1'

  [byte[]]$nameNeedle=[Text.Encoding]::ASCII.GetBytes('(Name "Button_Print")')
  $nameOffset=FindBytes $bytes $nameNeedle 0
  if($nameOffset-lt0){throw 'Button_Print was not found.'}
  if((FindBytes $bytes $nameNeedle ($nameOffset+1))-ge0){throw 'Button_Print occurs more than once.'}
  [byte[]]$valueNeedle=[Text.Encoding]::ASCII.GetBytes('(Visible 0)')
  $valueOffset=FindBytesReverse $bytes $valueNeedle $nameOffset
  if($valueOffset-lt0-or$valueOffset-lt($nameOffset-300)){throw 'Safe Button_Print Visible property was not found.'}
  $digitOffset=$valueOffset+9
  if($bytes[$digitOffset]-ne[byte][char]'0'){throw 'Target byte was not zero.'}
  $bytes[$digitOffset]=[byte][char]'1'
  [IO.File]::WriteAllBytes($copy,$bytes)

  [byte[]]$verify=[IO.File]::ReadAllBytes($copy)
  $diffs=0;$lastDiff=-1
  for($i=0;$i-lt$original.Length;$i++){if($original[$i]-ne$verify[$i]){$diffs++;$lastDiff=$i}}
  L ('Patch1=CheckboxEnablePrint.Value | Offset='+$checkDigitOffset+' | 0 -> 1')
  L ('Patch2=Button_Print.Visible | Offset='+$digitOffset+' | 0 -> 1')
  L ('VerifiedDifferentBytes='+$diffs)
  if($diffs-ne2){throw 'Local copy does not differ by exactly the two intended bytes.'}
  if($verify[$checkDigitOffset]-ne[byte][char]'1'-or$verify[$digitOffset]-ne[byte][char]'1'){throw 'One of the two intended patches was not verified.'}

  Start-Process -FilePath $copy
  Write-Host ''
  Write-Host 'LOCAL TEST COPY IS OPENING IN WINMOPS.' -ForegroundColor Yellow
  Write-Host '1. Navigate to a department and wait until real values are visible.'
  Write-Host '2. Return here BEFORE clicking Print.'
  [void](Read-Host 'Press ENTER when the table is ready')
  [Windows.Forms.Clipboard]::Clear()
  Write-Host 'MONITORING FOR 60 SECONDS - switch to WinMOPS and click PRINT now.' -ForegroundColor Yellow

  L ''
  L '===== CLIPBOARD IMAGE ====='
  L ('MonitorStart='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $deadline=(Get-Date).AddSeconds(60)
  $image=$null
  $formats=@()
  while((Get-Date)-lt$deadline-and$null-eq$image){
    try{
      $data=[Windows.Forms.Clipboard]::GetDataObject()
      if($data){$formats=@($data.GetFormats($false))}
      $image=[Windows.Forms.Clipboard]::GetImage()
    }catch{}
    if($null-eq$image){Start-Sleep -Milliseconds 100}
  }
  L ('CaptureTime='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('Formats='+($formats-join' | '))
  if($null-eq$image){throw 'No clipboard image was detected during 60 seconds.'}
  L ('Width='+$image.Width)
  L ('Height='+$image.Height)
  L ('PixelFormat='+$image.PixelFormat)
  $image.Save($png,[Drawing.Imaging.ImageFormat]::Png)
  $image.Dispose()
  L ('PNGBytes='+(Get-Item -LiteralPath $png).Length)
  L ('PNGSHA256='+(Get-FileHash -LiteralPath $png -Algorithm SHA256).Hash)

  L ''
  L '===== SAFETY ====='
  L 'Production MCD hash verified and production file left unchanged.'
  L 'Exactly two bytes changed in a local copy: CheckboxEnablePrint.Value and Button_Print.Visible, both 0 -> 1.'
  L 'WinMOPS performed its existing DoCopyAll action.'
  L 'The script only saved WinMOPS clipboard image as PNG.'
  L 'No new MOPS COM connection, Execute, Session.Open, or write to MDE.'
  L 'No Update/Insert/Delete/Write/Save.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
}finally{L ('Output='+$out)}
Write-Host ''
Write-Host 'DONE - send both files:' -ForegroundColor Green
Write-Host $out
Write-Host $png
