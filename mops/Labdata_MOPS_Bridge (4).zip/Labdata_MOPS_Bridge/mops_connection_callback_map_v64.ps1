﻿$ErrorActionPreference = "Continue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_CONNECTION_CALLBACK_MAP_v64.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s = "") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Safe($o, [string]$name) {
    try {
        $v = $o.$name
        if ($null -eq $v) { return '<null>' }
        return [string]$v
    } catch { return '<unavailable>' }
}
function TcpForPid([int]$pidValue, [string]$label) {
    L ("-- " + $label + " PID=" + $pidValue + " --")
    try {
        $rows = Get-NetTCPConnection -OwningProcess $pidValue -ErrorAction Stop |
            Sort-Object LocalPort, RemoteAddress, RemotePort
        if (-not $rows) { L "  No TCP rows." }
        foreach ($t in $rows) {
            L ("  State={0} | Local={1}:{2} | Remote={3}:{4}" -f `
                $t.State, $t.LocalAddress, $t.LocalPort, $t.RemoteAddress, $t.RemotePort)
        }
    } catch {
        L ("  Get-NetTCPConnectionError=" + $_.Exception.Message)
        $lines = & netstat.exe -ano -p tcp 2>$null
        foreach ($line in $lines) {
            if ($line -match '^\s*TCP\s+\S+\s+\S+\s+\S+\s+(\d+)\s*$' -and [int]$Matches[1] -eq $pidValue) {
                L ("  " + $line.Trim())
            }
        }
    }
}
function Members($o, [string]$label) {
    L ("-- " + $label + " --")
    try {
        $o | Get-Member | Sort-Object MemberType, Name | ForEach-Object {
            L ("  {0} {1} :: {2}" -f $_.MemberType, $_.Name, $_.Definition)
        }
    } catch { L ("  GetMemberError=" + $_.Exception.Message) }
}

$c = $null
$cmd = $null
$rs = $null
$selfPid = $PID

try {
    L "MOPS Connection/Callback Map v6.4"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ("PowerShellPID=" + $selfPid)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
    L "PURPOSE=Compare WinMOPS callback transport with a standalone connection, without Execute or Session.Open."

    if ([Environment]::Is64BitProcess) {
        throw "64-bit process detected. This probe requires the verified 32-bit MOPS client."
    }

    L ""
    L "===== NAME RESOLUTION ====="
    foreach ($name in @('HOIGIBMOCLAP12')) {
        L ("-- Name=" + $name)
        try {
            Resolve-DnsName -Name $name -ErrorAction Stop | Where-Object { $_.IPAddress -or $_.NameHost } | ForEach-Object {
                L ("  Type={0} | IPAddress={1} | NameHost={2}" -f $_.Type, $_.IPAddress, $_.NameHost)
            }
        } catch { L ("  ResolveError=" + $_.Exception.Message) }
    }

    L ""
    L "===== FIREWALL PROFILE STATE ====="
    try {
        Get-NetFirewallProfile -ErrorAction Stop | ForEach-Object {
            L ("Name={0} | Enabled={1} | DefaultInboundAction={2} | DefaultOutboundAction={3}" -f `
                $_.Name, $_.Enabled, $_.DefaultInboundAction, $_.DefaultOutboundAction)
        }
    } catch { L ("FirewallProfileError=" + $_.Exception.Message) }

    L ""
    L "===== RELEVANT FIREWALL APPLICATION RULES ====="
    try {
        $apps = Get-NetFirewallApplicationFilter -PolicyStore ActiveStore -ErrorAction Stop |
            Where-Object { $_.Program -match '(?i)(winmops|powershell|\\MOPS\\)' }
        if (-not $apps) { L "No matching application filters found." }
        foreach ($app in $apps) {
            $rule = Get-NetFirewallRule -AssociatedNetFirewallApplicationFilter $app -ErrorAction SilentlyContinue
            foreach ($r in $rule) {
                L ("Rule={0} | DisplayName={1} | Enabled={2} | Direction={3} | Action={4} | Profile={5} | Program={6}" -f `
                    $r.Name, $r.DisplayName, $r.Enabled, $r.Direction, $r.Action, $r.Profile, $app.Program)
            }
        }
    } catch { L ("FirewallRuleError=" + $_.Exception.Message) }

    L ""
    L "===== WINMOPS TCP BASELINE ====="
    $winmops = Get-Process -Name winmops -ErrorAction SilentlyContinue
    if (-not $winmops) { L "WinMOPS process not found." }
    foreach ($p in $winmops) { TcpForPid $p.Id ("WinMOPS " + $p.ProcessName) }

    L ""
    L "===== STANDALONE POWERSHELL BEFORE CONNECT ====="
    TcpForPid $selfPid "PowerShell before Connect"

    L ""
    L "===== COM PROGID / CLSID ====="
    foreach ($progId in @('MOPS.Connection.1', 'MOPS.Command.1', 'MOPS.RecordSet.1', 'MOPS.Session.1')) {
        try {
            $type = [Type]::GetTypeFromProgID($progId, $false)
            if ($null -eq $type) { L ("ProgID=" + $progId + " | Type=<not registered>") }
            else { L ("ProgID=" + $progId + " | CLSID=" + $type.GUID.ToString('B')) }
        } catch { L ("ProgID=" + $progId + " | Error=" + $_.Exception.Message) }
    }

    L ""
    L "===== COM AUTOMATION SURFACE - NO EXECUTION ====="
    $c = New-Object -ComObject 'MOPS.Connection.1'
    $cmd = New-Object -ComObject 'MOPS.Command.1'
    $rs = New-Object -ComObject 'MOPS.RecordSet.1'
    Members $c 'MOPS.Connection.1 members'
    Members $cmd 'MOPS.Command.1 members'
    Members $rs 'MOPS.RecordSet.1 members'

    L ""
    L "===== CONNECTION ONLY ====="
    $c.ConnectionString = '//HOIGIBMOCLAP12/'
    L ("ConnectionString=" + (Safe $c 'ConnectionString'))
    $c.Connect()
    L ("Connect=OK")
    L ("IsConnected=" + (Safe $c 'IsConnected'))
    L ("ServerTime=" + (Safe $c 'ServerTime'))
    L ("TagBroker=" + (Safe $c 'TagBroker'))
    Start-Sleep -Seconds 3
    TcpForPid $selfPid "PowerShell after Connect, before Browser.Refresh"

    L ""
    L "===== BROWSER METADATA REFRESH ONLY ====="
    try {
        $b = $c.Browser
        $b.Refresh()
        L ("Browser.Refresh=OK | Services.Count=" + $b.Services.Count)
        $mde = @($b.Services | Where-Object { $_.Name -eq 'mde' } | Select-Object -First 1)
        if ($mde) {
            L ("MDE.Name=" + (Safe $mde 'Name'))
            L ("MDE.Node=" + (Safe $mde 'Node'))
            L ("MDE.ProviderClassID=" + (Safe $mde 'ProviderClassID'))
            L ("MDE.ServiceID=" + (Safe $mde 'ServiceID'))
        } else { L "MDE service not found." }
    } catch { L ("BrowserRefreshError=" + $_.Exception.Message) }
    Start-Sleep -Seconds 3
    TcpForPid $selfPid "PowerShell after Browser.Refresh"

    L ""
    L "===== SAFETY ====="
    L "Created Connection, Command and RecordSet COM objects for metadata inspection."
    L "Connected to the already verified MOPS portal and refreshed service metadata."
    L "No CommandText set."
    L "No MOPS.Command.Execute."
    L "No service function invoked."
    L "No Session COM object created and no Session.Open."
    L "No DDE."
    L "No MCD opened, modified, or saved."
    L "No Update/Insert/Delete/Write/Save."
} catch {
    L ""
    L ("ERROR=" + $_.Exception.Message)
    try { L ("HRESULT=0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff)) } catch {}
} finally {
    if ($c) {
        try { $c.Disconnect(); L "Disconnect=OK" } catch { L ("DisconnectError=" + $_.Exception.Message) }
    }
    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
