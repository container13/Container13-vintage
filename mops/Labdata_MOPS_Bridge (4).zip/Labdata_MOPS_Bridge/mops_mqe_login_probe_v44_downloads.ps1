﻿$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_LOGIN_PROBE_v44.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
Remove-Item $out -ErrorAction SilentlyContinue
L "MOPS MQE Login probe v4.4"; L("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss")); L("WindowsIdentity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
try{
$q=New-Object -ComObject "Mqecom.MQEQuery.5"
S "DESTINATION"; $dest="//HOIGIBMOCLAP12/?mqe"; L("SetDestination="+$q.SetDestination($dest)); L("ErrorCode="+$q.GetErrorCode()); L("ErrorType="+$q.GetErrorType())
S "LOGIN TEST - NO TRANSACTION"; L "ApplicationUser=MOPSuser"; L "Password=<blank, not logged>"
try{$rc=$q.Login("MOPSuser","","");L("LoginReturn="+$rc)}catch{L("Login=FEL: "+$_.Exception.Message)}
try{L("ErrorCode="+$q.GetErrorCode())}catch{};try{L("ErrorType="+$q.GetErrorType())}catch{}
try{$ec=[int16]$q.GetErrorCode();$et=[int16]$q.GetErrorType();L("ErrorString="+$q.GetErrorString($ec,$et))}catch{}
}catch{L("TOP FEL="+$_.Exception.Message)}
S "SUMMARY";L "Login() WAS tested with MOPSuser and blank password.";L "NO DoTransaction()";L "NO LoginFromIni()";L "NO MQEUpdate object";L "NO ExecuteDDE()";L "NO Command.Execute()";L "NO Session.Open()";L "NO MOPS data write/update function called";L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
