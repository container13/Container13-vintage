NYA MOPS - MTEST OCX DEEP SCAN v6.9
Datum: 2026-09-09

v6.8 hittade mtest_standalone.exe och mtest.ocx. Själva MTest-logiken ligger
sannolikt i OCX-komponenten, som v6.8 inte skannade.

v6.9 läser därför mtest.ocx och dess COM-registerreferenser för att hitta den
officiella klientens flaggor och syntax för Create session, No CallBack och
Immediate Detach.

KÖRNING
Packa upp och dubbelklicka:
start_mops_mtest_ocx_deep_scan_v69.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_MTEST_OCX_DEEP_SCAN_v69.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
Endast lokal fil- och registerläsning. MTest startas inte. Ingen COM-instans,
nätverksanslutning, Session.Open, Execute, DDE eller MCD-ändring görs.

Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
