﻿$ErrorActionPreference = "Stop"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDE_COMMANDTEXT_v62.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }

$c=$null
$cmd=$null
$rs=$null

try {
    L "MOPS MDE CommandText probe v6.2"
    L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
    L ""

    if([Environment]::Is64BitProcess){
        throw "Körningen är 64-bit. Avbryter; MOPS-klienten är verifierad i 32-bit."
    }

    L "===== CONNECTION ====="
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = "//HOIGIBMOCLAP12/"
    $c.Connect()
    L ("IsConnected=" + $c.IsConnected)
    L ("ServerTime=" + $c.ServerTime)
    L ("TagBroker=" + [string]$c.TagBroker)
    L ""

    L "===== COMMANDTEXT ====="
    $cmd = New-Object -ComObject "MOPS.Command.1"
    $cmd.Connection = $c

    # Exact read-only command string copied from the production MCD.
    # Do NOT set ServiceName or FunctionName separately.
    $cmd.CommandText = "?MDE.GetPeriods()"

    L ("CommandText=" + $cmd.CommandText)
    L ("ServiceName=" + [string]$cmd.ServiceName)
    L ("FunctionName=" + [string]$cmd.FunctionName)
    L ("Parameters.Count=" + $cmd.Parameters.Count)
    try { L ("ParametersText=" + [string]$cmd.Parameters.ParametersText) } catch {}
    L ""

    L "===== EXECUTE READ-ONLY EXACT MCD COMMAND ====="
    $rs = New-Object -ComObject "MOPS.RecordSet.1"

    $sw=[Diagnostics.Stopwatch]::StartNew()
    $cmd.Execute($rs,$true)
    $sw.Stop()

    L "Execute=OK"
    L ("ElapsedMs=" + $sw.ElapsedMilliseconds)

    L ""
    L "===== RECORDSET ====="
    foreach($name in @("RecordCount","FlatRowCount","FlatFieldCount")){
        try { L ($name + "=" + [string]$rs.$name) } catch {}
    }

    try {
        $a=$rs.ResultArray
        if($null -eq $a){
            L "ResultArray=<null>"
        } elseif($a -is [System.Array]) {
            L ("ResultArray.Rank=" + $a.Rank)
            if($a.Rank -eq 2){
                $r0=$a.GetLowerBound(0); $r1=$a.GetUpperBound(0)
                $c0=$a.GetLowerBound(1); $c1=$a.GetUpperBound(1)
                L ("RowBounds="+$r0+".."+$r1)
                L ("ColBounds="+$c0+".."+$c1)
                for($r=$r0;$r -le [Math]::Min($r1,$r0+50);$r++){
                    $vals=@()
                    for($cc=$c0;$cc -le $c1;$cc++){
                        $v=$a.GetValue($r,$cc)
                        if($null -eq $v){$vals+="<null>"}else{$vals+=[string]$v}
                    }
                    L ("ROW["+$r+"] "+($vals -join " | "))
                }
            } else {
                L ("ResultArray=" + [string]$a)
            }
        } else {
            L ("ResultArray=" + [string]$a)
        }
    } catch {
        L ("ResultArrayError=" + $_.Exception.Message)
    }

    L ""
    L "===== SAFETY ====="
    L "Executed exactly one read-only command: ?MDE.GetPeriods()"
    L "This exact CommandString exists in the production MCD."
    L "No Data/Update/Insert/Delete/Write/Save command."
    L "No Session.Open()."
    L "No DDE."
    L "No MQEUpdate."
    L "No WinMOPS file modified."
}
catch {
    L ""
    L ("ERROR=" + $_.Exception.Message)
    try { L ("HRESULT=0x{0:X8}" -f ($_.Exception.HResult -band 0xffffffff)) } catch {}
}
finally {
    if($c){
        try { $c.Disconnect(); L "Disconnect=OK" } catch {}
    }
    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
