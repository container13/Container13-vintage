﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MACCESS_FAST_SCAN_v50b.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s="") { Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s) { L ""; L ("===== " + $s + " =====") }

L "MOPS MAccess Fast Scan v5.0b"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

$bin = "C:\Program Files (x86)\MOPS\sys\bin"

H "TARGET BINARIES - DIRECT BIN FOLDER ONLY"
if(Test-Path $bin){
    Get-ChildItem -LiteralPath $bin -File -ErrorAction SilentlyContinue |
      Where-Object {
        $_.Name -match '(?i)(maccess|mtest|mops3i|history|command|mclient|mqecom)'
      } |
      Sort-Object Name |
      ForEach-Object {
        L ($_.FullName + " | " + $_.Length + " bytes | " + $_.LastWriteTime)
      }
} else {
    L "MOPS bin folder not found."
}

H "DIRECT PROGID LOOKUPS"
$progids = @(
  "MOPS3iHistory",
  "MOPS3iHistory.1",
  "MOPS3iSnapshot",
  "MOPS3iSnapshot.1",
  "MOPS.MAccess",
  "MOPS.MAccess.1",
  "MAccess.MAccess",
  "MAccess.MAccess.1",
  "Mqecom.MQEQuery",
  "Mqecom.MQEQuery.5"
)

$regBases = @(
  "Registry::HKEY_CLASSES_ROOT",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes",
  "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes"
)

foreach($pid in $progids){
  $found=$false
  foreach($base in $regBases){
    $kp = Join-Path $base $pid
    if(Test-Path $kp){
      $found=$true
      L ("ProgID="+$pid+" | Key="+$kp)
      try{
        $clsidPath = Join-Path $kp "CLSID"
        if(Test-Path $clsidPath){
          $clsid = (Get-Item -LiteralPath $clsidPath).GetValue("")
          if($clsid){ L ("  CLSID="+$clsid) }

          if($clsid){
            foreach($cb in @(
              "Registry::HKEY_CLASSES_ROOT\CLSID",
              "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID",
              "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID"
            )){
              $ck = Join-Path $cb $clsid
              if(Test-Path $ck){
                foreach($sub in @("InprocServer32","LocalServer32","TypeLib","ProgID")){
                  $sp=Join-Path $ck $sub
                  if(Test-Path $sp){
                    try{
                      $val=(Get-Item -LiteralPath $sp).GetValue("")
                      if($val){ L ("  "+$sub+"="+$val) }
                    }catch{}
                  }
                }
                break
              }
            }
          }
        }
      }catch{}
      break
    }
  }
  if(-not $found){ L ("ProgID="+$pid+" | NOT FOUND") }
}

H "SAFE COM CREATION - LOCAL ONLY"
foreach($pid in @(
  "MOPS3iHistory",
  "MOPS3iSnapshot",
  "Mqecom.MQEQuery.5",
  "MOPS.MAccess",
  "MAccess.MAccess"
)){
  try{
    $o = New-Object -ComObject $pid -ErrorAction Stop
    L ("ProgID="+$pid+" | Created=True | Type="+$o.GetType().FullName)
    try{
      [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($o) | Out-Null
    }catch{}
  }catch{
    L ("ProgID="+$pid+" | Created=False | Error="+$_.Exception.Message)
  }
}

H "SUMMARY"
L "Fast targeted local scan only."
L "No recursive full-registry scan."
L "No MOPS server connection."
L "No login."
L "No query."
L "No Submit/Execute/Update/Write invoked."
L "No file modified except this output."
L ("Output="+$out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
