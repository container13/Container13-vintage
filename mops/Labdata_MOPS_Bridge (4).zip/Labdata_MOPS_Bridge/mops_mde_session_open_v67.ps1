﻿$ErrorActionPreference = "Stop"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDE_SESSION_OPEN_v67.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s = "") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Safe($o, [string]$name) {
    try {
        $v = $o.$name
        if ($null -eq $v) { return '<null>' }
        return [string]$v
    } catch { return '<unavailable>' }
}
function TcpSnapshot([string]$label) {
    L ('-- ' + $label + ' PID=' + $PID + ' --')
    try {
        $rows = Get-NetTCPConnection -OwningProcess $PID -ErrorAction Stop |
            Sort-Object LocalPort, RemoteAddress, RemotePort
        if (-not $rows) { L '  No TCP rows.' }
        foreach ($t in $rows) {
            L ('  State={0} | Local={1}:{2} | Remote={3}:{4}' -f `
                $t.State, $t.LocalAddress, $t.LocalPort, $t.RemoteAddress, $t.RemotePort)
        }
    } catch { L ('  TcpSnapshotError=' + $_.Exception.Message) }
}

$connection = $null
$session = $null

try {
    L 'MOPS MDE Session.Open Probe v6.7'
    L ('Time=' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    L ('WindowsIdentity=' + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    L ('PowerShellPID=' + $PID)
    L ('Is64BitProcess=' + [Environment]::Is64BitProcess)
    L 'PURPOSE=Test only the documented provider-session step for MDESPName mde.'

    if ([Environment]::Is64BitProcess) {
        throw '64-bit process detected. This probe requires 32-bit Windows PowerShell.'
    }

    L ''
    L '===== BEFORE CONNECTION ====='
    TcpSnapshot 'Before MOPS.Connection.Connect'

    L ''
    L '===== MOPS CONNECTION ====='
    $connection = New-Object -ComObject 'MOPS.Connection.1'
    $connection.ConnectionString = '//HOIGIBMOCLAP12/'
    L ('ConnectionString=' + $connection.ConnectionString)
    $connection.Connect()
    L 'Connect=OK'
    L ('IsConnected=' + (Safe $connection 'IsConnected'))
    L ('ServerTime=' + (Safe $connection 'ServerTime'))
    Start-Sleep -Seconds 2
    TcpSnapshot 'After MOPS.Connection.Connect'

    L ''
    L '===== MDE SESSION CONFIGURATION ====='
    $session = New-Object -ComObject 'MOPS.Session.1'
    $session.Connection = $connection
    $session.SessionString = 'mde'
    L ('SessionString=' + (Safe $session 'SessionString'))
    L ('IsOpenBefore=' + (Safe $session 'IsOpen'))
    L ('SessionErrorStateBefore=' + (Safe $session 'SessionErrorState'))

    L ''
    L '===== SESSION.OPEN ONLY ====='
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $session.Open()
        $sw.Stop()
        L 'Session.Open=OK'
        L ('ElapsedMs=' + $sw.ElapsedMilliseconds)
        L ('IsOpenAfter=' + (Safe $session 'IsOpen'))
        L ('SessionErrorStateAfter=' + (Safe $session 'SessionErrorState'))
        try {
            $browser = $session.Browser
            L ('SessionBrowserType=' + $browser.GetType().FullName)
            L ('SessionBrowserService=' + (Safe $browser 'Name'))
            $functions = $browser.Functions
            L ('SessionBrowserFunctions.Count=' + (Safe $functions 'Count'))
        } catch { L ('SessionBrowserReadError=' + $_.Exception.Message) }
    } catch {
        $sw.Stop()
        L ('Session.Open.ERROR=' + $_.Exception.Message)
        try { L ('Session.Open.HRESULT=0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffff)) } catch {}
        L ('ElapsedMs=' + $sw.ElapsedMilliseconds)
        L ('IsOpenAfterError=' + (Safe $session 'IsOpen'))
        L ('SessionErrorStateAfterError=' + (Safe $session 'SessionErrorState'))
    }
    Start-Sleep -Seconds 2
    TcpSnapshot 'After Session.Open attempt'

    L ''
    L '===== SAFETY ====='
    L 'Executed only MOPS.Connection.Connect and MOPS.Session.Open for service mde.'
    L 'No MOPS.Command object created.'
    L 'No CommandText and no Execute.'
    L 'No MDE function or data query invoked.'
    L 'No DDE.'
    L 'No MCD opened, modified, or saved.'
    L 'No Update/Insert/Delete/Write/Save.'
} catch {
    L ''
    L ('ERROR=' + $_.Exception.Message)
    try { L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffff)) } catch {}
} finally {
    if ($session) {
        try {
            if ($session.IsOpen) { $session.Close(); L 'Session.Close=OK' }
        } catch { L ('Session.CloseError=' + $_.Exception.Message) }
    }
    if ($connection) {
        try { $connection.Disconnect(); L 'Disconnect=OK' } catch { L ('DisconnectError=' + $_.Exception.Message) }
    }
    L ('Output=' + $out)
}

Write-Host ''
Write-Host 'KLAR - skicka hit:' -ForegroundColor Green
Write-Host $out
