﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDE_SERVICE_CONTRACT_v60.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s){ L ""; L ("===== " + $s + " =====") }
function SafeVal($o,[string]$name){
    try{
        $v=$o.$name
        if($null -eq $v){ return "<null>" }
        return [string]$v
    }catch{return "<unavailable>"}
}
function CountOf($o){
    try{return [int]$o.Count}catch{return -1}
}
function ItemAt($o,[int]$i){
    try{return $o.Item($i)}catch{}
    try{return $o[$i]}catch{}
    return $null
}

L "MOPS MDE Service Contract probe v6.0"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

$server="//HOIGIBMOCLAP12/"

H "CONNECTION"
try{
    $conn=New-Object -ComObject "MOPS.Connection.1"
    try{$conn.ConnectionString=$server}catch{}
    # Some installations connect when ConnectionString is set, others expose Connect().
    try{
        if(-not $conn.IsConnected){
            if(($conn | Get-Member -Name Connect -MemberType Method)){ $conn.Connect() | Out-Null }
        }
    }catch{}
    L ("ConnectionString=" + (SafeVal $conn "ConnectionString"))
    L ("IsConnected=" + (SafeVal $conn "IsConnected"))
    L ("ServerTime=" + (SafeVal $conn "ServerTime"))
    L ("TagBroker=" + (SafeVal $conn "TagBroker"))
}catch{
    L ("ConnectionCreateError=" + $_.Exception.Message)
}

H "SERVICES BROWSER"
$browser=$null

# Route A: browser exposed by connection
foreach($propName in @("Services","ServiceBrowser","ServicesBrowser")){
    if($null -eq $browser -and $conn){
        try{
            $candidate=$conn.$propName
            if($candidate){
                $browser=$candidate
                L ("BrowserRoute=Connection." + $propName)
            }
        }catch{}
    }
}

# Route B: standalone registered browser
if($null -eq $browser){
    foreach($progid in @("MOPS.ServicesBrowser.1","MOPS.ServicesBrowser","MOPS.ServiceBrowser.1","MOPS.ServiceBrowser")){
        try{
            $candidate=New-Object -ComObject $progid
            if($candidate){
                $browser=$candidate
                L ("BrowserRoute=COM:" + $progid)
                break
            }
        }catch{}
    }
}

if($browser){
    # Attach connection only if such a writable property/method exists.
    try{$browser.Connection=$conn; L "Browser.Connection=assigned"}catch{}
    try{$browser.MOPSConnection=$conn; L "Browser.MOPSConnection=assigned"}catch{}
    try{$browser.ConnectionString=$server; L ("Browser.ConnectionString=" + $server)}catch{}
    try{
        if(($browser | Get-Member -Name Refresh -MemberType Method)){
            $browser.Refresh()
            L "Browser.Refresh=OK"
        }
    }catch{L ("Browser.RefreshError=" + $_.Exception.Message)}

    L ("Browser.Type=" + $browser.GetType().FullName)
    try{
        L "-- Browser members --"
        $browser | Get-Member | ForEach-Object { L ("  " + $_.MemberType + " " + $_.Name) }
    }catch{}
}else{
    L "Browser=<not created>"
}

# Get services collection by common property names.
$services=$null
foreach($pn in @("Services","Items")){
    if($browser -and $null -eq $services){
        try{
            $x=$browser.$pn
            if($x){$services=$x; L ("ServicesRoute=Browser."+$pn)}
        }catch{}
    }
}
# In some builds ServicesBrowser itself is the collection.
if($null -eq $services -and $browser){
    try{
        $c=CountOf $browser
        if($c -ge 0){$services=$browser; L "ServicesRoute=Browser itself"}
    }catch{}
}

if($services){
    $sc=CountOf $services
    L ("ServiceCount=" + $sc)
    for($i=0;$i -lt $sc;$i++){
        $s=ItemAt $services $i
        if($s){
            L ("SERVICE["+$i+"] Name=" + (SafeVal $s "Name"))
        }
    }
}else{
    L "Services=<not available>"
}

H "MDE SERVICE"
$mde=$null
if($services){
    $sc=CountOf $services
    for($i=0;$i -lt $sc;$i++){
        $s=ItemAt $services $i
        if($s -and ((SafeVal $s "Name") -ieq "mde")){$mde=$s;break}
    }
}
if($mde){
    foreach($p in @("Name","Node","ProviderClassID","ServiceID","DisplayName","Description","Type","Context","Server","Host")){
        L ($p + "=" + (SafeVal $mde $p))
    }

    try{
        L "-- MDE service members --"
        $mde | Get-Member | ForEach-Object {L ("  "+$_.MemberType+" "+$_.Name)}
    }catch{}

    $funcs=$null
    try{$funcs=$mde.Functions}catch{}
    if($funcs){
        $fc=CountOf $funcs
        L ("FunctionCount=" + $fc)

        $interesting = '(?i)(Get|Read|Data|Period|Department|Area|Location|Grid|Sample|Property|Tag|Value|Time|Config|Limit|Grade|Method)'
        $unsafe = '(?i)(Update|Insert|Delete|Write|Save|Set|Create|Modify|Commit|Activate)'

        for($i=0;$i -lt $fc;$i++){
            $fn=ItemAt $funcs $i
            if(-not $fn){continue}
            $name=SafeVal $fn "Name"

            # List every function name, marking likely read vs unsafe-looking.
            $flag=""
            if($name -match $unsafe){$flag=" [WRITE-LIKE NAME - NOT EXECUTED]"}
            elseif($name -match $interesting){$flag=" [READ/RELEVANT CANDIDATE]"}
            L ("FUNCTION["+$i+"] "+$name+$flag)

            # Only introspect schema for read/relevant candidates.
            if(($name -match $interesting) -and -not ($name -match $unsafe)){
                try{
                    $pars=$fn.Parameters
                    $pc=CountOf $pars
                    L ("  Parameters.Count="+$pc)
                    for($j=0;$j -lt $pc;$j++){
                        $p=ItemAt $pars $j
                        if($p){
                            L ("    P["+$j+"] Name="+(SafeVal $p "Name")+" | Type="+(SafeVal $p "Type"))
                        }
                    }
                }catch{}
                try{
                    $fields=$fn.Fields
                    $flc=CountOf $fields
                    L ("  Fields.Count="+$flc)
                    for($j=0;$j -lt $flc;$j++){
                        $f=ItemAt $fields $j
                        if($f){
                            L ("    F["+$j+"] Name="+(SafeVal $f "Name")+" | Type="+(SafeVal $f "Type"))
                        }
                    }
                }catch{}
            }
        }
    }else{
        L "MDE.Functions=<not available>"
    }
}else{
    L "MDE service=<not found>"
}

H "SAFETY"
L "Service-browser metadata/schema inspection only."
L "No MOPS.Command Execute()."
L "No service function invocation."
L "No Session.Open()."
L "No DDE."
L "No MQEUpdate."
L "No Update/Insert/Delete/Write/Save operation."
L ("Output=" + $out)

try{if($conn -and $conn.IsConnected){$conn.Disconnect() | Out-Null; L "Disconnect=OK"}}catch{}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
