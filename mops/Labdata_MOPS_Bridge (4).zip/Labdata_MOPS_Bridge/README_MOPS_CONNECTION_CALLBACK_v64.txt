NYA MOPS - CONNECTION/CALLBACK MAP v6.4
Datum: 2026-09-09

RESULTAT FRÅN v6.3
Den fungerande WinMOPS-processen hade MDEGrid.mcx, mclient.dll och
mportalps.dll laddade. WinMOPS lyssnade på lokal TCP-port 52646 och hade två
etablerade anslutningar från 10.244.32.134 till denna lokala port.

Det visar att den fungerande MDEGrid-vägen har en dubbelriktad RPC/DCOM-kanal.
Det är förenligt med att fristående PowerShell når servicekatalog/metadata men
får RPC 0x800706BA när MDE-providern ska leverera data.

SYFTE MED v6.4
- jämföra WinMOPS nätläge med fristående PowerShell
- kontrollera om enbart MOPS.Connection.Connect öppnar en callback-lyssnare
- kontrollera om Browser.Refresh ändrar nätläget
- lista COM-ytan för Connection, Command och RecordSet utan Execute
- kontrollera DNS och relevanta aktiva brandväggsregler

INNAN DU KÖR
1. Starta WinMOPS och logga in normalt.
2. Öppna "Manuell labdata Alt1".
3. Kontrollera att riktiga värden syns och låt WinMOPS vara öppet.

KÖRNING
Dubbelklicka:
start_mops_connection_callback_map_v64.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_CONNECTION_CALLBACK_MAP_v64.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
- MOPS.Connection skapas och ansluts till den redan verifierade portalen
- Browser.Refresh läser endast service-metadata
- Command och RecordSet skapas endast för medlemslista
- ingen CommandText sätts
- ingen Execute
- ingen servicefunktion anropas
- inget Session-objekt skapas och ingen Session.Open
- ingen DDE
- ingen MCD öppnas, ändras eller sparas
- ingen Update/Insert/Delete/Write/Save

Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
