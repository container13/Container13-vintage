﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MTEST_QUERY_FILES_SCAN_v48.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s="") { Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s) { L ""; L ("===== " + $s + " =====") }

L "MOPS MTest Query Files Scan v4.8"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)

$roots = @(
  "C:\Program Files (x86)\MOPS",
  "C:\Program Files\MOPS",
  $env:USERPROFILE,
  $env:APPDATA,
  $env:LOCALAPPDATA,
  "$env:USERPROFILE\Downloads\Labdata_MOPS_Bridge"
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

H "MTEST EXECUTABLES / CONFIG FILES"
$mtestFiles = foreach($r in $roots){
  Get-ChildItem -Path $r -File -Recurse -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match '^mtest(\..+)?$' -or $_.Name -ieq 'mtest.ini' -or $_.Name -match '^mtest.*\.(ini|cfg|config)$'
  }
}
$mtestFiles = $mtestFiles | Sort-Object FullName -Unique
foreach($f in $mtestFiles){
  L ($f.FullName + " | " + $f.Length + " bytes | " + $f.LastWriteTime)
}

H "SAFE MTEST.INI CONTENT"
foreach($f in ($mtestFiles | Where-Object {$_.Extension -ieq ".ini"})){
  L ""
  L ("FILE: " + $f.FullName)
  try{
    foreach($line in (Get-Content -LiteralPath $f.FullName -ErrorAction Stop)){
      # Never expose password-like values.
      if($line -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){
        $key = ($line -split '=',2)[0]
        L ($key + "=<REDACTED>")
      } else {
        L $line
      }
    }
  } catch { L ("  READ ERROR: " + $_.Exception.Message) }
}

H "QUERY FILES (.qry)"
$qry = @()
foreach($r in $roots){
  $qry += Get-ChildItem -Path $r -Filter "*.qry" -File -Recurse -ErrorAction SilentlyContinue
}
$qry = $qry | Sort-Object FullName -Unique
L ("QueryFilesFound=" + (($qry | Measure-Object).Count))

foreach($f in $qry){
  L ""
  L ("FILE: " + $f.FullName)
  L ("SIZE: " + $f.Length)
  try{
    $lines = Get-Content -LiteralPath $f.FullName -ErrorAction Stop
    $n=0
    foreach($line in $lines){
      $n++
      if($line -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){
        $key = ($line -split '=',2)[0]
        L ("  ["+$n+"] " + $key + "=<REDACTED>")
      } else {
        $shown = $line
        if($shown.Length -gt 1000){$shown=$shown.Substring(0,1000)+" ..."}
        L ("  ["+$n+"] " + $shown)
      }
      if($n -ge 300){ L "  ... TRUNCATED AFTER 300 LINES ..."; break }
    }
  } catch {
    L ("  TEXT READ ERROR: " + $_.Exception.Message)
  }
}

H "SCRIPT FILES REFERENCING qryString / SUBMIT / TagHistory"
$scr = @()
foreach($r in $roots){
  $scr += Get-ChildItem -Path $r -Filter "*.scr" -File -Recurse -ErrorAction SilentlyContinue
}
$scr = $scr | Sort-Object FullName -Unique
foreach($f in $scr){
  try{
    $hits = Select-String -LiteralPath $f.FullName -Pattern @("qryString","SUBMIT","TagHistory","Tag history","StartTime","EndTime","NumValues") -SimpleMatch -CaseSensitive:$false
    if($hits){
      L ""
      L ("FILE: " + $f.FullName)
      foreach($m in $hits){
        $txt=$m.Line
        if($txt -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){
          $txt=(($txt -split '=',2)[0] + "=<REDACTED>")
        }
        L ("  ["+$m.LineNumber+"] "+$txt)
      }
    }
  } catch {}
}

H "LIKELY ROOT DIRECTORIES FROM MTEST.INI"
foreach($f in ($mtestFiles | Where-Object {$_.Extension -ieq ".ini"})){
  try{
    Select-String -LiteralPath $f.FullName -Pattern @("rootDir","lastQry","lastConnect","qryString") -SimpleMatch -CaseSensitive:$false |
      ForEach-Object {
        $txt=$_.Line
        if($txt -match '(?i)\b(pass(word)?|pwd|secret|token)\b\s*='){$txt=(($txt -split '=',2)[0]+"=<REDACTED>")}
        L ($f.FullName+" ["+$_.LineNumber+"] "+$txt)
      }
  } catch {}
}

H "SUMMARY"
L "Local read-only scan."
L "No COM objects created."
L "No MOPS/MQE server query executed."
L "No login attempted."
L "No file modified."
L "Password/token-like INI values are redacted."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
