﻿# mops_mqe_taghistory_transaction_probe_v43.ps1
# Controlled READ-ONLY MQECOM query using the actual MQECOMDLL$QUERY contract:
# Table, Function, Columns, Orderby, Params.
# No login, no update object, no Session.Open, no DDE.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_MQE_TAGHISTORY_TRANSACTION_PROBE_v43.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
function P($o,$n){try{$v=$o.$n;if($null-eq$v){"<null>"}else{[string]$v}}catch{"<ERR>"}}
Remove-Item $out -ErrorAction SilentlyContinue

$tag="22=3120=7264"
$st=(Get-Date).AddHours(-2)
$en=Get-Date

L "MOPS MQE TagHistory Transaction probe v4.3"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)

try{
 $q=New-Object -ComObject "Mqecom.MQEQuery.5"
 S "DESTINATION"
 L("SetDestination="+$q.SetDestination("//HOIGIBMOCLAP12/?mqe"))
 L("ErrorCode="+$q.GetErrorCode())

 S "QUERY USING MQECOMDLL QUERY CONTRACT"
 # MQECOM object maps:
 # Table -> Table
 # SelFunction -> Function
 # Columns -> Columns
 # OrderingFunction -> Orderby
 # SelParam -> Params
 #
 # Table is the MQE service/table context; Function is the actual read function.
 $q.Table="mqe"
 $q.SelFunction="TagHistory"
 $q.Columns="Tag,Data,Time,Value,Status"
 $q.OrderingFunction=""
 $q.MaxRows=10

 # Params string for the TagHistory function.
 # Keep only the four required/known parameters.
 $q.SelParam='Tags="' + $tag + '",StartTime="' + $st.ToString("yyyy-MM-dd HH:mm:ss") + '",EndTime="' + $en.ToString("yyyy-MM-dd HH:mm:ss") + '",NumValues=10'

 foreach($n in @("Table","SelFunction","Columns","OrderingFunction","SelParam","MaxRows")){
   L($n+"="+(P $q $n))
 }

 S "DOTRANSACTION"
 try{
   $ok=$q.DoTransaction()
   L("DoTransaction="+$ok)
 }catch{L("DoTransaction=FEL: "+$_.Exception.Message)}
 try{L("ErrorCode="+$q.GetErrorCode())}catch{}
 try{L("ErrorType="+$q.GetErrorType())}catch{}
 try{
  $ec=[int16]$q.GetErrorCode();$et=[int16]$q.GetErrorType()
  L("ErrorString="+$q.GetErrorString($ec,$et))
 }catch{}
 L("NumOfRows="+(P $q "NumOfRows"))
 L("NumOfColumns="+(P $q "NumOfColumns"))

 if(([int]$q.NumOfRows)-gt 0 -and ([int]$q.NumOfColumns)-gt 0){
   S "RESULT"
   $cols=[int]$q.NumOfColumns
   for($c=0;$c-lt$cols;$c++){
     try{L("COLUMN[$c]="+$q.GetColumnName([int16]$c))}catch{}
   }
   $rows=[Math]::Min([int]$q.NumOfRows,10)
   for($r=0;$r-lt$rows;$r++){
     $vals=@()
     for($c=0;$c-lt$cols;$c++){
       try{
         $v=New-Object object
         $rc=$q.GetDataVal([ref]$v,[int]$r,[int16]$c)
         $vals+=("C"+$c+"="+[string]$v+" (rc="+$rc+")")
       }catch{$vals+=("C"+$c+"=<ERR "+$_.Exception.Message+">")}
     }
     L("ROW[$r] "+($vals -join " | "))
   }
 }
 try{$q.FreeRowset()|Out-Null}catch{}
}catch{L("TOP FEL="+$_.Exception.Message)}

S "SUMMARY"
L "DoTransaction() WAS attempted once using MQEQuery read object."
L "NO Login()/LoginFromIni()"
L "NO MQEUpdate object"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS write/update function called"
L("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
