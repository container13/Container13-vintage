MOPS MDEGrid Trace Test v5.9

Bakgrund
v58 + MDE Reference Manual visar att MDEGrid har egenskapen TraceCalculations.
Manualen säger att när den är True skrivs MOPS access definitions till:
C:\temp\winmops\mdegrid.txt

Detta test använder därför den aktiva MCD:n som facit och skapar EN LOKAL TESTKOPIA.

Vad scriptet gör
1. Verifierar SHA256 på original-MCD:n.
2. Läser originalet utan att ändra det.
3. Skapar en kopia i Labdata_MOPS_Bridge.
4. Ändrar exakt EN byte:
   (TraceCalculations 0) -> (TraceCalculations 1)
5. Verifierar att exakt en byte skiljer kopian från originalet.
6. Tar bort gammal lokal mdegrid.txt.
7. Öppnar ENDAST testkopian i redan körande WinMOPS via DDE open().
8. Väntar 8 sekunder och kopierar innehållet från mdegrid.txt till resultatfilen.

Säkerhet
- Original-MCD ändras inte.
- Ingen save via DDE.
- Ingen Update/Insert/Delete/Write i scriptet.
- Eventuell serveråtkomst sker genom WinMOPS/MDEGrids normala läsväg när testkopian öppnas.

Resultat
C:\Users\iiblabl4\Downloads\MOPS_MDEGRID_TRACE_RESULT_v59.txt
