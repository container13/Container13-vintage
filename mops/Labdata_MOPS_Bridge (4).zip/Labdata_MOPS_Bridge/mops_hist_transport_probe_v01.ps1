﻿# MOPS History transport probe v0.1
# READ-ONLY. No Execute, no writes, no network scanning.
# Purpose: inspect the already-working MOPS connection and the "hist" service
# for endpoint/transport/provider information that could let the HTML bridge
# reach history without manually opening WinMOPS/MCD.

$ErrorActionPreference = "Stop"
$cs = "//HOIGIBMOCLAP12/"
$outFile = Join-Path $env:USERPROFILE "Downloads\MOPS_HIST_TRANSPORT_PROBE_v01.txt"

function Safe-Value($obj, [string]$name) {
    try {
        $v = $obj.$name
        if ($null -eq $v) { return "<null>" }
        if ($v -is [System.Array]) {
            return (@($v) | ForEach-Object { [string]$_ }) -join "; "
        }
        return [string]$v
    } catch {
        return "<error: $($_.Exception.Message)>"
    }
}

function Dump-Object($title, $obj) {
    Add-Content -LiteralPath $outFile -Value ""
    Add-Content -LiteralPath $outFile -Value "===== $title ====="

    if ($null -eq $obj) {
        Add-Content -LiteralPath $outFile -Value "<null>"
        return
    }

    $members = @()
    try {
        $members = @($obj | Get-Member -MemberType Property,Method | Sort-Object Name)
    } catch {}

    foreach ($m in $members) {
        if ($m.MemberType -eq "Property") {
            Add-Content -LiteralPath $outFile -Value ("PROP  {0} = {1}" -f $m.Name, (Safe-Value $obj $m.Name))
        } else {
            Add-Content -LiteralPath $outFile -Value ("METHOD {0}" -f $m.Name)
        }
    }
}

Remove-Item -LiteralPath $outFile -ErrorAction SilentlyContinue

$c = $null
try {
    $c = New-Object -ComObject "MOPS.Connection.1"
    $c.ConnectionString = $cs
    $c.Connect()

    Add-Content -LiteralPath $outFile -Value "MOPS History transport probe v0.1"
    Add-Content -LiteralPath $outFile -Value ("Time: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    Add-Content -LiteralPath $outFile -Value ("Connected: " + $c.IsConnected)
    Add-Content -LiteralPath $outFile -Value ("ConnectionString: " + $c.ConnectionString)
    Add-Content -LiteralPath $outFile -Value ("ServerTime: " + $c.ServerTime)

    Dump-Object "MOPS.Connection.1" $c

    try {
        Dump-Object "Connection.AuxiliaryParameters" $c.AuxiliaryParameters
    } catch {}

    try {
        Dump-Object "Connection.TagBroker" $c.TagBroker
    } catch {}

    $b = $c.Browser
    $b.Refresh()
    Dump-Object "Browser" $b

    $hist = @($b.Services | Where-Object { $_.Name -eq "hist" } | Select-Object -First 1)
    if (-not $hist) {
        Add-Content -LiteralPath $outFile -Value ""
        Add-Content -LiteralPath $outFile -Value "ERROR: hist service not found"
    } else {
        Dump-Object "Browser.Services['hist']" $hist

        # Dump all property names/values from hist service, including values that
        # ordinary Get-Member exposes but we have not previously inspected.
        try {
            foreach ($f in @($hist.Functions)) {
                Dump-Object ("hist.Function: " + $f.Name) $f

                try {
                    Add-Content -LiteralPath $outFile -Value "PARAMETERS:"
                    foreach ($p in @($f.Parameters)) {
                        $line = "  Name={0}; Type={1}; Required={2}; Default={3}" -f `
                            (Safe-Value $p "Name"), `
                            (Safe-Value $p "Type"), `
                            (Safe-Value $p "Required"), `
                            (Safe-Value $p "DefaultValue")
                        Add-Content -LiteralPath $outFile -Value $line
                    }
                } catch {}
            }
        } catch {}
    }

    # Registry inspection for the exact hist provider CLSID, if exposed.
    $providerClsid = $null
    try { $providerClsid = [string]$hist.ProviderClassID } catch {}
    if ($providerClsid) {
        Add-Content -LiteralPath $outFile -Value ""
        Add-Content -LiteralPath $outFile -Value "===== HIST PROVIDER REGISTRY ====="
        Add-Content -LiteralPath $outFile -Value ("ProviderClassID: " + $providerClsid)

        $regPaths = @(
            "Registry::HKEY_CLASSES_ROOT\CLSID\$providerClsid",
            "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\$providerClsid",
            "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID\$providerClsid"
        )

        foreach ($rp in $regPaths) {
            Add-Content -LiteralPath $outFile -Value ("PATH: " + $rp)
            try {
                $item = Get-Item -LiteralPath $rp -ErrorAction Stop
                Add-Content -LiteralPath $outFile -Value ("  Exists: YES")
                try {
                    $props = Get-ItemProperty -LiteralPath $rp
                    foreach ($pr in $props.PSObject.Properties) {
                        if ($pr.Name -notmatch '^PS') {
                            Add-Content -LiteralPath $outFile -Value ("  {0} = {1}" -f $pr.Name, $pr.Value)
                        }
                    }
                } catch {}
                try {
                    foreach ($sub in Get-ChildItem -LiteralPath $rp -ErrorAction SilentlyContinue) {
                        Add-Content -LiteralPath $outFile -Value ("  SUBKEY: " + $sub.PSChildName)
                        try {
                            $sp = Get-ItemProperty -LiteralPath $sub.PSPath
                            foreach ($pr in $sp.PSObject.Properties) {
                                if ($pr.Name -notmatch '^PS') {
                                    Add-Content -LiteralPath $outFile -Value ("    {0} = {1}" -f $pr.Name, $pr.Value)
                                }
                            }
                        } catch {}
                    }
                } catch {}
            } catch {
                Add-Content -LiteralPath $outFile -Value "  Exists: NO"
            }
        }
    }

    Write-Host ""
    Write-Host "KLAR"
    Write-Host "Resultat sparat i:"
    Write-Host $outFile
    Write-Host ""
    Write-Host "Skicka filen MOPS_HIST_TRANSPORT_PROBE_v01.txt hit."
}
catch {
    Write-Host ""
    Write-Host "FEL:"
    Write-Host $_.Exception.Message
}
finally {
    if ($c) {
        try { $c.Disconnect() } catch {}
    }
}
