﻿# MOPS portal/transport probe v0.3
# READ-ONLY. No MOPS history execution and no writes.
$ErrorActionPreference="SilentlyContinue"

$outFile=Join-Path $env:USERPROFILE "Downloads\MOPS_PORTAL_TRANSPORT_PROBE_v03.txt"
Remove-Item $outFile -ErrorAction SilentlyContinue

"MOPS portal/transport probe v0.3" | Set-Content $outFile
"Time=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Add-Content $outFile

$needles=@(
 "config.MOPSConnections",
 "DefaultPortal",
 "LoginNode",
 "HOIGIBMOCLAP12",
 "MOPSConnections"
)

"`r`n===== ENVIRONMENT =====" | Add-Content $outFile
"COMPUTERNAME=$env:COMPUTERNAME" | Add-Content $outFile
"USERPROFILE=$env:USERPROFILE" | Add-Content $outFile

"`r`n===== REGISTRY TEXT MATCHES =====" | Add-Content $outFile
$roots=@(
 "Registry::HKEY_CURRENT_USER\Software",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\MOPS",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\MOPS"
)
foreach($root in $roots){
 if(Test-Path $root){
  Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
   try{
    $v=Get-ItemProperty $_.PSPath
    $txt=($_.PSChildName+" "+(($v.PSObject.Properties|?{$_.Name -notmatch '^PS'}|%{"$($_.Name)=$($_.Value)"}) -join " | "))
    foreach($n in $needles){
     if($txt -like "*$n*"){
      "$($_.PSPath)`r`n  $txt" | Add-Content $outFile
      break
     }
    }
   }catch{}
  }
 }
}

"`r`n===== CONFIG FILE MATCHES =====" | Add-Content $outFile
$dirs=@(
 "C:\Program Files (x86)\MOPS",
 "$env:APPDATA",
 "$env:LOCALAPPDATA"
)
$exts=@("*.ini","*.cfg","*.conf","*.config","*.xml","*.txt")
foreach($d in $dirs){
 if(Test-Path $d){
  foreach($ext in $exts){
   Get-ChildItem $d -Recurse -File -Filter $ext -ErrorAction SilentlyContinue |
    Where-Object {$_.Length -lt 5MB} | ForEach-Object {
     try{
      $hits=Select-String -LiteralPath $_.FullName -SimpleMatch -Pattern $needles -ErrorAction Stop
      if($hits){
       "FILE: $($_.FullName)" | Add-Content $outFile
       foreach($h in $hits | Select-Object -First 20){
        "  L$($h.LineNumber): $($h.Line.Trim())" | Add-Content $outFile
       }
      }
     }catch{}
    }
  }
 }
}

"`r`n===== MOPS CONNECTION SANITY =====" | Add-Content $outFile
try{
 $c=New-Object -ComObject "MOPS.Connection.1"
 $c.ConnectionString="//HOIGIBMOCLAP12/"
 $c.Connect()
 "Connected=$($c.IsConnected)" | Add-Content $outFile
 "ConnectionString=$($c.ConnectionString)" | Add-Content $outFile
 "TagBroker=$($c.TagBroker)" | Add-Content $outFile
 try{"AuxiliaryParameters=$($c.AuxiliaryParameters)" | Add-Content $outFile}catch{}
 try{$c.Disconnect()}catch{}
}catch{
 "Connection error=$($_.Exception.Message)" | Add-Content $outFile
}

Write-Host ""
Write-Host "KLAR"
Write-Host "Skicka denna fil hit:"
Write-Host $outFile
