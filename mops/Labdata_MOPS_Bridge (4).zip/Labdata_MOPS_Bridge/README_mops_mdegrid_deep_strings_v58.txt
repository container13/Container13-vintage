MOPS MDEGrid Deep String/Registry Scan v5.8

v57 visade:
- ProgID: MDEGrid
- CLSID: {551C85D7-31B1-4E1C-A92C-6C436A6ED8DD}
- InprocServer32: C:\Program Files (x86)\MOPS\sys\bin\MDEGrid.mcx
- aktiv display använder MDESPName=mde

v58 går djupare men är fortfarande helt lokal/read-only:
1. Läser alla CLSID-underkeys för MDEGrid.
2. Läser MDEGrid.mcx som bytes.
3. Extraherar både ASCII och UTF-16-strängar.
4. Letar efter property-/method-/serviceord som kan avslöja hur MDEGrid
   faktiskt triggar läsningen av labbperioderna.

Ingen COM-instans skapas.
Ingen WinMOPS/DDE.
Ingen serveranslutning/login/query.
Ingen Execute/Submit/Update/Write.

Resultat:
C:\Users\<user>\Downloads\MOPS_MDEGRID_DEEP_STRINGS_v58.txt
