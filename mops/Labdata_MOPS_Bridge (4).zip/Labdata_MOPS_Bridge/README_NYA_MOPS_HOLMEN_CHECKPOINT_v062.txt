NYA MOPS HOLMEN – CHECKPOINT v0.62
Datum: 2026-09-09

BAS
- Byggd direkt från v0.61.
- Blekeri 4-bredskärmsfixen från v0.61 är kvar.
- Responsiv höjd och adaptiv datumetikett är kvar.

ÄNDRING v0.62
- Ny vy: Syrgasblekeri 3.
- Placering i Navigator:
    Linje3
      Kokeri 3
      Syrgasblekeri 3
      Blekeri 3
- Kolumner avlästa från WinMOPS MDE-skärmbilder 2026-09-09:
  1. L3 Massa till DD-tvätt – Konc
  2. L3 Massa till DD-tvätt – pH filtrat
  3. L3 Massa till DD-tvätt – Konc utg
  4. L3 Massa till O₂-reaktor – Kappa
  5. L3 Massa till O₂-reaktor – Visk
  6. L3 Massa till O₂-reaktor – Konc
  7. L3 Massa från O₂-reaktor – pH
  8. L3 Massa från O₂-reaktor – Kappa
  9. L3 Massa från O₂-reaktor – Visk
 10. L3 Massa till sileri – Konc
 11. L3 Oxiderad vitlut – EA
 12. L3 Oxiderad vitlut – Sulfid

VIKTIGT
- Inga exakta MOPS-taggar eller prefix har gissats.
- Den nya vyn är UI/layout-förberedd och använder samma read-only adapterstruktur.
- Övriga vyer, MOPS/bridge/login/editera/spara-logik är oförändrade.
- DIAG_HTML_VERSION är fortsatt 0.57 eftersom protokollet inte ändrats.

FÖREGÅENDE VERSION
- v0.61
