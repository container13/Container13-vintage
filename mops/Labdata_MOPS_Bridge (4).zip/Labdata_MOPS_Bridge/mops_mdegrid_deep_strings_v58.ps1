﻿$ErrorActionPreference = "SilentlyContinue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MDEGRID_DEEP_STRINGS_v58.txt"
Remove-Item $out -ErrorAction SilentlyContinue

function L([string]$s=""){ Add-Content -Path $out -Value $s -Encoding UTF8 }
function H([string]$s){ L ""; L ("===== " + $s + " =====") }

$mcx = "C:\Program Files (x86)\MOPS\sys\bin\MDEGrid.mcx"
$clsid = "{551C85D7-31B1-4E1C-A92C-6C436A6ED8DD}"

L "MOPS MDEGrid Deep String/Registry Scan v5.8"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
L ("MDEGridCLSID=" + $clsid)
L ("MCX=" + $mcx)

H "CLSID SUBKEYS"
$clsRoots = @(
 "Registry::HKEY_CLASSES_ROOT\CLSID\$clsid",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\$clsid",
 "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID\$clsid"
)
foreach($root in $clsRoots){
    if(Test-Path $root){
        L ("Root=" + $root)
        Get-ChildItem $root -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
            try{
                $p=$_.PSPath
                $rel=$p.Substring($root.Length)
                $v=Get-ItemProperty $p
                L ("  Key=" + $rel)
                foreach($prop in $v.PSObject.Properties){
                    if($prop.Name -notmatch '^PS'){
                        L ("    " + $prop.Name + "=" + $prop.Value)
                    }
                }
            }catch{}
        }
    }
}

if(-not (Test-Path -LiteralPath $mcx)){
    H "ERROR"
    L "MDEGrid.mcx not found."
    Write-Host "HITTAR INTE MDEGrid.mcx"
    Write-Host $out
    exit
}

$f=Get-Item -LiteralPath $mcx
H "FILE"
L ("Length=" + $f.Length)
L ("FileVersion=" + $f.VersionInfo.FileVersion)
L ("ProductVersion=" + $f.VersionInfo.ProductVersion)
try{ L ("SHA256=" + (Get-FileHash $mcx -Algorithm SHA256).Hash) }catch{}

[byte[]]$bytes=[IO.File]::ReadAllBytes($mcx)

function Get-Ascii([byte[]]$b,[int]$min=4){
    $list=New-Object Collections.Generic.List[string]
    $sb=New-Object Text.StringBuilder
    foreach($x in $b){
        if($x -ge 32 -and $x -le 126){ [void]$sb.Append([char]$x) }
        else {
            if($sb.Length -ge $min){$list.Add($sb.ToString())}
            [void]$sb.Clear()
        }
    }
    if($sb.Length -ge $min){$list.Add($sb.ToString())}
    return $list
}

function Get-Utf16([byte[]]$b,[int]$min=4){
    $list=New-Object Collections.Generic.List[string]
    foreach($offset in 0,1){
        $sb=New-Object Text.StringBuilder
        for($i=$offset;$i -lt $b.Length-1;$i+=2){
            $lo=$b[$i]; $hi=$b[$i+1]
            if($hi -eq 0 -and $lo -ge 32 -and $lo -le 126){
                [void]$sb.Append([char]$lo)
            } else {
                if($sb.Length -ge $min){$list.Add($sb.ToString())}
                [void]$sb.Clear()
            }
        }
        if($sb.Length -ge $min){$list.Add($sb.ToString())}
    }
    return $list
}

$ascii=@(Get-Ascii $bytes 4)
$utf16=@(Get-Utf16 $bytes 4)
$all=@($ascii+$utf16 | Sort-Object -Unique)

H "COUNTS"
L ("AsciiStrings=" + $ascii.Count)
L ("Utf16Strings=" + $utf16.Count)

$terms = @(
 'MDEGrid','MDESPName','MOPSPortal','LoginNode',
 'GetData','GetDataOnOpen','Refresh','RefreshFrequency',
 'DoRefresh','DoSaveGridData','SaveGridData','InputTrigging',
 'Department','Areas','Locations','CurrentTime','PeriodName',
 'NumDataPeriods','DefaultPeriodOut','SelectedTag',
 'GetDepartments','GetDepartmentAreas','GetAreaLocations','GetPeriods',
 'Query','Command','Execute','Submit','Fetch','Read','History',
 'OutputData','Parameters','Fields','Tags','hist::','mde'
)

H "TARGETED ASCII/UTF16 HITS"
$hits=New-Object Collections.Generic.List[string]
foreach($s in $all){
    foreach($t in $terms){
        if($s.IndexOf($t,[StringComparison]::OrdinalIgnoreCase) -ge 0){
            if($s -notmatch '(?i)(password|passwd|pwd|token|secret)'){
                $hits.Add($s)
            }
            break
        }
    }
}
$uniq=@($hits | Sort-Object -Unique)
L ("TargetHits=" + $uniq.Count)
foreach($s in $uniq){
    $x=$s
    if($x.Length -gt 700){$x=$x.Substring(0,700)+"..."}
    L $x
}

H "LIKELY PROPERTY/METHOD TOKENS"
# Pull compact identifier-like strings that look like COM/property names.
$ident=@()
foreach($s in $all){
    if($s -match '^[A-Za-z_][A-Za-z0-9_]{3,48}$'){
        if($s -match '(?i)(MDE|Grid|Data|Refresh|Period|Area|Location|Department|Tag|Time|Input|Output|Save|Read|Fetch|Query|Command|Portal|Login)'){
            $ident += $s
        }
    }
}
$ident=@($ident | Sort-Object -Unique)
L ("IdentifierHits=" + $ident.Count)
foreach($s in $ident){ L $s }

H "SAFETY"
L "Local registry + local binary byte inspection only."
L "No COM object created."
L "No WinMOPS/DDE."
L "No server connection/login/query."
L "No Execute/Submit/Update/Write."
L ("Output=" + $out)

Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
