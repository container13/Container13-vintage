﻿# mops_parameter_value_probe_v20.ps1
# READ-ONLY: bygger lokala TagHistory-parametrar men anropar ALDRIG Execute().
$ErrorActionPreference = "Stop"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_PARAMETER_VALUE_PROBE_v20.txt"
function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function SV($o,[string]$n){ try{$v=$o.$n;if($null -eq $v){"<null>"}else{[string]$v}}catch{"<ERROR: $($_.Exception.Message)>"} }

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
$c=$null; $cmd=$null

try {
  L "MOPS Parameter value probe v2.0"
  L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
  L ("Is64BitProcess="+[Environment]::Is64BitProcess)
  L ""

  $c=New-Object -ComObject "MOPS.Connection.1"
  $c.ConnectionString="//HOIGIBMOCLAP12/"
  $c.Connect()
  L ("IsConnected="+$c.IsConnected)

  $cmd=New-Object -ComObject "MOPS.Command.1"
  $cmd.Connection=$c
  $cmd.ServiceName="hist"
  $cmd.FunctionName="TagHistory"

  L ("ServiceName readback="+[string]$cmd.ServiceName)
  L ("FunctionName readback="+[string]$cmd.FunctionName)
  L ""

  $p=$cmd.Parameters
  $p.RemoveAll()

  $tag="22=3120=7264"
  $start=(Get-Date).AddHours(-24)
  $end=Get-Date

  L "Lagger lokala READ-parametrar - ingen Execute:"
  [void]$p.Add("Tags",$tag)
  [void]$p.Add("StartTime",$start)
  [void]$p.Add("EndTime",$end)
  [void]$p.Add("NumValues",25)

  L ("Count="+$p.Count)
  L ("ParametersText="+(SV $p "ParametersText"))
  L ""

  for($i=0;$i -lt [int]$p.Count;$i++){
    try {
      $x=$p.Item($i)
      L ("ITEM index="+$i)
      foreach($n in @("Name","Value","Type","SchemaType","Options","AmendedTimeStampFormat")){
        L ("  "+$n+"="+(SV $x $n))
      }
    } catch {
      L ("ITEM index="+$i+" FEL="+$_.Exception.Message)
    }
  }

  L ""
  L "Kontroll via Item(Name):"
  foreach($n in @("Tags","StartTime","EndTime","NumValues")){
    try {
      $x=$p.Item($n)
      L ($n+": Name="+(SV $x "Name")+" | Value="+(SV $x "Value")+" | Type="+(SV $x "Type"))
    } catch { L ($n+" FEL="+$_.Exception.Message) }
  }

  L ""
  L "Tommer lokal parametersamling..."
  $p.RemoveAll()
  L ("Count efter RemoveAll="+$p.Count)
  L "KLAR - Execute() anropades INTE."
}
catch { L ("FEL="+$_.Exception.Message) }
finally {
  if($c){try{$c.Disconnect();L "Disconnect=OK"}catch{L ("Disconnect FEL="+$_.Exception.Message)}}
  L "READ-ONLY. Ingen historikbegaran och ingen MOPS-dataskrivning."
  L ("Output="+$out)
}

Write-Host ""
Write-Host "KLAR"
Write-Host "Skicka hit:"
Write-Host $out
