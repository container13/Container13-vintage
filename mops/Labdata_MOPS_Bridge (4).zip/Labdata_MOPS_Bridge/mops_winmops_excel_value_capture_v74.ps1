$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'Downloads\MOPS_WINMOPS_EXCEL_VALUES_v74.txt'
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
function L([string]$s=''){Add-Content -LiteralPath $out -Value $s -Encoding UTF8}
function FindBytes([byte[]]$hay,[byte[]]$needle,[int]$start=0){
  for($i=$start;$i-le$hay.Length-$needle.Length;$i++){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if($hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
function FindBytesReverse([byte[]]$hay,[byte[]]$needle,[int]$start){
  for($i=$start;$i-ge0;$i--){
    $ok=$true
    for($j=0;$j-lt$needle.Length;$j++){if(($i+$j)-ge$hay.Length-or$hay[$i+$j]-ne$needle[$j]){$ok=$false;break}}
    if($ok){return $i}
  }
  return -1
}
function ExcelSnapshot {
  $names=@()
  try{
    $app=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
    for($i=1;$i-le$app.Workbooks.Count;$i++){$names+=([string]$app.Workbooks.Item($i).FullName)}
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)
  }catch{}
  return @($names)
}
function CellText($value){
  if($null-eq$value){return ''}
  return (([string]$value)-replace "`t",' ' -replace "`r?`n",' ')
}
try{
  $source='\\HOIGIBMOCLAP12\WinMOPS\Bilder\Iggesund\Cellulosa\Manuell labdata Alt1.mcd'
  $expected='ACE84824DD638BCEEE1DFA5EF993CC93790FC7AE5F35B51674A20D7733405DEB'
  $work=Join-Path $env:USERPROFILE 'Downloads\Labdata_MOPS_Bridge'
  $copy=Join-Path $work 'Manuell labdata Alt1_EXCEL_VALUE_TEST_v74.mcd'

  L 'MOPS WinMOPS Excel Value Capture v7.4'
  L ('Time='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  L ('WindowsIdentity='+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
  L ('Source='+$source)
  L ('TestCopy='+$copy)

  if(-not(Test-Path -LiteralPath $source)){throw 'Production MCD could not be read.'}
  $sourceHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
  L ('SourceSHA256='+$sourceHash)
  if($sourceHash-ne$expected){throw ('Wrong source version. Expected '+$expected+' but got '+$sourceHash+'.')}

  New-Item -ItemType Directory -Path $work -Force|Out-Null
  [byte[]]$original=[IO.File]::ReadAllBytes($source)
  [byte[]]$bytes=$original.Clone()
  [byte[]]$nameNeedle=[Text.Encoding]::ASCII.GetBytes('(Name "Button_Print")')
  $nameOffset=FindBytes $bytes $nameNeedle 0
  if($nameOffset-lt0){throw 'Button_Print was not found.'}
  if((FindBytes $bytes $nameNeedle ($nameOffset+1))-ge0){throw 'Button_Print occurs more than once.'}
  [byte[]]$valueNeedle=[Text.Encoding]::ASCII.GetBytes('(Visible 0)')
  $valueOffset=FindBytesReverse $bytes $valueNeedle $nameOffset
  if($valueOffset-lt0-or$valueOffset-lt($nameOffset-300)){throw 'Safe Button_Print Visible property was not found.'}
  $digitOffset=$valueOffset+9
  if($bytes[$digitOffset]-ne[byte][char]'0'){throw 'Target byte was not zero.'}
  $bytes[$digitOffset]=[byte][char]'1'
  [IO.File]::WriteAllBytes($copy,$bytes)

  [byte[]]$verify=[IO.File]::ReadAllBytes($copy)
  $diffs=0;$lastDiff=-1
  for($i=0;$i-lt$original.Length;$i++){if($original[$i]-ne$verify[$i]){$diffs++;$lastDiff=$i}}
  L ('PatchObject=Button_Print.Visible')
  L ('PatchOffset='+$digitOffset)
  L ('VerifiedDifferentBytes='+$diffs)
  if($diffs-ne1-or$lastDiff-ne$digitOffset){throw 'Local copy differs by more than the intended byte.'}

  $before=@(ExcelSnapshot)
  L ('ExcelWorkbooksBefore='+($before-join' | '))
  Start-Process -FilePath $copy

  Write-Host ''
  Write-Host 'LOCAL TEST COPY IS OPENING IN WINMOPS.' -ForegroundColor Yellow
  Write-Host '1. Navigate to a department and wait until real values are visible.'
  Write-Host '2. Click PRINT once.'
  Write-Host '3. Leave the Excel window open.'
  Write-Host '4. Return to this black window and press ENTER.'
  [void](Read-Host 'Press ENTER after Excel has opened')

  L ''
  L '===== EXCEL CAPTURE ====='
  L ('CaptureTime='+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $excel=[Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
  L ('ExcelVersion='+$excel.Version)
  L ('WorkbookCount='+$excel.Workbooks.Count)
  $activeFull=''
  try{$activeFull=[string]$excel.ActiveWorkbook.FullName}catch{}
  L ('ActiveWorkbook='+$activeFull)
  $captured=0
  for($w=1;$w-le$excel.Workbooks.Count;$w++){
    $wb=$excel.Workbooks.Item($w)
    $full=[string]$wb.FullName
    $isNew=($before-notcontains$full)
    L ''
    L ('WORKBOOK='+$full)
    L ('WasOpenBefore='+(-not$isNew))
    for($s=1;$s-le$wb.Worksheets.Count;$s++){
      $ws=$wb.Worksheets.Item($s)
      $used=$ws.UsedRange
      $rows=[Math]::Min([int]$used.Rows.Count,200)
      $cols=[Math]::Min([int]$used.Columns.Count,200)
      L ('SHEET='+$ws.Name+' | UsedRows='+$used.Rows.Count+' | UsedColumns='+$used.Columns.Count+' | CapturedRows='+$rows+' | CapturedColumns='+$cols)
      if($isNew-or$activeFull-eq$full){
        L 'BEGIN_TSV'
        $values=$used.Value2
        for($r=1;$r-le$rows;$r++){
          $parts=@()
          for($c=1;$c-le$cols;$c++){
            if($used.Rows.Count-eq1-and$used.Columns.Count-eq1){$v=$values}else{$v=$values[$r,$c]}
            $parts+=CellText($v)
          }
          L ($parts-join"`t")
        }
        L 'END_TSV'
        $captured++
      }else{L 'SkippedData=Workbook existed before test and is not active.'}
      [void][Runtime.InteropServices.Marshal]::ReleaseComObject($used)
      [void][Runtime.InteropServices.Marshal]::ReleaseComObject($ws)
    }
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($wb)
  }
  L ('CapturedSheets='+$captured)
  if($captured-eq0){L 'CaptureResult=No eligible Excel sheet found.'}
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)

  L ''
  L '===== SAFETY ====='
  L 'Production MCD hash verified and production file left unchanged.'
  L 'Exactly one byte changed in a local copy: Button_Print.Visible 0 -> 1.'
  L 'WinMOPS performed its existing DoCopyAll and StartExcel actions.'
  L 'The script only read Excel workbook cell values; it did not save or edit Excel.'
  L 'No new MOPS COM connection, Execute, Session.Open, or write to MDE.'
  L 'No Update/Insert/Delete/Write/Save.'
}catch{
  L ''
  L ('ERROR='+$_.Exception.Message)
  try{L ('HRESULT=0x{0:X8}' -f ($_.Exception.HResult-band 0xffffffff))}catch{}
}finally{L ('Output='+$out)}
Write-Host ''
Write-Host 'DONE - send this file:' -ForegroundColor Green
Write-Host $out
