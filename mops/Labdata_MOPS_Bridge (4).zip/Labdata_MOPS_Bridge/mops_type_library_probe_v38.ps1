﻿# mops_type_library_probe_v38.ps1
# READ-ONLY: inspect registered type libraries / COM metadata for MOPS3i and MQE.
# Goal: expose real method signatures for MOPS3iHistory / MOPS3iTagFinder / MQEQuery.
# No DDE command, no Execute, no Session.Open, no credentials, no writes.

$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_TYPE_LIBRARY_PROBE_v38.txt"
function L([string]$x=""){Add-Content $out $x -Encoding UTF8}
function S([string]$x){L "";L("===== "+$x+" =====")}
Remove-Item $out -ErrorAction SilentlyContinue

L "MOPS Type Library probe v3.8"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("Identity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

S "REGISTERED PROGIDS"
$progids=@(
 "MOPS3iHistory","MOPS3iSnapshot","MOPS3iTagFinder",
 "Mqecom.MQEQuery","Mqecom.MQEQuery.5",
 "Mqecom.MQEQueryVector","Mqecom.MQEQueryVector.5"
)
foreach($pr in $progids){
 foreach($base in @("Registry::HKEY_CLASSES_ROOT","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes")){
  $k="$base\$pr"
  if(Test-Path $k){
   $cls=$null
   try{$cls=(Get-Item "$k\CLSID").GetValue("")}catch{}
   L("ProgID=$pr | CLSID=$cls")
   if($cls){
    foreach($cb in @("Registry::HKEY_CLASSES_ROOT\CLSID\$cls","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID\$cls")){
     if(Test-Path $cb){
      $tl=$null;$ver=$null
      try{$tl=(Get-Item "$cb\TypeLib").GetValue("")}catch{}
      try{$ver=(Get-Item "$cb\Version").GetValue("")}catch{}
      L("  TypeLib=$tl | Version=$ver")
      foreach($sub in @("InprocServer32","LocalServer32")){
       if(Test-Path "$cb\$sub"){try{L("  "+$sub+"="+(Get-Item "$cb\$sub").GetValue(""))}catch{}}
      }
     }
    }
   }
  }
 }
}

S "POWERSHELL COM METHOD DEFINITIONS"
foreach($pr in @("Mqecom.MQEQuery.5","Mqecom.MQEQueryVector.5","MOPS3iHistory","MOPS3iTagFinder")){
 try{
  $o=New-Object -ComObject $pr
  L("-- $pr --")
  $o.PSObject.Methods|Sort-Object Name|%{
   L($_.Name+" :: "+$_.Definition)
   try{foreach($od in $_.OverloadDefinitions){L("  "+$od)}}catch{}
  }
  $o.PSObject.Properties|Sort-Object Name|%{
   L("PROPERTY "+$_.Name+" :: "+$_.TypeNameOfValue)
  }
 }catch{L("$pr CREATE FEL="+$_.Exception.Message)}
}

S "TYPELIB REGISTRY DETAILS"
$seen=@{}
foreach($root in @("Registry::HKEY_CLASSES_ROOT\TypeLib","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\TypeLib")){
 if(!(Test-Path $root)){continue}
 Get-ChildItem $root -ErrorAction SilentlyContinue|%{
  $guid=$_.PSChildName
  try{
   $txt=(Get-ChildItem $_.PSPath -Recurse -ErrorAction SilentlyContinue|ForEach-Object {
    try{(Get-Item $_.PSPath).GetValue("")}catch{}
   }) -join " "
   if($txt -match '(?i)MOPS|MQE'){
    if(!$seen[$guid]){
     $seen[$guid]=$true
     L("TypeLib=$guid | "+$txt)
    }
   }
  }catch{}
 }
}

S "SUMMARY"
L "NO Initialize()"
L "NO ExecuteDDE()"
L "NO Command.Execute()"
L "NO Session.Open()"
L "NO credentials set"
L "NO MOPS data write"
L ("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
