﻿# Nya MOPS - Connection / Session / History probe v0.5
# Read-only introspection only. Does not execute history or write to MOPS.
# Run in Windows PowerShell (x86).

$ErrorActionPreference = "Continue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_CONNECTION_SESSION_HISTORY_PROBE_v05.txt"

function L([string]$s="") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function S([string]$s) { L ""; L ("===== " + $s + " =====") }

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

L "MOPS Connection/Session/History probe v0.5"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("COMPUTERNAME=" + $env:COMPUTERNAME)
L ("PowerShell=" + $PSVersionTable.PSVersion)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)

function Probe-ComObject {
    param(
        [string]$ProgId,
        [string]$Section
    )

    S $Section
    $obj = $null
    try {
        $obj = New-Object -ComObject $ProgId
        L ("Create " + $ProgId + "=OK")

        L "-- Get-Member --"
        try {
            $obj | Get-Member | Sort-Object MemberType,Name | ForEach-Object {
                L ($_.MemberType.ToString().PadRight(18) + " " + $_.Name + " :: " + $_.Definition)
            }
        } catch {
            L ("Get-Member error: " + $_.Exception.Message)
        }

        L "-- Safe readable properties --"
        try {
            $props = $obj | Get-Member -MemberType Property | Sort-Object Name
            foreach ($p in $props) {
                $name = $p.Name

                # Skip obviously action-oriented or potentially sensitive properties
                if ($name -match '(?i)password|credential|commandtext|functionname') {
                    L ($name + "=<skipped>")
                    continue
                }

                try {
                    $v = $obj.$name

                    if ($null -eq $v) {
                        L ($name + "=<null>")
                    }
                    elseif ($v -is [string] -or $v -is [ValueType]) {
                        L ($name + "=" + [string]$v)
                    }
                    else {
                        L ($name + "=<COM/Object type: " + $v.GetType().FullName + ">")
                    }
                } catch {
                    L ($name + "=<ERROR: " + $_.Exception.Message + ">")
                }
            }
        } catch {
            L ("Property enumeration error: " + $_.Exception.Message)
        }

    } catch {
        L ("Create " + $ProgId + "=ERROR: " + $_.Exception.Message)
    }

    return $obj
}

$conn = Probe-ComObject -ProgId "MOPS.Connection" -Section "MOPS.CONNECTION"
$session = Probe-ComObject -ProgId "MOPS.Session" -Section "MOPS.SESSION"
$hist = Probe-ComObject -ProgId "MOPS3iHistory" -Section "MOPS3IHISTORY"

S "MOPS.COMMAND RELATIONSHIP"
$cmd = $null
try {
    $cmd = New-Object -ComObject "MOPS.Command"
    L "Create MOPS.Command=OK"

    foreach ($name in @("Connection","Session","Parameters","ServiceName","Context","CommandType","MaxRows","PageSize")) {
        try {
            $v = $cmd.$name
            if ($null -eq $v) {
                L ($name + "=<null>")
            }
            elseif ($v -is [string] -or $v -is [ValueType]) {
                L ($name + "=" + [string]$v)
            }
            else {
                L ($name + "=<COM/Object type: " + $v.GetType().FullName + ">")
            }
        } catch {
            L ($name + "=<ERROR: " + $_.Exception.Message + ">")
        }
    }
} catch {
    L ("Create MOPS.Command=ERROR: " + $_.Exception.Message)
}

S "TYPELIB / REGISTRY"
foreach ($progId in @("MOPS.Connection","MOPS.Session","MOPS3iHistory")) {
    try {
        $cp = "Registry::HKEY_CLASSES_ROOT\$progId\CLSID"
        if (Test-Path $cp) {
            $clsid = (Get-ItemProperty -LiteralPath $cp).'(default)'
            L ($progId + " CLSID=" + $clsid)

            $base = "Registry::HKEY_CLASSES_ROOT\CLSID\$clsid"
            foreach ($sub in @("InprocServer32","LocalServer32","TypeLib","ProgID","VersionIndependentProgID")) {
                $path = Join-Path $base $sub
                if (Test-Path $path) {
                    try {
                        $v = (Get-ItemProperty -LiteralPath $path).'(default)'
                        L ("  " + $sub + "=" + [string]$v)
                    } catch {}
                }
            }
        } else {
            L ($progId + " CLSID=<not found>")
        }
    } catch {
        L ($progId + " registry error=" + $_.Exception.Message)
    }
}

S "SUMMARY"
L "Probe complete."
L "Read-only introspection only."
L "No Execute() call made."
L "No history request made."
L "No login/logout invoked."
L "No write invoked."
L ("Output=" + $out)

foreach ($o in @($cmd,$hist,$session,$conn)) {
    if ($null -ne $o) {
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($o) } catch {}
    }
}

Write-Host ""
Write-Host "Klart."
Write-Host "Resultat sparat i:"
Write-Host $out
Write-Host ""
