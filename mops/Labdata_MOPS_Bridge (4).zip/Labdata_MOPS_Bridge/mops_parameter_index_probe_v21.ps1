﻿# mops_parameter_index_probe_v21.ps1
# READ-ONLY. Undersoker hur MOPS.Parameters.Item indexeras.
# Command.Execute() anropas ALDRIG.

$ErrorActionPreference = "Stop"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_PARAMETER_INDEX_PROBE_v21.txt"
function L([string]$s=""){ Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Dump($label,$x){
  L $label
  if($null -eq $x){ L "  <null>"; return }
  foreach($n in @("Name","Value","Type","SchemaType","Options","AmendedTimeStampFormat")){
    try { L ("  {0}={1}" -f $n,[string]$x.$n) } catch { L ("  {0}=<ERR: {1}>" -f $n,$_.Exception.Message) }
  }
}

Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue
$c=$null
try {
  L "MOPS Parameter index probe v2.1"
  L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
  L ("Is64BitProcess="+[Environment]::Is64BitProcess)
  L ""

  $c=New-Object -ComObject "MOPS.Connection.1"
  $c.ConnectionString="//HOIGIBMOCLAP12/"
  $c.Connect()
  L ("IsConnected="+$c.IsConnected)

  $cmd=New-Object -ComObject "MOPS.Command.1"
  $cmd.Connection=$c
  $cmd.ServiceName="hist"
  $cmd.FunctionName="TagHistory"
  $p=$cmd.Parameters
  $p.RemoveAll()

  # Behall returnerade parameterobjekt fran Add - dessa vet vi fungerar fran v19.
  $a0=$p.Add("Tags","22=3120=7264")
  $a1=$p.Add("StartTime",(Get-Date).AddHours(-24))
  $a2=$p.Add("EndTime",(Get-Date))
  $a3=$p.Add("NumValues",25)

  L ("Count="+$p.Count)
  L ""
  Dump "RETURN FROM Add #0" $a0
  Dump "RETURN FROM Add #1" $a1
  Dump "RETURN FROM Add #2" $a2
  Dump "RETURN FROM Add #3" $a3
  L ""

  L "TEST Item(index) - bade 0-based och 1-based:"
  foreach($i in @(0,1,2,3,4)){
    try { Dump ("Item("+$i+")") ($p.Item($i)) }
    catch { L ("Item("+$i+") FEL="+$_.Exception.Message) }
  }

  L ""
  L "TEST Item(name):"
  foreach($n in @("Tags","StartTime","EndTime","NumValues")){
    try { Dump ("Item('"+$n+"')") ($p.Item($n)) }
    catch { L ("Item('"+$n+"') FEL="+$_.Exception.Message) }
  }

  L ""
  $p.RemoveAll()
  L ("Count efter RemoveAll="+$p.Count)
  L "KLAR - Execute() anropades INTE."
}
catch { L ("FEL="+$_.Exception.Message) }
finally {
  if($c){try{$c.Disconnect();L "Disconnect=OK"}catch{}}
  L "READ-ONLY. Ingen historikbegaran och ingen MOPS-dataskrivning."
  L ("Output="+$out)
}
Write-Host ""
Write-Host "KLAR - skicka hit:"
Write-Host $out
