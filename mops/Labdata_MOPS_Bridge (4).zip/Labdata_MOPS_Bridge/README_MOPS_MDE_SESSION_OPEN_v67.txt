NYA MOPS - MDE SESSION.OPEN v6.7
Datum: 2026-09-09

BAKGRUND
v6.5-v6.6 verifierade följande:
- MOPS.Command har egenskapen Session
- MOPS.Session.Open ansluter till en serviceprovider
- Session.Connection används när sessionen öppnas
- SessionString är sessionens anslutningssträng
- MDE-manualens MDESPName är namnet på MDESP-instansen
- fungerande MDEGrid och servicekatalog anger MDESPName/service mde

Därför används exakt SessionString=mde. Inga alternativa strängar provas.

SYFTE
Kontrollera om fristående 32-bitars PowerShell kan öppna själva MDE-provider-
sessionen. Detta skiljer provider/sessionfelet från kommandoparsning och data.

INNAN DU KÖR
WinMOPS får gärna vara öppet med Manuell labdata Alt1 och riktiga värden.

KÖRNING
Packa upp ZIP-filen och dubbelklicka:
start_mops_mde_session_open_v67.bat

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_MDE_SESSION_OPEN_v67.txt

Skicka resultatfilen till ChatGPT.

SÄKERHET
- ansluter till den redan verifierade MOPS-portalen
- öppnar endast en session mot serviceprovidern mde
- skapar inget MOPS.Command-objekt
- ingen CommandText och ingen Execute
- ingen MDE-funktion eller datafråga
- ingen DDE
- ingen MCD öppnas, ändras eller sparas
- ingen Update/Insert/Delete/Write/Save

Sessionen stängs och MOPS-anslutningen kopplas ned efter testet.
Launchern använder sin egen mapp och 32-bitars Windows PowerShell.
