﻿$ErrorActionPreference = "SilentlyContinue"
$out = Join-Path $env:USERPROFILE "Downloads\MOPS_MACCESS_FAST_SCAN_v50c.txt"
Remove-Item $out -ErrorAction SilentlyContinue
function L([string]$s=""){Add-Content -Path $out -Value $s -Encoding UTF8}
function H([string]$s){L "";L("===== "+$s+" =====")}

L "MOPS MAccess Fast Scan v5.0c"
L ("Time="+(Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity="+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess="+[Environment]::Is64BitProcess)

$bin="C:\Program Files (x86)\MOPS\sys\bin"
H "TARGET BINARIES"
if(Test-Path $bin){
 Get-ChildItem $bin -File | Where-Object {$_.Name -match '(?i)(maccess|mtest|mops3i|history|command|mclient|mqecom)'} |
 Sort-Object Name | ForEach-Object {L($_.FullName+" | "+$_.Length+" bytes | "+$_.LastWriteTime)}
}

H "DIRECT PROGID LOOKUPS"
$progIds=@("MOPS3iHistory","MOPS3iHistory.1","MOPS3iSnapshot","MOPS3iSnapshot.1","MOPS.MAccess","MOPS.MAccess.1","MAccess.MAccess","MAccess.MAccess.1","Mqecom.MQEQuery","Mqecom.MQEQuery.5")
$regBases=@("Registry::HKEY_CLASSES_ROOT","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes")
foreach($progIdName in $progIds){
 $found=$false
 foreach($base in $regBases){
  $kp=Join-Path $base $progIdName
  if(Test-Path $kp){
   $found=$true; L("ProgID="+$progIdName+" | Key="+$kp)
   $cp=Join-Path $kp "CLSID"
   if(Test-Path $cp){
    $clsid=(Get-Item $cp).GetValue(""); if($clsid){L("  CLSID="+$clsid)}
    foreach($cb in @("Registry::HKEY_CLASSES_ROOT\CLSID","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID","Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID")){
     $ck=Join-Path $cb $clsid
     if(Test-Path $ck){
      foreach($sub in @("InprocServer32","LocalServer32","TypeLib","ProgID")){
       $sp=Join-Path $ck $sub
       if(Test-Path $sp){$v=(Get-Item $sp).GetValue("");if($v){L("  "+$sub+"="+$v)}}
      };break
     }
    }
   };break
  }
 }
 if(!$found){L("ProgID="+$progIdName+" | NOT FOUND")}
}

H "SAFE COM CREATION"
foreach($progIdName in @("MOPS3iHistory","MOPS3iSnapshot","Mqecom.MQEQuery.5","MOPS.MAccess","MAccess.MAccess")){
 try{
  $o=New-Object -ComObject $progIdName -ErrorAction Stop
  L("ProgID="+$progIdName+" | Created=True | Type="+$o.GetType().FullName)
  try{[Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)|Out-Null}catch{}
 }catch{L("ProgID="+$progIdName+" | Created=False | Error="+$_.Exception.Message)}
}

H "SUMMARY"
L "Fast targeted local scan only."
L "No MOPS server connection / login / query / Submit / Execute / Update / Write."
L ("Output="+$out)
Write-Host "";Write-Host "KLAR - skicka hit:";Write-Host $out
