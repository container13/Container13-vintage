MOPS MDEGrid Component Scan v5.7

Syfte:
Efter analys av den MCD som körs idag vet vi att själva labbdatavägen är
centrerad kring MDEGrid, med MDESPName=mde.

v57 kartlägger därför MDEGrid-komponenten lokalt:
- registrerade ProgID/CLSID
- InprocServer32 / TypeLib om de finns
- relevanta MOPS-binära komponenter
- säkra textsträngar som kan avslöja service-/metodnamn för MDEGrid

Detta är fortfarande read-only:
- ingen COM-instans
- ingen WinMOPS/DDE
- ingen serveranslutning eller login
- ingen query
- ingen Execute/Submit/Update/Write

Resultat:
C:\Users\<user>\Downloads\MOPS_MDEGRID_COMPONENT_SCAN_v57.txt
