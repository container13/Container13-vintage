NYA MOPS - RUNTIME PROVIDER/SESSION/TRANSPORT SNAPSHOT v6.3
Datum: 2026-09-09

SYFTE
Identifiera den provider-/sessions-/transportkontext som den fungerande
WinMOPS/MDEGrid-instansen använder, utan att skicka något MDE-kommando.

VARFÖR DETTA TEST
MDE-manualen anger att MDEGrid.Parameters.MOPSPortal=LoginNode använder den
MOPS-server som användaren loggade in mot i WinMOPS. MDESPName väljer sedan
MDE-serviceproviderinstansen. v6.1 och v6.2 nådde servicekatalog och metadata
från fristående PowerShell, men Execute föll på RPC 0x800706BA.

Det här testet undersöker därför den fungerande WinMOPS-körningen passivt i
stället för att prova fler Execute-varianter.

INNAN DU KÖR
1. Starta WinMOPS normalt.
2. Logga in med WinMOPS-användaren MOPSuser och blankt lösenord.
3. Öppna "Manuell labdata Alt1" och kontrollera att riktiga värden syns.
4. Låt WinMOPS och bilden vara öppna.

KÖRNING
Dubbelklicka:
start_mops_runtime_transport_snapshot_v63.bat

Launchern använder sin egen mapp och fungerar därför oavsett aktuell katalog.
Den startar uttryckligen 32-bitars Windows PowerShell.

RESULTAT
C:\Users\iiblabl4\Downloads\MOPS_RUNTIME_TRANSPORT_SNAPSHOT_v63.txt

SKICKA RESULTATFILEN TILL CHATGPT.

VAD SOM LÄSES
- WinMOPS/MOPS/MDE-processer och startinformation
- relevanta laddade moduler
- TCP-anslutningar som ägs av dessa processer
- endast sektionen [MOPS Portals] ur MOPS-INI-filer i standardmappar
- COM/DCOM-registrering för MDE-provider, MDE-service och MDEGrid

SÄKERHET
- ingen MOPS.Connection skapas
- ingen MOPS.Command och ingen Execute
- ingen Session.Open
- ingen DDE
- ingen MCD öppnas, ändras eller sparas av testet
- ingen Update/Insert/Delete/Write/Save
- rader som ser ut att innehålla lösenord/token filtreras

KÄLLGRUND
- mde-refman-en.pdf: LoginNode använder servern från WinMOPS-login
- mde-refman-en.pdf: MDESPName är namnet på MDESP-instansen
- MOPS_ACTIVE_MDEGRID_PATH_v56.txt
- MOPS_MDEGRID_COMPONENT_SCAN_v57.txt
- MOPS_MDE_SERVICE_CONTRACT_v60b.txt
- MOPS_MDE_DATA_READ_v61.txt
- MOPS_MDE_COMMANDTEXT_v62.txt
