﻿# MOPS parameter collection probe v1.8 - READ ONLY, NO Execute()
$ErrorActionPreference="Continue"
$out=Join-Path $env:USERPROFILE "Downloads\MOPS_PARAMETER_COLLECTION_PROBE_v18.txt"
function L([string]$s=""){Add-Content $out $s -Encoding UTF8;Write-Host $s}
Remove-Item $out -ErrorAction SilentlyContinue
$c=$null;$cmd=$null
try{
 $c=New-Object -ComObject "MOPS.Connection";$c.ConnectionString="//HOIGIBMOCLAP12/";$c.Connect()
 $cmd=New-Object -ComObject "MOPS.Command";$cmd.Connection=$c;$cmd.ServiceName="hist";$cmd.FunctionName="TagHistory"
 L ("IsConnected="+$c.IsConnected)
 L "-- Parameters collection via PSObject metadata --"
 $p=$cmd.Parameters
 try{$p.PSObject.Methods|ForEach-Object{L ("METHOD "+$_.Name+" :: "+$_.OverloadDefinitions)}}catch{L ("Methods FEL="+$_.Exception.Message)}
 try{$p.PSObject.Properties|ForEach-Object{L ("PROPERTY "+$_.Name+" Type="+$_.TypeNameOfValue+" Value="+[string]$_.Value)}}catch{L ("Properties FEL="+$_.Exception.Message)}
 L "-- Command via PSObject metadata --"
 try{$cmd.PSObject.Methods|ForEach-Object{L ("CMDMETHOD "+$_.Name+" :: "+$_.OverloadDefinitions)}}catch{L ("Cmd methods FEL="+$_.Exception.Message)}
 L "KLAR - Execute() anropades INTE."
}catch{L ("FEL="+$_.Exception.Message)}
finally{
 if($null-ne $cmd){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($cmd)}catch{}}
 if($null-ne $c){try{if($c.IsConnected){$c.Disconnect();L "Disconnect=OK"}}catch{};try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)}catch{}}
}
L "READ-ONLY."
L ("Output="+$out)
