@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
set "PS1=%SCRIPT_DIR%mops_mtest_local_scan_v68.ps1"
if not exist "%PS1%" (
  echo HITTAR INTE: %PS1%
  pause
  exit /b 1
)
%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
echo.
pause
