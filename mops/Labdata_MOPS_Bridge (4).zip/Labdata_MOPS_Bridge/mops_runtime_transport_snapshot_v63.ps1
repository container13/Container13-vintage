﻿$ErrorActionPreference = "Continue"

$out = Join-Path $env:USERPROFILE "Downloads\MOPS_RUNTIME_TRANSPORT_SNAPSHOT_v63.txt"
Remove-Item -LiteralPath $out -ErrorAction SilentlyContinue

function L([string]$s = "") { Add-Content -LiteralPath $out -Value $s -Encoding UTF8 }
function Redact([string]$s) {
    if ($s -match '(?i)(password|passwd|pwd|secret|token|credential)\s*=') {
        return (($s -split '=', 2)[0] + '=<filtered>')
    }
    return $s
}

L "MOPS Runtime Provider/Session/Transport Snapshot v6.3"
L ("Time=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
L ("WindowsIdentity=" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
L ("Is64BitProcess=" + [Environment]::Is64BitProcess)
L ""
L "PURPOSE=Passively identify the runtime context used by a working WinMOPS/MDEGrid instance."
L "EXPECTED_STATE=WinMOPS is logged in and Manuell labdata Alt1 is open with visible data."

try {
    L ""
    L "===== WINMOPS / MOPS PROCESSES ====="
    $procs = Get-CimInstance Win32_Process | Where-Object {
        $_.Name -match '(?i)(winmops|mops|mde)' -or $_.ExecutablePath -match '(?i)\\MOPS\\'
    } | Sort-Object ProcessId

    if (-not $procs) { L "No matching process found." }
    foreach ($p in $procs) {
        L ("PID={0} | Name={1} | ParentPID={2} | SessionId={3} | ExecutablePath={4} | CommandLine={5}" -f `
            $p.ProcessId, $p.Name, $p.ParentProcessId, $p.SessionId, $p.ExecutablePath, (Redact ([string]$p.CommandLine)))
    }

    L ""
    L "===== RELEVANT LOADED MODULES ====="
    foreach ($p in $procs) {
        L ("-- PID={0} Name={1} --" -f $p.ProcessId, $p.Name)
        try {
            $gp = Get-Process -Id $p.ProcessId -ErrorAction Stop
            $mods = $gp.Modules | Where-Object {
                $_.ModuleName -match '(?i)(mde|mops|mclient|mipc|rpc|portal|service|provider)' -or
                $_.FileName -match '(?i)\\MOPS\\'
            } | Sort-Object FileName -Unique
            if (-not $mods) { L "  No relevant module names found (or module list unavailable)." }
            foreach ($m in $mods) {
                L ("  Module={0} | Version={1} | Path={2}" -f $m.ModuleName, $m.FileVersionInfo.FileVersion, $m.FileName)
            }
        } catch { L ("  ModuleReadError=" + $_.Exception.Message) }
    }

    L ""
    L "===== TCP CONNECTIONS OWNED BY MATCHING PROCESSES ====="
    $pids = @($procs | ForEach-Object { [int]$_.ProcessId })
    try {
        $tcp = Get-NetTCPConnection -ErrorAction Stop | Where-Object { $pids -contains $_.OwningProcess } |
            Sort-Object OwningProcess, LocalPort, RemoteAddress, RemotePort
        if (-not $tcp) { L "No TCP connections found for matching processes." }
        foreach ($t in $tcp) {
            L ("PID={0} | State={1} | Local={2}:{3} | Remote={4}:{5}" -f `
                $t.OwningProcess, $t.State, $t.LocalAddress, $t.LocalPort, $t.RemoteAddress, $t.RemotePort)
        }
    } catch {
        L ("Get-NetTCPConnectionError=" + $_.Exception.Message)
        L "-- netstat fallback, filtered by PID --"
        $lines = & netstat.exe -ano -p tcp 2>$null
        foreach ($line in $lines) {
            if ($line -match '^\s*TCP\s+\S+\s+\S+\s+\S+\s+(\d+)\s*$') {
                if ($pids -contains [int]$Matches[1]) { L $line.Trim() }
            }
        }
    }

    L ""
    L "===== MOPS PORTAL CONFIGURATION ====="
    $roots = @(
        (Join-Path $env:ProgramData 'MOPS'),
        (Join-Path ${env:ProgramFiles(x86)} 'MOPS'),
        (Join-Path $env:APPDATA 'MOPS'),
        (Join-Path $env:LOCALAPPDATA 'MOPS')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

    $iniFiles = @()
    foreach ($root in $roots) {
        $iniFiles += Get-ChildItem -LiteralPath $root -Filter '*.ini' -File -Recurse -ErrorAction SilentlyContinue
    }
    $iniFiles = $iniFiles | Sort-Object FullName -Unique
    if (-not $iniFiles) { L "No INI files found under standard MOPS roots." }

    foreach ($file in $iniFiles) {
        $lines = @(Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue)
        $inSection = $false
        $captured = New-Object System.Collections.Generic.List[string]
        foreach ($line in $lines) {
            if ($line -match '^\s*\[(.+)\]\s*$') {
                if ($inSection) { break }
                $inSection = ($Matches[1] -match '(?i)^MOPS\s+Portals$')
                if ($inSection) { [void]$captured.Add($line) }
                continue
            }
            if ($inSection) { [void]$captured.Add((Redact $line)) }
        }
        if ($captured.Count -gt 0) {
            L ("-- File=" + $file.FullName)
            foreach ($line in $captured) { L ("  " + $line) }
        }
    }

    L ""
    L "===== MDE PROVIDER COM/DCOM REGISTRATION ====="
    $ids = @(
        '{DBF11749-5F81-4C23-9FC4-3517F9126190}',
        '{55F7FFDF-CDF8-4E8A-AA3F-59C23C8CF591}',
        '{551C85D7-31B1-4E1C-A92C-6C436A6ED8DD}'
    )
    $regRoots = @(
        'Registry::HKEY_CLASSES_ROOT\CLSID',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID',
        'Registry::HKEY_CLASSES_ROOT\AppID',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\AppID',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\AppID'
    )
    foreach ($id in $ids) {
        L ("-- ID=" + $id)
        foreach ($root in $regRoots) {
            $path = Join-Path $root $id
            if (Test-Path -LiteralPath $path) {
                L ("  Key=" + $path)
                try {
                    $item = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
                    foreach ($prop in $item.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }) {
                        L ("    {0}={1}" -f $prop.Name, (Redact ([string]$prop.Value)))
                    }
                    Get-ChildItem -LiteralPath $path -ErrorAction SilentlyContinue | ForEach-Object {
                        L ("    SubKey=" + $_.PSChildName)
                        $sub = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
                        foreach ($prop in $sub.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }) {
                            L ("      {0}={1}" -f $prop.Name, (Redact ([string]$prop.Value)))
                        }
                    }
                } catch { L ("    RegistryReadError=" + $_.Exception.Message) }
            }
        }
    }

    L ""
    L "===== SAFETY ====="
    L "Passive local inspection only."
    L "No MOPS.Connection created."
    L "No MOPS.Command and no Execute."
    L "No Session.Open."
    L "No DDE."
    L "No MCD opened, modified, or saved."
    L "No Update/Insert/Delete/Write/Save."
} catch {
    L ""
    L ("UNEXPECTED_ERROR=" + $_.Exception.Message)
} finally {
    L ("Output=" + $out)
}

Write-Host ""
Write-Host "KLAR - skicka hit:" -ForegroundColor Green
Write-Host $out
