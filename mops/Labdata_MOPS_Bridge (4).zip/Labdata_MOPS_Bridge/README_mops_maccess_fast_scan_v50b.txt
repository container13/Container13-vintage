MOPS MAccess Fast Scan v5.0b

Snabbversion av v50.

Skillnad mot v50:
- Ingen bred rekursiv registry-scan.
- Läser bara MOPS sys\bin direkt.
- Slår upp ett litet antal relevanta ProgID exakt.
- Gör endast lokal COM-objektskapning för kända read/introspection-objekt.
- Ingen serveranslutning, login, query eller submit.

Resultat:
C:\Users\<user>\Downloads\MOPS_MACCESS_FAST_SCAN_v50b.txt
