# LINA HANDOFF – V0.56.1

## Ny huvudarkitektur
Dashboard-first kontrollcentral, responsiv på mobil och större skärmar.

## Dashboard
- Linas lägesbild
- Nästa steg
- Forward: Jägaren + Swing G1
- Pågående forskning: Swing G2
- Historik & utveckling
- Metod
- Äldre LABB/testverktyg
- Projektanteckningar
- Full backup
- Senaste ändringar

## Status läses från verklig localStorage
Jägaren, Swing G1 och Swing G2 visar verklig lokal status/progress. Dashboarden hårdkodar inte att något är aktivt om det inte är startat på enheten.

## Oförändrat
- Jägaren forwardankare 2026-09-11
- Swing G1 forwardankare 2026-09-14
- Swing G1 hash 8f09f32a
- Swing G2 A–O-regler och perioder
- Handel AV
- Robotmognad 48/100

## Nästa
Testa dashboard visuellt på mobil och större skärm. Därefter kör Swing G2 A–O.


## Permanent release rule – two ZIP packages

From V0.56.1 onward, every Lina release delivered to the user MUST include two ZIP packages:

1. **COMPLETE** – the complete deployable Lina package containing all files required for the version.
2. **CHANGED_FILES_ONLY** – only files that were created or modified since the immediately preceding release.

Additional rules:
- Both ZIP packages must use the same Lina version number.
- The complete package is the authoritative deployable release.
- The changed-files package is a convenience package for reviewing/updating only changed files.
- Every delivery must state which files are included in CHANGED_FILES_ONLY.
- Release inspection and ZIP integrity checks must be performed before delivery.
- Historical `LINA_HANDOFF_Vxxxx.md` files are immutable snapshots and must not be rewritten retroactively.
- Each new version gets a new handoff file.
- `LINA_PROJECT_HISTORY.md` is the rolling project/build history and may be updated in new releases.
- This rule must be preserved in future README/handoff files so it survives chat handoffs.
