# WORKER DEPLOY – V0.58.8

V0.58.8 behöver en Worker-uppdatering för G2:s DEV-data från 2020.

## Varför
Den nuvarande `/bars`-rutten använder Alpaca IEX och ger 0 rader för AMD januari 2020.
EODHD-rutten gav inte heller användbar USA-data i live-testet.

## Ny endpoint
`/yahoo-bars`

Den hämtar dags-OHLCV server-side från Yahoo Finance chart-endpointen och returnerar samma radformat som Lina redan använder.

## Deploy
Ersätt den nuvarande Worker-koden med `worker_v0588_complete.js` och deploya med Wrangler.

Typiskt från Worker-repot:
`npx wrangler deploy`

Efter deploy ska `/health` visa version `0.58.8` och `yahooHistoricalConfigured: true`.

Frontend V0.58.8 provar därefter:
1. Worker Yahoo daily
2. EODHD .US
3. Alpaca daily

Ingen livehandel aktiveras.
