# LINA HANDOFF – V0.57.9

## Major UX correction
Swing G2 is a workflow, not a link to the generic Data tool.

The default G2 path is now:
Dashboard → Forskning → Swing G2 → Steg 1: Hämta forskningsdata → Steg A: Dataintegritet → ...

## G2 Step 1
Clearly shows:
- WHERE: Swing G2
- STEP: 1 – Hämta forskningsdata
- WHY: data is required before A–O
- FIXED INPUTS: Lina Selection 16, Dagsdata, DEV 2020–2022, locked pseudo-forward 2023–2026
- NOW: Hämta G2-data
- NEXT: Steg A – Dataintegritet

Generic Data controls are hidden by default in the G2 path and available only via `Visa datainställningar`.

## Permanent rule
If a research plan has pre-registered inputs, the workflow owns those inputs. Do not ask the user to manually reconstruct them in a generic tool.

## Existing permanent rules
The upper work header answers Where am I?
Shared tools inherit workflow owner.
Visible state is authoritative.
Klar/Redo/Väntar must expose next action.
Two ZIPs per release.
Old handoffs immutable.
No image generation unless explicitly requested.

## Research unchanged
No strategy/signal/risk/forward logic changed.
Jägaren anchor 2026-09-11.
Swing G1 anchor 2026-09-14.
Swing G1 hash 8f09f32a.
Swing G2 research grid/periods unchanged.
Handel AV.
Robotmognad 48/100.
