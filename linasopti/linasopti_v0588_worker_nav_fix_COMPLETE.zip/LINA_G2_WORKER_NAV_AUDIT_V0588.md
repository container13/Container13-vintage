# LINA G2 WORKER + NAV AUDIT – V0.58.8

## Worker source inspected
The saved complete Worker source was retrieved and inspected.

Relevant behavior:
- `/bars` proxies Alpaca stock bars and explicitly sets feed `iex`.
- `/eod-bars` uses EODHD and requires `EODHD_API_TOKEN`.

## Why V0.58.7 still failed
The frontend could try more URLs, but it could not create historical coverage that the deployed Worker/upstream did not return.

## Fix
A real backend source is added: `/yahoo-bars`, implemented in `worker_v0588_complete.js`.
It proxies Yahoo's chart data server-side, avoiding browser CORS.

## Back-button finding
Historical context functions repeatedly replace the back-button node.
V0.58.8 centralizes the actual current action on the fresh node through `.onclick`, and G2 re-arms its research back route.

No strategy logic changed.
