# G2 GUIDED FLOW AUDIT – V0.57.9

Problem verified from live screenshot:
Clicking G2 could leave the user at a generic Marknadsdata screen with no clear instruction.

Correction:
1. G2 data action is intercepted before legacy navigation can clear context.
2. G2 owner is explicitly stored.
3. Data pane is reused technically, but generic controls are hidden by default.
4. A dedicated G2 guide tells the user where they are, what is fixed, what to do now, and what happens next.
5. Advanced data settings can still be revealed.
6. Data-ready state leads to Step A, not a dead end.

No trading/research algorithm changes.
