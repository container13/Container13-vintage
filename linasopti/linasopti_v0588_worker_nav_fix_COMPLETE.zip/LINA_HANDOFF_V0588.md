# LINA HANDOFF – V0.58.8

## Live issues
- AMD 2020-01 still returned 0 daily rows in V0.58.7.
- G2 `← Forskning` still did not navigate.

## Root data finding
Saved Worker source `worker_v031_complete.js` shows:
- `/bars` = Alpaca IEX
- `/eod-bars` = EODHD
Neither supplied usable AMD Jan 2020 data in the live test.

## V0.58.8
Adds `worker_v0588_complete.js` with `/yahoo-bars` server-side historical daily OHLCV.
G2 fetch order:
1. Worker Yahoo daily
2. EODHD .US
3. Alpaca daily

Checkpoint: `g2-symbol-month-daily-4`.

## Back navigation
Current context buttons use direct `.onclick` property binding after clone cleanup. G2 explicitly re-arms `← Forskning` with `.onclick`.

## Important deploy note
The website ZIP alone cannot add a Worker endpoint. Deploy `worker_v0588_complete.js` to the existing Linas Opti Cloudflare Worker as well.

## Research unchanged
G2 DEV 2020–2022, pseudo-forward 2023–2026-09-10, 648-grid and all strategy/risk rules unchanged.
Handel AV. Robotmognad 48/100.
